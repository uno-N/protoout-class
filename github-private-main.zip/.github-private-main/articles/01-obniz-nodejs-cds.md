---
title: "obnizとNode.jsでCdSセル(照度センサ)を使ってみる" # 記事のタイトル
emoji: "🌤" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["javaScript","Node.js","obniz","電子工作","CdSセル"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

obnizでCdSセルを使うサンプルが無かったので使ってみます。

## 使うものやソフトウェア

使うものというよりも、使ったものです。

- [obniz](https://obniz.io)
- [1MΩのCdSセル](http://akizukidenshi.com/catalog/g/gI-00110/)
- [ミニブレッドボード](http://akizukidenshi.com/catalog/g/gP-05155/)
- [ジャンパワイヤ オス-オス](http://akizukidenshi.com/catalog/g/gC-05371/)
- Node.js

## CdSセルをobnizに配線

obnizにそれぞれ以下を配線します。

- 0: 電源
- 1: アナログピン
- 2: GND

> ![](https://i.gyazo.com/833479cfa8c24055be4f7739560e6763.png)

## Node.jsのコード

通常通り準備です。

```bash
$ mkdir myapp
$ cd myapp
$ npm init -y
```

obnizのライブラリをインストールします。

```bash
$ npm i obniz
```

`app.js`などのファイルを作成しましょう。

```js
'use strict';

const Obniz = require('obniz');
const obniz = new Obniz('obnizのデバイスID');

obniz.onconnect = async () => {
    obniz.io0.output(true); //io0を5vに
    obniz.io2.output(false); //io2をGNDに

    //io1をアナログピンに
    obniz.ad1.start((voltage) => {
        console.log(`changed to ${voltage} v`);
    });
}
```

電源周りは`io~`をアナログ入力は`ad~`というプロパティを使えるみたいですね。

- 参考: [io - obniz](https://obniz.io/ja/doc/sdk/doc/io)
- 参考: [ad - obniz](https://obniz.io/ja/doc/sdk/doc/ad)


```bash
$ node app.js
```

## 動かしてみた様子

こんな感じで動作しました。

[![](https://i.gyazo.com/68e830028ba9847b61dbdd2f97cb6c9b.jpg)](https://www.instagram.com/p/BxeXtnPjodn/)

> https://www.instagram.com/p/BxeXtnPjodn/
