---
title: "アイキャッチ画像や動画作成などによく使うツールたちまとめ" # 記事のタイトル
emoji: "🎥" # アイキャッチとして使われる絵文字（1文字だけ）
type: "idea" # tech: 技術記事 / idea: アイデア記事
topics: ["画像","サムネイル","動画","OGP"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

実装ネタではなく、記事を書く際などに利用しやすいサムネイル作成のツールなどを紹介します。（随時更新予定です。）

何かサービスを作った際などに利用イメージを伝えたり、利用したいと思わせるにあたり、デザインは非常に大事ですが、時間やお金を掛けずに済むならそうしたいところです。

## 画像作成系

### Canva

- https://www.canva.com/ja_jp
- ひと言: サムネイル作成で大変お世話になってます。ブラウザだけで利用できるので手軽
- 解説：[Canva（キャンバ）とは？無料でもプロ並みな画像編集ができるデザインツールの使い方｜ferret](https://ferret-plus.com/7902)

### Figma

- https://www.figma.com
- ひと言: Webやアプリのモックアップデザインの作成にも利用可能、Canvaよりも日本語に強い印象。
- 解説：[Figma（フィグマ）とは？初心者でも分かるWebデザインツールの使い方｜ferret](https://ferret-plus.com/13195)

## 動画系

### InShot

- https://apps.apple.com/jp/app/inshot-%E5%8B%95%E7%94%BB%E7%B7%A8%E9%9B%86-%E5%8B%95%E7%94%BB%E4%BD%9C%E6%88%90-%E5%8B%95%E7%94%BB%E5%8A%A0%E5%B7%A5/id997362197
- ひと言: 動画をサクッと編集できます。スマホアプリです。

## スクリーンショット系

素早く画面を収録して公開しましょう。Gyazoはとくにオススメです。

### Gyazo

- https://gyazo.com
- ひと言: めちゃ便利。公開URLまで発行してくれるのですぐ使える。MacもWinも使えます。

### Screenpresso 

- https://screenpresso.com/ja/
- Windowsのみ

### その他: 動画収録方法

- Windows - https://omoiji.com/windows10-movie-capture/
- Mac - https://support.apple.com/ja-jp/HT208721/

## 素材系

画像はフリー素材を積極的に使いましょう。お金をかける余裕があれば有料コンテンツも検討しましょう。

### アマナ

- [ストックフォト・写真素材・動画素材ならアマナイメージズ](https://amanaimages.com/home.aspx)

### 写真AC

- [写真素材なら「写真AC」無料（フリー）ダウンロードOK](https://www.photo-ac.com)

### Adobe Stock

- [ストック写真、ロイヤリティフリーの画像、グラフィック、ベクターおよびビデオ | Adobe Stock](https://stock.adobe.com/jp/)

### いらすとや

- [かわいいフリー素材集 いらすとや](https://www.irasutoya.com)

### unsplash

- https://unsplash.com/

## OGP系

シェアをした後に画像を更新しても、キャッシュされてOGP画像が変更されない場合ありますよね。

これらで対応しましょう。

### Facebook シェアデバッガー

- https://developers.facebook.com/tools/debug/?locale=ja_JP

### Twitter Card validator

- https://cards-dev.twitter.com/validator