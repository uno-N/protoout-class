---
title: "友達全員にメッセージを送るシンプルな送信専用LINE BOTを作る【Node.js】 #linedc" # 記事のタイトル
emoji: "🍀" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["LINE","Node.js","JavaScript","LINE Bot","LINE Messaging API"] # タグ。["markdown", "rust", "aws"]のように指定する
published: false # 公開設定（falseにすると下書き）
---

LINE BOTは大枠はユーザーからの投稿に返信する`リプライメッセージ`と、BOT起点でユーザーにメッセージを配信する`プッシュメッセージ`に分かれますが、後者のプッシュメッセージのみ(後述: 厳密にはブロードキャスト)でBOTを作ってみたいと思います。

## STEP0. まずはBOTアカウント作成やチャンネルシークレット取得

[1時間でLINE BOTを作るハンズオン](https://qiita.com/n0bisuke/items/ceaa09ef8898bee8369d)の資料のSTEP1までを終わらせましょう。

## STEP1. JavaScriptコードのコピペでBOT作成

プロジェクト用のフォルダ準備します。とりあえず`mylinebot`としました。

```bash
$ mkdir mylinebot
$ cd mylinebot
```

SDKのインストール

```bash
$ npm init -y
```

```bash
$ npm i @line/bot-sdk
```

`mylinebot`フォルダに`app.js`などの名前でファイルを作成し、以下を記述します。

※`チャンネルシークレット`と`チャンネルアクセストークン`を実際の値に変更しましょう。

```app.js
'use strict';

const line = require('@line/bot-sdk');

const config = {
    channelSecret: 'チャンネルシークレット',
    channelAccessToken: 'チャンネルアクセストークン'
};
const client = new line.Client(config);


const main = async () => {
    
    const messages = [{
        type: 'text',
        text: 'いっせい送信です！'
    }];

    try {
        const res = await client.broadcast(messages);
        console.log(res);        
    } catch (error) {
        console.log(`エラー: ${error.statusMessage}`);
        console.log(error.originalError.response.data);
    }
}

main();

```

実行

```bash
$ node app.js
```

## STEP2. 完成！ 実際の送信された様子

**これで完成！すぐですね〜**

> ![スクリーンショット 2020-12-16 22.56.42.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/35387/8f6b522e-5556-fd1a-52bf-216a5b5607d0.png "スクリーンショット 2020-12-16 22.56.42.png")

## ブロードキャストメッセージで全員に送信

ブロードキャストメッセージは、プッシュメッセージの種類の一つとなります。

* プッシュメッセージ: 1人のユーザーに送信する
* マルチキャストメッセージ: 複数のユーザーに送信する
* ナローキャストメッセージ: 属性情報やリターゲティングを利用して複数のユーザーに送信する
* ブロードキャストメッセージ: LINE公式アカウントと友だちになっているすべてのユーザーに送信する (←今回これ)

> https://developers.line.biz/ja/docs/messaging-api/sending-messages/#push-messages

通常のプッシュメッセージはユーザーIDを指定して送信する必要がありますが、 **ブロードキャストメッセージは友達になっているユーザー全てにメッセージを配信できる**ので、特にIDを気にせず利用できます。

> LINE公式アカウントと友だちになっているすべてのユーザーに、任意のタイミングでプッシュメッセージを送信します。
> 参考: [ブロードキャストメッセージを送る - 公式](https://developers.line.biz/ja/reference/messaging-api/#send-broadcast-message)

Node.jsのSDKにもあるので便利です。[メッセージオブジェクト](https://developers.line.biz/ja/docs/messaging-api/sending-messages/)の配列を指定します。

```js
await client.broadcast(`メッセージオブジェクトの配列`);
```

> line/line-bot-sdk-nodejs https://github.com/line/line-bot-sdk-nodejs/blob/e2ffe1a72a7e49e3a7967c4695fb126734a44452/lib/client.ts#L129

### フリープランだと1000通/月までなので注意

ブロードキャストメッセージは、配信ごとに`無料メッセージ通数`が減っていくので注意しましょう。

> ![スクリーンショット 2020-12-16 23.29.36.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/35387/b4a241f1-0fad-9f46-8d62-e99556668f0f.png "スクリーンショット 2020-12-16 23.29.36.png")
> https://www.linebiz.com/jp/service/line-official-account/plan/

## リプライメッセージが無いとこんなにシンプル

* **Webhookの設定がいらない**

コードを見ると分かりますが、expressなどを使ってなく、サーバーを立てるなどが必要ないです。

> ![スクリーンショット 2020-12-16 23.16.29.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/35387/158b5f30-4b4d-89b6-626c-88a1126eb528.png "スクリーンショット 2020-12-16 23.16.29.png")

Webhook設定は空ですが問題なく動いています。

* **管理画面での設定もデフォで大丈夫**

今回気づきましたが、Webhookをオンにするなどをする必要が無いと、特にBOTの管理画面で設定を変更する必要もなく、動いてくれます。

* **ngrokなどのトンネリングやHerokuなどサーバーの準備をする必要が無い**

サーバーが不要なので、今までngrokでトンネリングして検証したり、Herokuなどにホスティングして試すということをしてましたが、それらも不要です。

* **ハンズオンなどでも良いかも**

サーバー不要で検証もいらないので、 **とりあえず試すには向いてそう。**

## おまけ: 実用化させるために 

このスクリプトをGitHub Actionsなどで定期実行すればOKですね。
（GitHub Actionsの使い方は各自調べて下さい！）

```.github/workflows/node.js.yml
name: 日本時間の12:30,18:30に配信 

on:
  schedule:
  - cron:  '30 3,9 * * *' #(UTCなので9時間ズレ)

jobs:
  build:
    # マシン準備
    runs-on: ubuntu-latest

    strategy:
      matrix:
        node-version: [15.x]

    # 以下が実際のステップ
    steps:

    - uses: actions/checkout@v2
    - name: Use Node.js 15.x
      uses: actions/setup-node@v1
      with:
        node-version: '15.x'

    - name: npm install command
      run: npm i

    - name: メッセージ配信
      run: node app.js
```

初回プッシュ時だけ、`cron`周辺のコードを以下にして実行すると安定します。

```yml
 on:
   push:
     branches: [ master ]
```

## まとめと所感

今までとりあえずのチュートリアルはリプライメッセージをベースにやっていたけど、ブロードキャストメッセージを使った配信専用も手軽で良さそうですね。

ハンズオンのバリエーションが増えそうです。