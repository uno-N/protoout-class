---
title: "機械学習系サービスの事例集" # 記事のタイトル
emoji: "🤖" # アイキャッチとして使われる絵文字（1文字だけ）
type: "idea" # tech: 技術記事 / idea: アイデア記事
topics: ["機械学習"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

随時更新していきます。

機械学習を活用したサービスや事例集です。

## 事例

- [きゅうり判定](https://www.itmedia.co.jp/enterprise/articles/1803/12/news035.html)

## サービス

- [Arduinoも利用してシリアルとマシュマロ分類器](https://experiments.withgoogle.com/tiny-sorter)
- [Quick Draw!](https://quickdraw.withgoogle.com/)
- [ハンドトラッキングでキラッ☆](https://twitter.com/reona396/status/1268133530627801089)
- [顔ホッケー](https://note.com/mizumasa/n/n691a07b49390)
- [遠隔人類補完計画](https://protopedia.net/prototype/d5e2c0adad503c91f91df240d0cd4e49)

## その他

こんなサービスあるよ！というコメント貰えると嬉しいです。