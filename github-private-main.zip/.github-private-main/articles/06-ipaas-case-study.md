---
title: "iPaaSを活用した利用例集" # 記事のタイトル
emoji: "🤖" # アイキャッチとして使われる絵文字（1文字だけ）
type: "idea" # tech: 技術記事 / idea: アイデア記事
topics: ["iPaaS"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

随時更新していきます。

iPaaSを活用したサービスや事例集です。

## 記事

- [【超便利】IFTTTのアプレット・レシピおすすめ21選](https://www.webhack.jp/archives/11990)
- [IFTTTを使ってGoogleアシスタントから家計簿をつける（スプレッドシート編）](https://qiita.com/hideto2112/items/d9aebb33025d30057717)
- [IFTTTの位置情報を活用してできる11のこと | ライフハッカー［日本版］](https://www.lifehacker.jp/2014/01/140128ifttt_location.html)

## その他

こんなサービスあるよ！というコメント貰えると嬉しいです。