---
title: "Node-REDでLINEBotを作るときの参考リンク集" # 記事のタイトル
emoji: "🤖" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["LINE Bot", "Node-RED"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

## 【１】LINE Bot（公式アカウント + Messaging API）が企業で活用されている事例

### 【1-0】まとめサイトまとめ
* [事例記事一覧｜LINE for Business](https://www.linebiz.com/jp/case-study/?field_case_category_function_target_id=6561)
* [チャットボット事例集 : 日本国内のChatBot活用事例](https://chatbot-list.userlocal.jp/chatbots?page=2&platform=line)
* [LINE BOTの業種別おすすめ＆成功事例14選 | Hummingbird](https://humming-bird.info/linebot/linebot_cases/)

### 【1-1】企業のLINE Bot
* [ローソンLINE公式アカウント：便利機能を使いこなそう！｜ローソン研究所](https://www.lawson.co.jp/lab/tsuushin/art/1372267_4659.html)
    * あきこちゃんが商品を教えてくれたり、ゲームできたり
* [LINEで宅急便](https://www.kuronekoyamato.co.jp/ytc/campaign/renkei/LINE/)
* [LINEで郵便局［ぽすくま］の使い方 | 日本郵便株式会社](https://www.post.japanpost.jp/send/line/guide.html)
* [JR東日本 Chat Bot｜JR東日本 LINE公式アカウント](https://info.jreast-chat.com/)
* [チャットボット - ドミノ・ピザ | チャットボット事例集 : 日本国内のChatBot活用事例](https://chatbot-list.userlocal.jp/chatbots/126)
* [デジタルと店舗の融合！LINE公式アカウントを活用したクラフトマルシェの新たな顧客体験｜LINE for Business](https://www.linebiz.com/jp/case-study/craftmarche/?field_case_category_goal_target_id=7456&field_case_category_function_target_id=6561)
* [LINEでモバイルオーダーが完結！「TOUCH-AND-GO COFFEE」のCXデザインとは｜LINE for Business](https://www.linebiz.com/jp/case-study/touch-and-go-coffee/?field_case_category_goal_target_id=7456&field_case_category_function_target_id=6561)

###　【1-3】企業じゃないけど有名なもの、おもしろそうなもの
* [りんな](https://www.rinna.jp/)
* [リマインくん | LINE Official Account](https://page.line.me/aum5545l?openQrModal=true)
* [Youtube字幕ボット](https://youtube-with-caption.weebly.com/)
* [人狼GM | LINE Official Account](https://page.line.me/geu2750q?openQrModal=true)

### 【１−９９】まとめ、感想
* LINE Botという形で情報を与える場合、今までのWebサイトと違い、人や動物と会話するように情報を与える、もしくは引き出させることが効果的だと感じた

## 【2】Node-REDの使い方として、初心者に最もわかりやすい解説をしている記事
* [node-red-beginner-handson-3/01_getting_started.md at master · 1ft-seabass/node-red-beginner-handson-3](https://github.com/1ft-seabass/node-red-beginner-handson-3/blob/master/01_getting_started.md)
* [node-red-beginner-handson-3/02_api_request.md at master · 1ft-seabass/node-red-beginner-handson-3](https://github.com/1ft-seabass/node-red-beginner-handson-3/blob/master/02_api_request.md)
* [Node-RED超入門 - Qiita](https://qiita.com/makaishi2/items/5c7b1b6a72b6938cf3d2)
    * おすすめ

## 【3】Node-REDが使えるサービス（enebularみたいな）の一覧
* [Node-RED](https://nodered.org/)
* [enebular - あらゆるデバイスとクラウドサービスを「つなぐ」、IoTのためのデータ連携プラットフォーム](https://www.enebular.com/ja/)
* [Node-RED | ia-cloud](https://ia-cloud.com/node-red/)
* [GCP で Node-RED によるローコード プログラミングが可能に | Google Cloud Blog](https://cloud.google.com/blog/ja/products/gcp/using-node-red-with-google-cloud)
* [Node-REDを使った照明設備とIoT機器の連携 – スマートライト株式会社](https://smartlight.co.jp/node-red-lighting-iot/)
* [OSSソリューション：OSS（オープンソース・ソフトウェア）：日立](https://www.hitachi.co.jp/products/it/oss/solution/index.html)
* [スタートアップスクリプト「Node-RED」をリリースしました | さくらのクラウドニュース](https://cloud-news.sakura.ad.jp/2017/04/28/node-red-startup-script-release/)
    * レンタルサーバでは、借りる場所によってはクリックだけでサーバにNode-REDをインストールできる

## 【4】その他のローコードツール　おまけ

* Scratchとか
* Blocklyとか
* PureDataとか
* Unityでもエフェクトをノードベースで
    * [【Unity】ゼロから作るノードベースエディター【UIElements】 - Qiita](https://qiita.com/saragai/items/f7f88df863091946c9d1)