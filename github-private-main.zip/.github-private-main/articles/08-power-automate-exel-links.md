---
title: "PowerAutomateとExcelをつなげるときの参考リンク集" # 記事のタイトル
emoji: "💪" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["PowerAutomate", "Excel"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

## 【１】PowerAutomate

### 【1-1】使い方
* [Power Automate のドキュメント - Power Automate | Microsoft Docs](https://docs.microsoft.com/ja-jp/power-automate/)
* [クラウド フローを作成してタスクを自動化する - Power Automate | Microsoft Docs](https://docs.microsoft.com/ja-jp/power-automate/get-started-logic-flow)
* [PowerAppsは僕には難しくて憶えられない。ので、使い方をTips風にまとめておきました - Qiita](https://qiita.com/yowatana/items/7698a7fcbc1e26fb08e4)
* [【無料RPA】RPA初心者がPower Automate Desktopで遊んでみた。ExcelやWeb操作を自動化できるのか。 - YouTube](https://www.youtube.com/watch?v=D6AM1m-esjs)

### 【1-2】使った事例
* [Power Automateで簡単に自動化した生産性向上の事例](https://www.cresco.co.jp/blog/entry/13672/)
* [PowerAutomateで業務を手軽に自動化しよう！その具体例とポイント | BizAppチャンネル](https://www.cloudtimes.jp/dynamics365/blog/powerautomate-tips)

### 【1-3】制作に参考になりそうな事例
* [M365 予定表を Power Automate で Googleカレンダー へ同期する（追加・編集・削除 全対応）トリガーV3更新版 - Qiita](https://qiita.com/yamad365/items/4e64d068e97c6cb3726b)
* [[Teamsと連携！] 参加登録した人に、事前課題をチャットで自動通知 - Qiita](https://qiita.com/Asuka_Nagamine/items/0610b5937332ea00f1e8)
* [C#とPowerAutomateでコメントを画面に表示する発表者アプリ作ってみた](https://zenn.dev/canonno/articles/b1f6182980e70e)

## 【2】Excel

### 【2-1】Excelだけで自動化紹介
* [Excelマクロ「超入門」、初心者でも実例でわかる基礎中の基礎 連載：Excel実践入門講座｜ビジネス+IT](https://www.sbbit.jp/article/cont1/37638)
* [Excel関数 機能別一覧（全486関数） | できるネット](https://dekiru.net/article/4429/)
* [【Python実践】PythonでExcel操作！マクロで仕事を自動化しよう | 侍エンジニアブログ](https://www.sejuku.net/blog/75536)

#### 【2-2】ExcelとPowerAutomateの連携
* [Power AutomateでExcelの特定の行に対していろいろやる - ExPy Style](https://expy-style.net/excel/powerautomate-excel-row-update/)
* Webhook
  * [Webhookとは？APIとの違いや対応サービスについて | IT職種コラム](https://it-kyujin.jp/article/detail/402/)
  * [WebhookとMicrosoft Flowを使って、プログラミングせずにkintoneであれこれ｜R3 Cloud Journey](https://www.r3it.com/blog/20170713-kintone-webhook-ms-flow-1)

## 【3】その他サービスや、連携
* [今話題のiPaaSとは？ツール一覧を紹介 | RPA HACK](https://rpahack.com/ipaas)
* [目次: TeamsとPower Automateを組み合わせて便利に使う！ - Qiita](https://qiita.com/Asuka_Nagamine/items/e94131a2be4878b65deb)
* [Wildfire – Chromeでマクロを組む方法! 操作を記録して繰り返し自動クリックしよう](https://sp7pc.com/google/chrome/14473)

## 【4】情報の調べ方
* [マイクロソフト イベント開催情報](https://www.microsoft.com/ja-jp/events/top)
* [RPACommunityチャンネル - YouTube](https://www.youtube.com/channel/UCm8GV22BVkw6RmeriT7VJUA)
* [RPACommunity - connpass](https://rpacommunity.connpass.com/)
* [自分自身で課題を解決するDX事例紹介連載一覧：CodeZine（コードジン）](https://codezine.jp/article/corner/842)