---
title: "機械学習に関する参考リンク集" # 記事のタイトル
emoji: "🧑‍🎓" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["機械学習", "TeachableMachine"] # タグ。["markdown", "rust", "aws"]のように指定する
published: false # 公開設定（falseにすると下書き）
---

## 【1】機械学習

### 【1-1】機械学習とは
* [AI、機械学習、ディープラーニングの違いを説明できますか？機械学習と統計の違いは？ (1/3)：MarkeZine（マーケジン）](https://markezine.jp/article/detail/29471)
* [AI-SCHOLAR.TECH | AI-SCHOLAR | AI：(人工知能)論文・技術情報メディア](https://ai-scholar.tech/learn/c0/0-1)
* [機械学習とは？これだけは知っておきたい3つのこと - MATLAB & Simulink](https://jp.mathworks.com/discovery/machine-learning.html)

### 【1-2】事例
* [vol26_2_004jp](https://www.nttdocomo.co.jp/binary/pdf/corporate/technology/rd/technical_journal/bn/vol26_2/vol26_2_004jp.pdf)
* [映像自動要約技術の最新動向｜NHK技研R&D｜NHK放送技術研究所](https://www.nhk.or.jp/strl/publica/rd/182/2.html)
* [Hｍcommが、通販大手ディノス・セシールとコールセンター集中呼自動応答(音声Bot)」の共同開発を開始。｜Hmcomm株式会社のプレスリリース](https://prtimes.jp/main/html/rd/p/000000008.000033941.html)
* [トライアルが首都圏初のスマートストア、リテールAIによる流通情報革命の現場に：スマートリテール（1/3 ページ） - MONOist](https://monoist.atmarkit.co.jp/mn/articles/2002/26/news050.html)
* [「スマートスピーカー」の中にある「人工知能」は何をしているのか、作り方から理解する：ものになるモノ、ならないモノ（77） - ＠IT](https://www.atmarkit.co.jp/ait/articles/1805/16/news016.html)
* [元組み込みエンジニアの農家が挑む「きゅうり選別AI」　試作機3台、2年間の軌跡：農業×ディープラーニングの可能性（1/3 ページ） - ITmedia エンタープライズ](https://www.itmedia.co.jp/enterprise/articles/1803/12/news035.html)

### 【1-3】サービスやツール
* [Teachable Machine](https://teachablemachine.withgoogle.com/)
* [Vertex AI  |  Google Cloud](https://cloud.google.com/vertex-ai)
* [Azure Machine Learningのいろは - Qiita](https://qiita.com/gnbrganchan/items/43e6c44754cb83220db5)
* [TensorFlow](https://www.tensorflow.org/?hl=ja)

## 【2】TeachableMachine
[Teachable Machine](https://teachablemachine.withgoogle.com/)

### 【2-1】使い方
* TeachableMachineの使い方
  * [Teachable Machineの利用方法を紹介します - Qiita](https://qiita.com/misa_m/items/d8a20d153c8ee7daf0c1)
  * (過去の資料) [teaching-material/03-teachable_machine.md at po04 · protoout/teaching-material](https://github.com/protoout/teaching-material/blob/po04/lesson-06/03-teachable_machine.md)
* 他のサービスやツールと組み合わせる
  * [「Teachable Machine」で機械学習した音声認識データを使って「Scratch」でプログラミング ～拡張機能「TM2Scratch」を専用の「Scratch」で - どれ使う？プログラミング教育ツール - 窓の杜](https://forest.watch.impress.co.jp/docs/serial/progedu/1273286.html)
  * [yoppa org – Teachable Machine + ml5.js + p5.jsで機械学習コンテンツを作る 1](https://yoppa.org/mit_mediaart19/10591.html)
  * [Node-RED で Teachable Machine を試す（Node-RED のセットアップ後にノードを追加してサンプルを動かす） - Qiita](https://qiita.com/youtoy/items/102c9ab8b5f25d542056)
  * [Google Teachable Machineを使ってノンコーディングで機械学習を体験。 | enebular blog](https://blog.enebular.com/event/noncoding-machine-learning/)

### 【2-2】使った事例や作品
* [ml5でお前のソウルがウルトラソウルかニセモノソウルか判定する - Qiita](https://qiita.com/canonno/items/964b9ff613ced1b217c2)
* [【Node-RED】AIによる広島名物とのそっくり度からオススメのお店を紹介するLINE BOTを作ったよ - Qiita](https://qiita.com/tatsuya1970/items/340857eaef1cecfd3c1a)
* [youさん (@youtoy) / Twitter](https://twitter.com/youtoy)


