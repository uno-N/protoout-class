---
title: "Make（旧: Integromat）のアカウント登録" # 記事のタイトル
emoji: "🤖" # アイキャッチとして使われる絵文字（1文字だけ）
type: "idea" # tech: 技術記事 / idea: アイデア記事
topics: ["Make","Integromat","アカウント登録","iPaaS"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

Make（旧: Integromat）のアカウント登録手順をまとめておきます。

## サイトアクセス

https://www.make.com/

> ![](https://i.gyazo.com/084f8d46c32e1e2a5ca73008c9ffb1b4.png)

`Get started free`から進みます。

## Sign up

有効なメールアドレスをいれてアカウント作成をします。Google経由などで登録も可能ですが、メールアドレスを利用したアカウント作成手順を書いておきます。

> ![](https://i.gyazo.com/64e329a484ee0ec2748a0461cb4e1996.jpg)

## 確認用でメールが送られてくる

リンクをクリックして認証完了です。

> ![](https://i.gyazo.com/d198efb71bcdb597269cf53398411879.png)

## ログイン

ログインページにリダイレクトするのでログインしましょう。

> ![](https://i.gyazo.com/dd6bf476024677734abb110cca4c9a18.png)

初回ログイン時にアンケートを聞かれますが、適当に回答しても大丈夫です。

> ![](https://i.gyazo.com/4c66ed3f126e8c8e7a60072a3f0eed5c.png)

初回立ち上げで多少読み込みに時間が掛かる場合もあるので、少し待ちましょう。

以下のような画面が表示されればOKです。

> ![](https://i.gyazo.com/bf982567f9732895d8435b6bbbab0558.png)