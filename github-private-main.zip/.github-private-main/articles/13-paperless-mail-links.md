---
title: "ペーパーレス化につながる手法の事例" # 記事のタイトル
emoji: "📜" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["Integromat","アカウント登録","iPaaS"] # タグ。["markdown", "rust", "aws"]のように指定する
published: false # 公開設定（falseにすると下書き）
---

## 印刷する際に便利なサービス
* [Google クラウド プリント](https://www.google.com/intl/ja_ALL/cloudprint/learn/)
* [セブン‐イレブンで簡単プリント ～ネットプリント(個人のお客様)～](https://www.printing.ne.jp/index_p.html)

## 実際の紙とうまく連携している手法やサービス
* [IoTはんこ | ProtoPedia](https://protopedia.net/prototype/1483)
* [InCaaaanインカーン | ProtoPedia](https://protopedia.net/prototype/1386)
* [コクヨのIoT文具「しゅくだいやる気ペン」、1万台以上売れた秘密：あの会社のこの商品（1/4 ページ） - ITmedia ビジネスオンライン](https://www.itmedia.co.jp/business/articles/2102/08/news042.html)
* [HOME - ネオスマートペン](https://www.neosmartpen.com/jp/)

## ペーパーレス化につながる手法やサービス
* [iPhone、iPad、iPod touch で書類をスキャンする方法 - Apple サポート (日本)](https://support.apple.com/ja-jp/HT210336)
* 

## メール連携事例
* [ヤバいくらいアラート発生しTEL！ | ProtoPedia](https://protopedia.net/prototype/2354)


<!-- 
まだメモ

・ペーパーレス化につながる手法の事例（OCR・FAXが使えるAPI・クラウドプリントのAPI）
　→ 授業ではGoogle Cloud Visionを使う予定です、FAXとかクラウドプリントは使わないどころか廃止されてるやつばかりですが参考があればいいなと思ってます
・メール連携事例
　→ ビジネスのやりとりはメールがまだ多いのでチャットツールに移行、ではなく、メール対応は無くせない前提でいかに効率よく自動処理できるか？といった解決策事例がいくつかあれば嬉しいです -->
