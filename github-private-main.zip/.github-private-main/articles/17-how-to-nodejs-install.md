---
title: "Voltaを利用してMacでNode.jsのインストール - homebrewは使わないで！" # 記事のタイトル
emoji: "😅" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["javaScript","Node.js","volta","nvm","homebrew"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

Mac向けにNode.jsのインストール手順を紹介します。

Macの場合、Node.jsは直接インストールするよりも、バージョン管理ツール経由でインストールする方法が一般的です。

ここでは比較的新しめ（2021年9月時点）のVolta経由でのインストール方法を紹介します。

他の方法も調べると出てきますが、 **プロトアウトスタジオの授業を行っていく上で他の方法で進めた場合に、授業で不具合があるケースがある**ので、この手順に従って進めてください。

## Voltaを使ってNode.jsのインストール

https://volta.sh

### 1. Voltaのインストール

まずは[ターミナルアプリ](https://support.apple.com/ja-jp/guide/terminal/apd5265185d-f365-44cb-8b09-71a064a42125/mac)を起動して、以下を入力（コピペでOK）します。

```
curl https://get.volta.sh | bash
```

エンターで実行します。色々と表示が出ますが、

> success: Setup complete. Open a new terminal to start using Volta!

などが表示されれば成功です。完了するとvoltaコマンドが使えるようになります。以下を実行してみましょう。

```
volta -v
```

:::details command not found: volta が表示される方はこちら

パスの設定を行います。ターミナルアプリに以下を入力します。(長くて間違えやすいのでコピペしましょう)

```
echo 'VOLTA_HOME=$HOME/.volta' >> ~/.zshrc
echo 'export PATH=$VOLTA_HOME/bin:$PATH' >> ~/.zshrc
source ~/.zshrc
volta -v
```

:::

時期によって数字は変わりますが、`1.0.5`などバージョンの数字が表示されれば成功です。

ちなみにこの時に`command not found: volta`と表示される場合はターミナルアプリを再起動してから`volta -v`を再実行してみましょう。

> tips: bashではなくzshを利用しているケースでも`curl https://get.volta.sh | bash`で問題なかったです。

### 2. Node.jsのインストール

次にNode.jsの最新版(latest)をインストールします。

```
volta install node@latest
```

最後にNode.jsが入ってるかを確認します。

```
node -v
```

時期によって最新版は変わりますが、`v16.10.0`などバージョンが表示されれば無事にインストールが完了しています。

## 注意喚起！ 公式インストーラ及びhomebrew経由のNode.jsインストールは禁止

以下はコラム的なものなので暇があればお読みください。

Node.jsのインストール方法で調べると、Node.jsの公式インストーラー経由やhomebrew経由でインストールする記事よくみますが**やめましょう！**

マジでhomebrew経由でインストールさせる記事が多すぎて困ります。
homebrew自体は素晴らしい仕組みですが、Node.jsのインストールには使わないようにして下さい。

**nodebrewをhomebrew経由でインストールする記事なども見かけますが、それもNG**です。注意して下さい。

### homebrew経由でインストールしたNode.jsは時限爆弾

voltaやnodebrew、nvm経由でインストールすると以下のようにユーザーのフォルダ(ここではn0bisukeフォルダ)以下にnodeコマンドがインストールされます。

```
/Users/n0bisuke/.volta/bin/node
```

これによってそのユーザーが行えることの権限内で基本全てが完結するため、トラブルが少ないです。

homebrew経由でインストールすると、以下のように`/usr/local/bin`という少しPCの権限がユーザーの権限とは違う場所にインストールされてしまいます。

```
/usr/local/bin/node
```

すぐに問題になる訳では無いですが、特定のnpmモジュールを利用する場合にトラブルが発生するケースが多いです。

`which`コマンドでNode.jsがどこにインストールされているかが分かるので、確認してみましょう。

```
which node
```
