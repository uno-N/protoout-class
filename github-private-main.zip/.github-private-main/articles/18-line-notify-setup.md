---
title: "LINE Notifyの初め方" # 記事のタイトル
emoji: "📱" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["LINE", "LINE Notify", "LINE Bot", "API", "Chat Bot"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

LINE Notifyを利用する際のアカウント設定などを紹介します。

ちなみに、**LINEのアカウントは各自が利用している前提**で話を進めます。

また、2021年9月時点版です。デザインが変更になってる箇所もあるかと思いますので、適宜読み換えて下さい。

## 1. LINE Notifyのアカウントと友達になる。

[LINE Notify](https://notify-bot.line.me/ja/)のサイトにアクセスしましょう。

> ![](https://i.gyazo.com/71df8996f5f261627f88ab4f4dc60543.png)

QRコードが表示されているのでスマートフォンでQRコードを読み取り友達になって下さい。

## 2. LINE Notifyのサイトにログインする

LINE Notifyのサイトの右上にログインリンクがあるので選択して進みます。

> ![](https://i.gyazo.com/f6307ba1c04602294c29acd3add461f4.png)

ログイン情報の入力を求められるので、自身のLINEアカウントの情報を入力しましょう。**新しくLINEアカウントを作成する訳ではないので注意しましょう。**

> ![](https://i.gyazo.com/efe0896c01d9a9bbaef99f232d52e8c7.png)

自身のLINEアカウントの情報が分からない場合は、LINEのスマートフォンアプリから設定を確認出来ます。

右上のメニューからマイページを選択します。

> ![](https://i.gyazo.com/35f438c7248d12c22430eebb012acaee.png)

連携中サービスの文字が表示されたらOKです。

> ![](https://i.gyazo.com/4591eaa80aa57fde473ee755c9543a18.png)

## 3. アクセストークンの発行

ページ下部の`トークンを発行する`ボタンを選択します。

> ![](https://i.gyazo.com/20b17efdfa5184f3da7eecbf38e727ba.png)

次に以下の2つを設定します。設定したら`発行する`ボタンを選択して下さい。

- トークン名: 任意の文字列を入れて下さい。ここではお天気通知用としました。
- 通知を送信するトークルーム: `1:1でLINE Notifyからの通知を受け取る`を選択しましょう。

> ![](https://i.gyazo.com/6753da4f3453563429340acbf863bfa3.png)

トークンというパスワードのような文字列が発行されます。
コピーして控えておきましょう。

> ![](https://i.gyazo.com/f772217e482035c18cb156af18f40566.png)

このトークンを使うことで、様々なツールなどとの連携が可能になります。

ちなみに、発行した際にLINE側にも通知が来ていると思います。

> ![](https://i.gyazo.com/8d6c0c54ee47edea51b1b25d5db58d29.png)

お疲れ様でした。