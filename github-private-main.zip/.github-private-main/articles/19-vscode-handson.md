---
title: "VSCodeの基本操作" # 記事のタイトル
emoji: "📱" # アイキャッチとして使われる絵文字（1文字だけ）
type: "idea" # tech: 技術記事 / idea: アイデア記事
topics: ["VSCode"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

# Visual Studio Codeについて

Visual Studio Code(以下、VSCode)は、Microsoft開発の優れたソースコードエディタです。  
無料でオープンソース、マルチプラットフォーム（Windows, macOS, 各種Linux）で動作します。

- マルチカラム画面で、エディタ・シェル操作・ファイルエクスプローラが統合されている
- JavaScript と Node.js の効率的な操作性
- Gitリポジトリの操作に対応
- シンタックスハイライト
- 拡張機能を追加することで、言語サポートや環境を柔軟にカスタマイズ可能

# 1. 左メニューについて理解する

VSCodeを起動すると、左端にメニューが表示されます。
アイコンのみの表示となっているので、内容を紹介します。

![image](https://i.gyazo.com/2b025672d6cb399810f61eb311cf9d1d.png)

1. エクスプローラ：現在のフォルダの中身を表示します。
2. ファイル検索（基本的に使用しません）
3. Git管理：フォルダがGitリポジトリの場合、差分確認やブランチ切替などができます。
4. Run & Debug（基本的に使用しません）
5. 拡張機能検索：拡張機能を検索して追加することができます。

![image](https://i.gyazo.com/9c455f5e6f33e00844eba66efcfda07c.png)

この時点で、このようにエクスプローラが表示されていない場合はクリックして表示させましょう。


# 2. フォルダをVSCodeで開く

![image](https://i.gyazo.com/be0d383c0d01713fea0b690f08c5e64c.png)

メニュー → Open Folder（開く…）をクリックして、先ほどのフォルダを選択します。

![image](https://i.gyazo.com/ff1e9750a0642a9db32396a82d95b49c.png)

これで、先ほど作成したフォルダの中で作業を行うことができます。

![image](https://i.gyazo.com/01fb4a399edcf4b5c0e8cc058e8bcd5e.png)

# 3. ファイルを作成する

![image](https://i.gyazo.com/f1c102d93042db2cbb3b37c7fa8170fe.png)

New Fileをクリックします。

![image](https://i.gyazo.com/582d658fe02787fedac0d5c3b680992a.png)

ファイル名を入力できるようになります。

![image](https://i.gyazo.com/0fc0d2378e9e32f880dd0d4bc85c9a1b.png)

好きなファイル名を入力します。
ファイル名は基本的に`英数字 + 拡張子`にしましょう。

![image](https://i.gyazo.com/1582315b3f7dcec7806f9312ac706d1b.png)

エディタに作成したファイルが表示されて、編集できるようになります。

# 4. ターミナルを開く

![image](https://i.gyazo.com/2207eff193aeefa16ff6816f74c5762d.png)

メニュー → New Terminal（ターミナル）をクリックします。

![image](https://i.gyazo.com/cd32cb871e44012b3830ec05d44083df.png)

下部にターミナル（Windowsの場合PowerShell）が開きます。
