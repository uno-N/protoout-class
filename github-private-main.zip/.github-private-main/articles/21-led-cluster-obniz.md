---
title: "秋月電子で買ったLEDクラスターランプをobnizで試す" # 記事のタイトル
emoji: "🚦" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["iot", "obniz", "JavaScript", "秋月電子"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

少し前に秋月電子の店先で見つけて **30円**という安さもあり試しに買ったLEDクラスターランプを触ってみました。これをobnizから触ってみます。

## LEDクラスターランプ

こういうやつです。正式型番は`30×30mm RG SQUARE LED CLUSTER`かな? データシートのファイル名だと`JL-CS30AR6G2`とあるのでこっちの方が型番っぽい。


> ![](https://i.gyazo.com/6a444299e19c723e0f6ba97c4578feaa.png)

> http://akizukidenshi.com/catalog/g/gM-06699/

店先に置いてあって面白そうだったので購入してみました。

緑と赤のランプです。

## データシートを読んでみた

秋月電子のサイトに載っているデータシートが[こちら](http://akizukidenshi.com/download/ds/japan/LED_cluster.pdf)です。

> ![](https://i.gyazo.com/6ef6ae5b35e9885ed5490c95922d81a0.png)

色々と英語や中国語で書いてて全部は読めてないですが、ケーブルの色で極性が分かりました。

* 赤 -> -
* 白 -> +
* 緑 -> -

という情報があったのでそれで接続を試してみます。

> ![](https://i.gyazo.com/e21ad657d2d1188b989f727dd96e5aa2.jpg)

> 実際に白赤緑の三つのケーブルが付いてます。


## obnizから利用してみた

電気を流すかGNDにするかの指定だけみたいだったので一旦これで試してみました。

```js
'use strict'

const Obniz = require('obniz');
const obniz = new Obniz(process.env.OBNIZID);

obniz.onconnect = async function () {
    obniz.io0.output(false); //ケーブル赤 io0 -
    obniz.io1.output(true); //ケーブル白 io1 +
    obniz.io2.output(false); //ケーブル緑 io2 -
}
```

```bash
$ OBNIZID=xxxx node led.js
```

特に問題なく起動

> ![](https://i.gyazo.com/edb54b41e1355fc4a157570eba50e201.jpg)

全てのLEDが点灯しました。

## 白が共通の+（アノードコモン）で赤と緑で制御

ケーブルの色をGNDにすることでその色のLEDが点くようになってるみたいです。

* 赤LEDを点灯: 赤- 白+ 緑+
* 緑LEDを点灯: 赤+ 白+ 緑-
* 赤と緑の両方のLEDを点灯: 赤- 白+ 緑-

という感じみたいです。

### 赤LEDのみ

赤LEDのみを点灯させたい場合は、赤のみを-にします。

* 赤 -> -
* 白 -> +
* 緑 -> +

obniz向けのコードだとこんな感じ

```js
'use strict'

const Obniz = require('obniz');
const obniz = new Obniz(process.env.OBNIZID);

obniz.onconnect = async function () {
    obniz.io0.output(false); //ケーブル赤 io0 -
    obniz.io1.output(true); //ケーブル白 io1 +
    obniz.io2.output(true); //ケーブル緑 io2 +
}

```

> ![](https://i.gyazo.com/e6528b06856a89fad4118505194d051c.jpg)

### 緑LEDのみ

緑LEDのみを点灯させたい場合は、緑のみを-にします。

* 赤 -> +
* 白 -> +
* 緑 -> -

obniz向けのコードだとこんな感じ

```js
'use strict'

const Obniz = require('obniz');
const obniz = new Obniz(process.env.OBNIZID);

obniz.onconnect = async function () {
    obniz.io0.output(true); //ケーブル赤 io0 +
    obniz.io1.output(true); //ケーブル白 io1 +
    obniz.io2.output(false); //ケーブル緑 io2 -
}

```

> ![](https://i.gyazo.com/d6482cc5e22ec729a9443f942ef9210f.png)


## パターンを組み合わせてみる

一定時間ごとに点灯パターンを切り替えます。ここまで紹介したパターンをまとめた感じですね。

```js
'use strict'

const Obniz = require('obniz');
const obniz = new Obniz(process.env.OBNIZID);

obniz.onconnect = async function () {
    while (true) {
        //全部点灯
        obniz.io0.output(false); //io0 -
        obniz.io1.output(true); //io1 +
        obniz.io2.output(false); //io2 -
        await obniz.wait(1000);

        //緑だけ
        obniz.io0.output(true); //io0 +
        obniz.io1.output(true); //io1 +
        obniz.io2.output(false); //io2 -
        await obniz.wait(1000);

        //赤だけ
        obniz.io0.output(false); //io0 -
        obniz.io1.output(true); //io1 +
        obniz.io2.output(true); //io2 +
        await obniz.wait(1000);

        //全て消す
        obniz.io0.output(false); //io0 -
        obniz.io1.output(false); //io1 -
        obniz.io2.output(false); //io2 -
        await obniz.wait(1000);
    }
}

```

> [動かした様子](https://twitter.com/n0bisuke/status/1277650887599513601)

## 所感

データシート全然読めてないけど、安くて面白い表現が出来そうなのでLチカよりは楽しそうですね。

ちなみに、8個のLEDを個別で制御出来るのかはよくわかってません。誰か試せたら教えて下さい :)
