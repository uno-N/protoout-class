---
title: "obnizとNode.jsで超音波距離センサ(HC-SR04)を使ってみる" # 記事のタイトル
emoji: "📡" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["iot", "HC-SR04", "obniz", "JavaScript", "距離センサ"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

obnizで超音波距離センサを利用する[公式サンプル](https://obniz.io/ja/sdk/parts/HC-SR04/README.md)を元にNode.jsから実行してみます。

## 使うものやソフトウェア

使うものというよりも、使ったものです。

* [obniz](https://obniz.io)
* [超音波距離センサ HC-SR04](http://akizukidenshi.com/catalog/g/gM-11009/)
* Node.js

## HC-SR04をobnizに配線

obnizにそれぞれ以下を配線します。

> ![](https://obniz.io/ja/sdk/parts/HC-SR04/wired.png)

## Node.jsのコード

通常通り準備です。

```bash
$ mkdir myapp
$ cd myapp
$ npm init -y
```

obnizのライブラリをインストールします。

```bash
$ npm i obniz
```

`app.js`などのファイルを作成しましょう。

[公式サンプルっぽい書き方](https://obniz.io/ja/sdk/parts/HC-SR04/README.md)でやってみます。

```js
'use strict';

const Obniz = require("obniz");
const obniz = new Obniz("obnizのデバイスID");

obniz.onconnect = async () => {
    const hcsr04 = obniz.wired("HC-SR04", {gnd:0, echo:1, trigger:2, vcc:3});
    
    while(true) {
        let avg = 0;
        let count = 0;
        for (let i=0; i<3; i++) { // measure three time. and calculate average
          const val = await hcsr04.measureWait();
          if (val) {
            count++;
            avg += val;
          }
        }
        if (count > 1) {
          avg /= count;
        }
        console.log(avg);
        await obniz.wait(100);
    }
}
```

whileループ内で`obniz.wait(100)`で0.1秒ごとにセンサーの値を測ってます。

```bash
$ node app.js
```

## 動かしてみた様子

こんな感じで動作しました。

> [![](https://i.gyazo.com/cf8b63eceb8462708da62fd01b24a1ba.jpg)](https://www.instagram.com/p/CB7zAY1jwDZ/)

> https://www.instagram.com/p/CB7zAY1jwDZ/


## それ以外の書き方

* `setInterval()`で書いてみる。 (一定時間毎の処理)

```js
'use strict';

const Obniz = require("obniz");
const obniz = new Obniz("obnizのデバイスID");

obniz.onconnect = async () => {
    const hcsr04 = obniz.wired("HC-SR04", {gnd:0, echo:1, trigger:2, vcc:3});
    
    const main = () => {
        hcsr04.measure(distance => {
            console.log("distance " + distance + " mm");
        });
    }

    setInterval(main, 100);
}
```

* `setTimeout()`と再帰で書いてみる。 (一回実行したあとにxxx秒待って同じ関数を実行)

```js
'use strict';

const Obniz = require("obniz");
const obniz = new Obniz("obnizのデバイスID");

obniz.onconnect = async () => {
    const hcsr04 = obniz.wired("HC-SR04", {gnd:0, echo:1, trigger:2, vcc:3});

    const main = () => {
        hcsr04.measure(distance => {
            console.log("distance " + distance + " mm");
        });
        setTimeout(main, 100);
    }

    main();
}
```

その他の書き方やメソッドなどは[公式サンプル](https://obniz.io/ja/sdk/parts/HC-SR04/README.md)を参考にしてみましょう。