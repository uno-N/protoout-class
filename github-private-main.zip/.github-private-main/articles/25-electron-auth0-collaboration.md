---
title: "ElectronでAuth0を使う" # 記事のタイトル
emoji: "💻" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["JavaScript", "Auth0", "Node.js", "Electron"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

## electron-quick-start

electron-quick-start で準備します。

electron/electron-quick-start: Clone to try a simple Electron app
https://github.com/electron/electron-quick-start

```bash
# Clone this repository
git clone https://github.com/electron/electron-quick-start
# Go into the repository
cd electron-quick-start
# Install dependencies
npm install
# Run the app
npm start
```

まずこれでフォルダを整えましょう。

## express を仕込む

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/bf435764-03ee-8d0e-39ce-f9a31dc257b3.png)

### expressインストール

```bash
npm i express
```

### morgan helmet インストール（Auth0用）

```bash
npm i morgan helmet
```

### public フォルダ作成

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/0eb07657-a80d-3f35-0ff8-d6e8d5fd3750.png)

publicフォルダを作ります。

### public/index.html をとりあえずつくる

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/825548b2-5e43-b1d7-a799-400ad85c32f1.png)

public/index.html も作ります。

```html
<html>
  <head>
    <title>Hello Server!</title>
  </head>
  <body>
    <p>Hello, World!</p>
  </body>
</html>
```

ソースはひとまずこちらで。

### main.js 書き換え

```js
// Modules to control application life and create native browser window
const {app, BrowserWindow} = require('electron')
const path = require('path')

// express setting
const express = require('express');
const appExpress = express();
appExpress.use(express.static(__dirname + '/public'));
appExpress.listen(3000);

// Keep a global reference of the window object, if you don't, the window will
// be closed automatically when the JavaScript object is garbage collected.
let mainWindow

function createWindow () {
  // Create the browser window.
  mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js')
    }
  })

  // and load the index.html of the app.
  // mainWindow.loadFile('index.html')
  // ログインページにアクセスして、画面に表示する
  mainWindow.loadURL("http://localhost:3000/" );

  // Open the DevTools.
  // mainWindow.webContents.openDevTools()

  // Emitted when the window is closed.
  mainWindow.on('closed', function () {
    // Dereference the window object, usually you would store windows
    // in an array if your app supports multi windows, this is the time
    // when you should delete the corresponding element.
    mainWindow = null
  })
}

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
app.on('ready', createWindow)

// Quit when all windows are closed.
app.on('window-all-closed', function () {
  // On macOS it is common for applications and their menu bar
  // to stay active until the user quits explicitly with Cmd + Q
  if (process.platform !== 'darwin') app.quit()
})

app.on('activate', function () {
  // On macOS it's common to re-create a window in the app when the
  // dock icon is clicked and there are no other windows open.
  if (mainWindow === null) createWindow()
})

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and require them here.
```

## 起動してみる

```
npm start
```

こちらでうまく動くか調べてみましょう。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/155a9e85-8c74-e423-8e26-64e713e48f39.png)

このように表示されたら、Expressが組み込まれました。

## Auth0の設定取り込み

サンプルファイル自動作成で 素のJavaScriptのVanillaJSログインファイル一式を持っておきます。

### 基本設定はしておく

サンプルファイル自動作成で指示される、Application Settings の Allowed Callback URLs、Allowed Web Origins、Allowed Logout URLsでの http://localhost:3000 の許可設定は忘れないようにしておきましょう。

### auth_config.json 移植

Electron側の最上部のフォルダに、 Auth0サンプル側の ```auth_config.json``` を移動します。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/27c150e4-cf1c-a5a3-98b0-932c200b5c5e.png)

**繰り返しますがElectron側の最上部のフォルダに入れます。**

### publicフォルダに、Auth0サンプル側のpublicフォルダにあるcss,images,jsフォルダを移植

Electron側のpublicフォルダに、Auth0サンプル側のpublicフォルダにある ```css,images,jsフォルダ``` を移植します。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/453a1104-11d1-2012-1d3d-69de974c01ea.png)

### public/index.html は上書き

Electron側の ```public/index.html``` はAuth0サンプル側のpublicフォルダにある ```index.html``` を上書きします。

## 起動します

```
npm start
```

こちらで起動します。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/8016439b-d6e6-d915-de45-721448d9afc6.png)

このように起動します。

## 注意：現状、LINEログインがおすすめです。

現状、LINEログインがおすすめです。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/2c993791-4907-97a5-2428-91f60bfc3889.png)

このようにGoogleアカウントは、ElectronのChromniumアクセスのせいか、弾かれてしまいます。

Auth0利用でなくても、ほかのコンテンツでElectronブラウザでGoogleログイン表示すると同じ画面になるので、ElectronのChromniumブラウザ関連ぽい。
