---
title: "Visual Studio Codeで手軽にAPIを試せる REST Client 拡張の紹介" # 記事のタイトル
emoji: "✏️" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["Visual Studio Code", "API", "REST"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

ProtoOut Studio では、たくさんのAPIとつなぐことで様々技術を知り、発想を広げていくことと大事にしています。

そうなると、自然とAPIを自分で探して、自分の制作にどうやって使えるかを試していく流れになりますが、Visual Studio Code の [REST Client](https://marketplace.visualstudio.com/items?itemName=humao.rest-client) をご紹介します。

## インストール方法

ProtoOut Studio では、 Visual Studio Code を統一したエディタとして使っているので導入しやすいですよ。

![image](https://i.gyazo.com/14ea9be6713913cb598559a17ffb9825.png)

Visual Studio Code の 左メニューから ![image](https://i.gyazo.com/52223cb419c826a5f7e666bd542b207b.png) をクリックして Extenshion を選びます。

![image](https://i.gyazo.com/68e6035cd41092bd73988dab022d5fba.png)

拡張機能をインストールできる EXTENSIONS エリアに移動します。こちらの詳しい操作方法は [Managing Extensions in Visual Studio Code](https://code.visualstudio.com/docs/editor/extension-gallery) に書いてあります。

![image](https://i.gyazo.com/305b2eb16a5601b1ea3fecad10b9ee29.png)

`REST Client` と入力して検索します。

![image](https://i.gyazo.com/c1c7c3faf9301dc0c371120725ca221c.png)

こちらの、REST Clientを探して、Installボタン ![image](https://i.gyazo.com/1b1d36793fbcbb4ebc80ca2dfc016788.png) を押します。

しばらく待っていると、Installボタンが消えてインストールされます。

![](https://i.gyazo.com/22a1c5b6677c63a3f3482352931d420d.png)

右エリアに REST Client の拡張機能の詳細が表示されていて、Uninstall となっていて、つまり、無事インストールされたことを確認しておきます。

これでインストールは完了です。

## テストする .http ファイルを作る

![](https://i.gyazo.com/e3f8fbd7fb07339dc18dadbadfac6a1e.png)

REST Client は、拡張子が ``.http`` か ``.rest`` のファイルの中で動作します。今回は試しにQiitaのREST APIをテストするということで ``qiita-test.http`` というファイル名で新規作成し一旦保存しましょう。

![](https://i.gyazo.com/ae819453f2e00e9e383e9bf9817f82a9.png)

新規作成できたらエディタに書き込んでいきます。書き方は、[HTTP/1\.1: Request](https://www.w3.org/Protocols/rfc2616/rfc2616-sec5.html) に準拠して書きます。

## Qiita API のタグ取得でGETリクエストを試す

Qiita APIにつないでみます。

[Qiita API v2ドキュメント \- Qiita:Developer](https://qiita.com/api/v2/docs#%E3%82%BF%E3%82%B0)

GETリクエストで分かりやすい、タグ取得を試しましょう。

![](https://i.gyazo.com/b73bf378ac27916674db923f3649a4dd.png)

このようにAPIの使い方が書いてあります。

今回は ``JavaScript`` のタグを取得するということで ``https://qiita.com/api/v2/tags/JavaScript`` にGETリクエストしてみます。

![](https://i.gyazo.com/4c7bda517c3769df4ac716829009fbd1.gif)

``qiita-test.http`` に、 ``https://qiita.com/api/v2/tags/JavaScript`` を貼り付けます。

すると、すぐに自動認識され Send Request というクリックできる文字が表示され、テストすることが出来ます。

![](https://i.gyazo.com/1df34f12ee169bcc42e30c889a6cda94.gif)

クリックしたあとの動きです。右側に送信した結果が表示されます。

## httpbin

[httpbin\.org](https://httpbin.org/) という、データを送ってオウム返しでデータが返ってくることでHTTPの送受信を試せるサイトがあります。

こちらに、POSTリクエストをしてみましょう。[HTTP/1\.1: Request](https://www.w3.org/Protocols/rfc2616/rfc2616-sec5.html) に準拠してPOST送信を書いてみます。

```
POST https://httpbin.org/post HTTP/1.1
content-type: application/json

{
    "name": "ProtoOut Studio",
    "category": "school",
    "message": "ProtoOut Studioは日本初のプロトタイピング専門スクールです。"
}
```

このような内容です。

![](https://i.gyazo.com/1a2714f1d4690447f8b7db61eab97be7.gif)

早速、送受信してみます。無事受信できています！

もちろん、最終的に、JavaScriptで取り込むには [axios](https://github.com/axios/axios) を使いますが、このように「お！これは面白そうなAPIだな！試してみよう。」と思ったときに、サッと試したいですよね。一旦、試して、データの内容を眺めて検証も細かく念入りにできるのでaxiosに置きえたときもスムーズになるでしょう。

ぜひインストールして、使いこなしてみてください！

## 参考文献

* より詳細の使い方
    * [VS Code上でHTTPリクエストを送信し、VS Code上でレスポンスを確認できる「REST Client」拡張の紹介 \- Qiita](https://qiita.com/toshi0607/items/c4440d3fbfa72eac840c)
* Postman も人気がありますが Visual Studio Code ですぐに試せるというところで今回は選んでおります
    * [REST API のテストに Postman 使ってたけど Visual Studio Code の REST Client に乗り換えた \- かずきのBlog@hatena](https://blog.okazuki.jp/entry/2019/07/13/121021)
* より高度な使い方の例があります
    * [VS Code拡張「REST Client」の便利機能メモ \- Qiita](https://qiita.com/garcons/items/c4dd7231bc78e7adf0a5)
