---
title: "複数のobnizを一つのコードで管理するときのコツ" # 記事のタイトル
emoji: "✏️" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["obniz", "JavaScript"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---


[ProtoOut LINE Things ハッカソン](https://protoout.connpass.com/event/135942/)で挙がった技術ポイントのひとつ、複数のobnizを一つのコードで管理するときのコツ をまとめました。

電力消費の少ないセンサーやアクチュエータであれば、1つのobnizで複数のピンに挿して上手く動きます。しかし、ソレノイドやモーターといったパーツは電力消費が高く同時に動かすことは難しいです。また、物理的に離れたパーツを動かす場合、同じobnizのピンに挿してしまうと長さの制約が工作面でやりにくくなってしまうので、そういったときも、もしobnizが2つあれば離して動作させることが出来ます。

このように複雑な仕組みを作る上で、obnizを複数動かしたくなる機会が出てきます。今回は、実際のそういったことをobnizでどう実現するかコードでお伝えします。

## サンプル

![2019-08-05_20h47_35.jpg](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/35235373-af25-78b4-28c5-3efe798396b6.jpeg)

例えば、1つ目のobnizでは5秒間カウントを行い、2つ目のobnizでは5秒後にブザーを鳴らすといった仕組みを作ったとしましょう。

Node.jsのコードでは以下のように動かします。

5秒間ディスプレイでカウンする obniz 1つ目のコードです。

```js
const Obniz = require('obniz');

var obniz = new Obniz("0000-0001");
obniz.onconnect = async function () {
  obniz.display.clear();
  obniz.display.print("count start");
  // 1秒ごと5回点滅させメッセージを流す
  obniz.display.clear();  // 1回
  obniz.display.print("count 1");
  obniz.wait(1000);
  obniz.display.clear();  // 2回
  obniz.display.print("count 2");
  obniz.wait(1000);
  obniz.display.clear();  // 3回
  obniz.display.print("count 3");
  obniz.wait(1000);
  obniz.display.clear();  // 4回
  obniz.display.print("count 4");
  obniz.wait(1000);
  obniz.display.clear();  // 5回
  obniz.display.print("count 5");
  obniz.wait(1000);
  obniz.display.clear();  // finish
  obniz.display.print("count finish");
}
```

5秒後にブザーを鳴らす obniz 2つ目のコードです。

```js
const Obniz = require('obniz');

var obniz = new Obniz("0000-0002");
obniz.onconnect = async function () {
  var speaker = obniz.wired("Speaker", {signal:0, gnd:1});
  // displayの実行を2つ目のobnizで行いたい場合は、実行をobniz2起点にする
  obniz.display.clear();
  obniz.display.print("waiting...");
  // waitの実行を2つ目のobnizで行いたい場合は、実行をobniz2起点にする
  obniz.wait(5000);
  // 1000hzの音を鳴らす
  speaker.play(1000);
  // ディスプレイ通知
  obniz.display.clear();
  obniz.display.print("sync Buzzer!");
  obniz.wait(2000);
  // 消音
  speaker.play(0);
}
```

このコードたちを動かした場合、Node.jsで、obniz1.js・obniz2.js 全く同じで実行できればよいですが、手動で行った場合、どうしてもタイミングがズレてしまうでしょう。

### 1つのコードで合わせてみる

同じタイミングで実行させるために、1つのコードで実行できるよう合体させてみましょう。

```js
const Obniz = require('obniz');

var obniz = new Obniz("0000-0001");
obniz.onconnect = async function () {
  obniz.display.clear();
  obniz.display.print("count start");
  // 1秒ごと5回点滅させメッセージを流す
  obniz.display.clear();  // 1回
  obniz.display.print("count 1");
  obniz.wait(1000);
  obniz.display.clear();  // 2回
  obniz.display.print("count 2");
  obniz.wait(1000);
  obniz.display.clear();  // 3回
  obniz.display.print("count 3");
  obniz.wait(1000);
  obniz.display.clear();  // 4回
  obniz.display.print("count 4");
  obniz.wait(1000);
  obniz.display.clear();  // 5回
  obniz.display.print("count 5");
  obniz.wait(1000);
  obniz.display.clear();  // finish
  obniz.display.print("count finish");
}

var obniz2 = new Obniz("0000-0002");  // 2つ目のobniz操作をobniz2で別の呼び出しにする
obniz2.onconnect = async function () {
  var speaker = obniz2.wired("Speaker", {signal:0, gnd:1});
  // displayの実行を2つ目のobnizで行いたい場合は、実行をobniz2起点にする
  obniz2.display.clear();
  obniz2.display.print("waiting...");
  // waitの実行を2つ目のobnizで行いたい場合は、実行をobniz2起点にする
  obniz2.wait(5000);
  // 1000hzの音を鳴らす
  speaker.play(1000);
  // ディスプレイ通知
  obniz2.display.clear();
  obniz2.display.print("sync Buzzer!");
  obniz2.wait(2000);
  // 消音
  speaker.play(0);
}
```

このように記述します。コツは2つ目の obniz は違う変数で宣言して、displayの実行、waitの実行、ブザーの実行を、完全に分離するところです。

実際に動かしてみると、しっかり同期して動いています！

> obniz複数台を一つのコードで動かすサンプル。左側5秒間カウントを行い、右側は5秒後にブザーを鳴らす形で一つのコードで動いてます。
> https://twitter.com/1ft_seabass/status/1158341346861522944?ref_src=twsrc%5Etfw