---
title: "Firebase Realtime DatabaseをNode.jsから動かしてみよう" # 記事のタイトル
emoji: "💾" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["Firebase", "JavaScript", "Node.js"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

本日の授業では、Firebaseの導入を体験しました。

この記事ではFirebaseをNode.jsから動かしてみましょう。

## GitHubからソースダウンロード

[1ft\-seabass/protoout\-01\-07\-src](https://github.com/1ft-seabass/protoout-01-07-src)

まず、今回の記事用のソースをダウンロードしておきましょう。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/5ddd0569-4000-f43b-e414-01877eeed03b.png)

firebaseフォルダにソースファイルが置いてあります。

## 秘密鍵を生成し準備

2019/08/25時点の情報で進めます。サービスアカウントで秘密鍵を生成しダウンロードします。

[サーバーに Firebase Admin SDK を追加する  \|  Firebase](https://firebase.google.com/docs/admin/setup#add_firebase_to_your_app)

こちらを参考に、

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/39fdc2ab-cd53-aa91-cf78-d8472be47dee.png)

まずプロジェクトの設定に行きます。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/3275f84e-6f09-7ba0-be3b-29257fcae30e.png)

サービスアカウントに移動します。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/6c0ef315-6384-9058-d214-958a50638dc2.png)

下部の新しい秘密鍵の生成ボタンを押します。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/fdea74ae-fbe6-5fcf-6d03-1d23e5317059.png)

このように、むやみに公開リポジトリに公開したりしないようにしようねと言われます。理解できたら、キーを生成ボタンを押します。すると、すぐに生成されてJSONファイルがダウンロードされます。この段階では、長めの文字数のファイル名.jsonになっているはずです。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/b41798c4-1c8d-ec54-396e-3d9e85260981.png)

ダウンロードしたJSONファイルをserviceAccountKey.jsonでリネームしてfirebaseフォルダ直下に配置します。

これで準備完了です。

## Realtime DatabaseのページでdatabaseURLを確認

Realtime DatabaseのページでdatabaseURLを確認します。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/3e92bd3b-b9b1-41c2-26e8-584049021d9d.png)

Firebaseコンソールにある、Realtime Databaseの中にあるデータが確認できるページでdatabaseURLを確認します。赤枠のところです。こちらをメモしておきます。

## データを set して体験する

ではいよいよ動かしていきましょう。データを set する体験をします。

```
cd firebase
```

ターミナルでfirebaseフォルダに移動して開始します。

### data_set.js 確認

data_set.jsを確認します。

今回はprotoout/studioというデータ階層に、温度・湿度のダミーデータを保存する仕組みです。

```js
var admin = require("firebase-admin");

// 1. サービスアカウント鍵を生成しserviceAccountKey.jsonでリネームしてfirebaseフォルダ直下に配置
var serviceAccount = require("./serviceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  // 2. Realtime DatabaseのページでdatabaseURLを確認して反映
  databaseURL: "https://<databaseURL>.firebaseio.com"
});

var db = admin.database();
var ref = db.ref("protoout/studio");

var usersRef = ref.child("sensor");
usersRef.set({
    "temperature": 26,
    "humidity": 43
});

ref.on("value", function(snapshot) {
    console.log("value Changed!!!");
    console.log(snapshot.val());
}, 
function(errorObject) {
    console.log("failed: " + errorObject.code);
} );
```

### data_set.js を修正

Realtime Databaseのページで確認したdatabaseURLを

```js
  // 2. Realtime DatabaseのページでdatabaseURLを確認して反映
  databaseURL: "https://<databaseURL>.firebaseio.com"
```

に反映し保存します。

### data_set.jsを動かしてみる

サービスアカウント鍵を生成しserviceAccountKey.jsonでリネームしてfirebaseフォルダ直下に配置出来ているかも確認しましょう。

確認できたら、以下のコマンドで動かしてみます。

```
node data_set.js
```

動かしてみると、

```
value Changed!!!
sensor: { humidity: 43, temperature: 26 }
```

と結果が出るはずです。

FirebaseコンソールのRealtime Databaseのページに戻ると、データツリーが変更されてデータが保存されていることが確認できます。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/ae6c5c25-09ec-d938-7052-af3bde6988ce.png)

## データを push して体験する

次はデータをpushすることで、リスト的にデータを蓄積することも体験します。

### data_push.js を確認する

こちらも data_set.js ののときと同じ databaseURL の反映をします。

```js
var admin = require("firebase-admin");

// 1. サービスアカウント鍵を生成しserviceAccountKey.jsonでリネームしてfirebaseフォルダ直下に配置
var serviceAccount = require("./serviceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  // 2. Realtime DatabaseのページでdatabaseURLを確認して反映
  databaseURL: "https://<databaseURL>.firebaseio.com"
});

var db = admin.database();
var ref = db.ref("protoout/studio");

var usersRef = ref.child("sensorList");
usersRef.push({
    "temperature": 26,
    "humidity": 43
});

ref.on("value", function(snapshot) {
    console.log("value Changed!!!");
    console.log(snapshot.val());
}, 
function(errorObject) {
    console.log("failed: " + errorObject.code);
} );
```

### data_push.jsを動かしてみる

確認できたら、以下のコマンドで動かしてみます。

```
node data_push.js
```

動かしてみると、結果が出たら書き込まれます。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/45c2170c-4351-4a3d-3661-6fe081a7c93d.png)

FirebaseコンソールのRealtime Databaseのページに戻ると、データツリーではsensorListが一つ増えています。ツリー内はランダム値のツリーにデータがぶらさがっています。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/3a487642-4014-9bd8-1d4b-d60675b6e4c1.png)

もう一度実行してみるとリスト上に情報が溜まって蓄積されていきます。

## データを読み出してみる

つづいてデータを読んでみましょう。

### data_once.js を確認する

こちらも data_set.js ののときと同じ databaseURL の反映をします。

```js
var admin = require("firebase-admin");

// 1. サービスアカウント鍵を生成しserviceAccountKey.jsonでリネームしてfirebaseフォルダ直下に配置
var serviceAccount = require("./serviceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  // 2. Realtime DatabaseのページでdatabaseURLを確認して反映
  databaseURL: "https://<databaseURL>.firebaseio.com"
});

var db = admin.database();
var refSensor = db.ref("protoout/studio/sensor");
refSensor.once('value')
  .then(function(dataSnapshot) {
    console.log('refSensor');
    console.log(dataSnapshot.toJSON());
  });
```

### data_once.jsを動かしてみる

確認できたら、以下のコマンドで動かしてみます。

```
node data_once.js
```

動かしてみると、データが取得させて返ってきます。

```
{ humidity: 43, temperature: 26 }
```

このように、Firebase Realtime Databaseは手軽にデータを蓄積できるWEBサービスです。実際にプロトタイプをするときにデータ蓄積や分析といった機能を加える助けになります。

詳しい使い方は、以下の参考文献を見つつ進めてみてください！

* [サーバーに Firebase Admin SDK を追加する  \|  Firebase](https://firebase.google.com/docs/admin/setup#add_firebase_to_your_app)
* [Firebase API Reference  \|  Firebase](https://firebase.google.com/docs/reference)
* [database \| Admin Node\.js SDK  \|  Firebase](https://firebase.google.com/docs/reference/admin/node/admin.database)
