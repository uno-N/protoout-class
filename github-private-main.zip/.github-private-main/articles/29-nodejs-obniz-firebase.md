---
title: "Node.jsでobniz スイッチからFirebaseにデータを保存しよう" # 記事のタイトル
emoji: "❤️‍🔥" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["Firebase", "JavaScript", "Node.js", "obniz"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---


Node.jsでobniz スイッチからFirebase Realtime Databaseにデータを保存してみます。

## 準備

前回の記事、

> [Firebase Realtime DatabaseをNode\.jsから動かしてみよう](https://zenn.dev/protoout/articles/28-firebase-realtimedb-nodejs)

こちらを済ませた firebase フォルダの中で進めます。

## Firebaseにobnizのスイッチ動作を保存する

Firebaseにobnizのスイッチ動作を保存します。

ます、firebase_obniz_switch.js というファイルに以下のソースをコピペします。

[前回の記事](https://protoout.studio/posts/firebase-realtime-database-node-js)と同じように、必要な設定を修正します。

* サービスアカウント鍵を生成しserviceAccountKey.jsonでリネームしてfirebaseフォルダ直下に配置
* Realtime DatabaseのページでdatabaseURLを確認して反映

```js
var admin = require("firebase-admin");

// 1. サービスアカウント鍵を生成しserviceAccountKey.jsonでリネームしてfirebaseフォルダ直下に配置
var serviceAccount = require("./serviceAccountKey.json");

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    // 2. Realtime DatabaseのページでdatabaseURLを確認して反映
    databaseURL: "https://<databaseURL>.firebaseio.com"
});

var db = admin.database();
// protoout/studio/obnizに保存すると決める
var ref = db.ref("protoout/studio/obniz");
// さらにsensorにぶらさげる
var sensorRef = ref.child("sensor");
ref.on("value", function (snapshot) {
    console.log("value Changed!!!");
    console.log(snapshot.val());
    },
    function (errorObject) {
        console.log("failed: " + errorObject.code);
    }
);

// obnizの処理
var Obniz = require("obniz");
var obniz = new Obniz("Obniz_ID");
obniz.onconnect = async function () {
    obniz.display.clear();
    obniz.display.print("Firebase - Obniz Switch");
    obniz.switch.onchange = function (state) {
        obniz.display.clear();
        obniz.display.print("state : " + state);
        // スイッチを押した情報が送られる
        sensorRef.set({
            "type":"switch",
            "state":state
        });
    }
}
```

あとは、obnizの処理をさせるために、

```
var obniz = new Obniz("Obniz_ID");
```

を、動かしたいobniz IDを反映します。

## 動かしてみる

実際に動かしてみます。

```
node firebase_obniz_switch.js
```

![2019-08-25_02h49_08.jpg](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/d6d29038-81ab-460f-536b-b61c6830f41d.jpeg)

スイッチを動かしてみます。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/371e7c23-87f3-7db7-930d-762fc1b2f8d8.png)

実行中のターミナルでは、リアルタイムにデータが送られていることが分かります。

![gif_001.gif](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/21a76343-0d14-537f-0803-5d7a7044bfee.gif)

FirebaseコンソールのRealtime Databaseのページに戻ると、データツリーでもデータの変化がすぐに行われていることが確認できます。

## obniz クラウドで動かしたいときは

今回はNode.jsで動かす方法をお伝えしました。obniz クラウドで動かしたいときは以下の記事、

[obnizでFirebaseと連携するメモ – 1ft\-seabass\.jp\.MEMO](https://www.1ft-seabass.jp/memo/2018/09/11/obniz-meets-firebase/)

を参考にすると良いでしょう。

