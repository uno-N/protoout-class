---
title: "Custom Vision ProjectでエラーでPublishできないときの一つの対処法" # 記事のタイトル
emoji: "🌥" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["Azure", "Custom Vision", "MicrosoftLearn"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

Custom Vision Project側で出来上がったトレーニングをAPI公開（Publish）するときに、 We only support publishing to a prediction resource in the same region as the training resource the project resides in. になってしまうときの、一つの対処法をまとめておきます。

こんなエラー。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/8fcaef60-b191-5825-6810-a9494b9be1e4.png)

## 注意

このナレッジは2019/08/25時点のものです。おそらく今後解消される可能性がありますし、さらに皆さんのお使いの環境では違う結果になるかもしれませんので、ご留意いただいた上で、それでも解決を試みたい方はご参考ください！

## 結論

まず、結論から。

Custom Vision Project側でCustom Vision用リソースグループやCustom Visionリソースを作らず、事前にAzure Portal側でCustom Vision用リソースグループやCustom Visionリソースを作ってから、それらをCustom Vision Project側で指定して進めていくとエラーなくAPI公開（Publish）できました。

## このエラーが起きてしまう状況

[演習: Custom Vision Service プロジェクトを作成する \- Learn \| Microsoft Docs](https://docs.microsoft.com/ja-jp/learn/modules/classify-images-with-custom-vision-service/1-create-custom-vision-service-project) の教材をベースに進めていました。

エラーの起こし方確認しましょう。無料仕様版のリソースを使って進めています。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/556db947-7578-194c-b512-81abe76bf46f.png)

Resourceを作ります。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/d06eadcc-6bfe-a591-06b7-40eb1c39b2b2.png)

Resource Groupも作ります。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/dbeff488-0e37-dd12-4432-c27dda4cb826.png)

New Resource Group は West US 2 をひとまず選択。（これはなんでもよさそう）

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/761894bc-aac3-232f-3364-d0e14d59324a.png)

Kindはそのまま。Locationは、念のため、合わせて West US 2。Price Tier は、無料の F0 を選択。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/9a009d0f-f066-f046-1fa6-ddcada7049dc.png)

以降は下の教材でトレーニングまですすめる。

[演習: Custom Vision Service プロジェクトを作成する \- Learn \| Microsoft Docs](https://docs.microsoft.com/ja-jp/learn/modules/classify-images-with-custom-vision-service/1-create-custom-vision-service-project)

レンブラント6枚だけでも作ったら、一旦トレーニングする。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/23645fae-ae95-7570-8b29-f3fec7088d42.png)

トレーニングできたら Publish する。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/3bbefc78-6017-f0f0-8b93-ce9f450518fb.png)

> Publish Model
We only support publishing to a prediction resource in the same region as the training resource the project resides in.
> 「プロジェクトが存在するトレーニングリソースと同じ地域の予測リソースへの公開のみをサポートしています。」

が、出てしまう。どうしても作れない状況です。

## 解決策

事前にAzure Portal側でCustom Vision用リソースグループやCustom Visionリソースを作ります。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/22ca4ade-28de-3452-a262-2ead10b8d48c.png)

まず、Azure Portalで今回用のリソースグループを作成します。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/509594e9-6757-1583-9865-6392573401bf.png)

つづいて、リソースの作成でCustom Visionを検索します。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/ae22f774-0787-2e92-5fd2-8088d5ff53d7.png)

作成ボタンを押します。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/8f37a16e-86a8-5093-ad2c-0382fa13831c.png)

これで作成完了です。

## 再度、Custom Vision Project側で指定

[演習: Custom Vision Service プロジェクトを作成する \- Learn \| Microsoft Docs](https://docs.microsoft.com/ja-jp/learn/modules/classify-images-with-custom-vision-service/1-create-custom-vision-service-project) から再開します。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/f58e772e-52e5-59c0-20b1-5631116ccad4.png)

先ほどのリソースグループとリソースをCustom Vision Project側で指定して進めていきます。

以降は下の教材でトレーニングまですすめます。

[演習: Custom Vision Service プロジェクトを作成する \- Learn \| Microsoft Docs](https://docs.microsoft.com/ja-jp/learn/modules/classify-images-with-custom-vision-service/1-create-custom-vision-service-project)

トレーニングします。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/141eb336-f57e-ee73-de19-c6005eee0e03.png)

出来上がったら、

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/982e5a9e-8214-8934-7ad1-cd1732833175.png)

Publish します。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/ca674059-9903-9300-3d48-8a656927d41f.png)

無事、作成画面が出てきました。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/3e743895-11bc-3a04-e87d-6dcd8e9578f2.png)

Prediction resource に自動的に？作られたリソースがあるので指定します。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/e3d2405d-d88b-f4c0-33c5-69d2fdf81cd9.png)

Unpublishになって、Prediction URLが出てきます。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/9b1377e2-a9a0-3eba-c93a-c9055b9aeca7.png)

Prediction URLが確認できます。

以降は、以下の演習から再開してサンドボックスからPrediction URLを叩くのもよし、もっと踏み込んで自分でAPIを利用するのも良しです。

[演習 \- HTTP 経由でモデルの予測エンドポイントを呼び出す \- Learn \| Microsoft Docs](https://docs.microsoft.com/ja-jp/learn/modules/classify-images-with-custom-vision-service/5-call-the-prediction-endpoint-curl)

エラー解決の助けとなれば幸いです！
