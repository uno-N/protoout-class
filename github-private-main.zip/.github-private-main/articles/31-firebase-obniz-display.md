---
title: "Firebaseのデータをobnizのディスプレイに反映させる" # 記事のタイトル
emoji: "📺" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["Firebase", "obniz", "JavaScript"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

Firebaseのデータをobnizのディスプレイに反映させます。

今回は

> [Node.jsでobniz スイッチからFirebaseにデータを保存しよう](https://zenn.dev/protoout/articles/29-nodejs-obniz-firebase)

をベースに進めます。こちらで動作している前提です。

## Firebaseのデータの準備

protoout/studio/obniz/display のデータを監視します。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/e9f8cd95-a1ad-fa87-7be6-1d1b8b04fba1.png)

Realtime Database に protoout/studio/obniz/display データを作ります。

## obnizのソースコード

今回、obnizで動作させる ```firebase_data_obniz_display.js``` のソースは以下のようになっています。

```js
var admin = require("firebase-admin");

// 1. サービスアカウント鍵を生成しserviceAccountKey.jsonでリネームしてfirebaseフォルダ直下に配置
var serviceAccount = require("./serviceAccountKey.json");

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    // 2. Realtime DatabaseのページでdatabaseURLを確認して反映
    databaseURL: "https://<databaseURL>.firebaseio.com"
});

var db = admin.database();
// protoout/studio/obniz/display のデータを監視する
var ref = db.ref("protoout/studio/obniz/display");
ref.on("value", function (snapshot) {
        console.log("value Changed!!!");
        console.log(snapshot.val());
        obniz.display.clear();
        obniz.display.print(snapshot.val());
    },
    function (errorObject) {
        console.log("failed: " + errorObject.code);
    }
);

// obnizの処理
var Obniz = require("obniz");
var obniz = new Obniz("Obniz_ID");
obniz.onconnect = async function () {
    obniz.display.clear();
    obniz.display.print("Firebase > Obniz display");
}
```

値を監視しているところはこちらです。

```js
var ref = db.ref("protoout/studio/obniz/display");
```

で狙いを定めて

```js
ref.on("value", function (snapshot) {
        console.log("value Changed!!!");
        console.log(snapshot.val());
        obniz.display.clear();
        obniz.display.print(snapshot.val());
    },
    function (errorObject) {
        console.log("failed: " + errorObject.code);
    }
);
```

で監視しています。

## 動かしてみる

![2019-08-28_11h08_50.jpg](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/ece2a3fa-1c09-7aea-a1ba-b3c1d7d6ab8f.jpeg)

起動するを「----」というあらかじめ設定しているデータがすぐに反映されます。

![image.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/f7b608de-e2f3-9d5f-f661-d251a6c1a3f0.png)

さきほどの Firebase のデータを「Hello obniz」に変更します。

![2019-08-28_11h08_55.jpg](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/83129be1-64c8-4fa5-5c4d-1f057fad0aee.jpeg)

監視された値が変化して obniz のディスプレイに反映されます！

![2019-08-28_11h12_57.jpg](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/56170/f5f3e513-42ca-194b-abf3-3a5fc683f688.jpeg)

ちなみに値に日本語を加えてしまうと、バックエンドでのNode.jsからの実行の場合は日本語フォントが無いため文字化けするので、英数字で行いましょう。（obniz Cloud で実行する場合はブラウザとフロントエンドの力で日本語も表示できます。）
