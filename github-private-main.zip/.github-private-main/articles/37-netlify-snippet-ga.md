---
title: "NetlifyのSnippet InjectionでGoogle Analyticsのタグを仕込む" # 記事のタイトル
emoji: "🏘" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["Netlify", "Google Analytics", "JavaScript", "HTML", "JAM Stack"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---


[Netlify](https://www.netlify.com/)上にホスティングしているWebサイトについてのナレッジです。

先日から何かの不良(Nuxt.jsのビルド設定かなぁ)でGAがトラッキングされていない現象に陥っていて、緊急対応策でこの機能を使ってみます。 (追記: [Nuxt.js+Netlify+Contentfulの環境でアクセストークンエラーになる現象](https://protoout.studio/posts/nuxtjs-netlify-contentful)が原因だったみたい。）

## スニペットインジェクション

Netlifyのビルド機能のPost processingにある機能です。
任意のタグを`</head>の前`か`</body>の前`の箇所に入れ込むことができます。

![](https://i.gyazo.com/8332297898fea0114427cb22c1b3431c.png)

## GAのトラッキングコードを入れ込んでみる

`Insert before </head>`を選択して、名前をGAなど適当に付けます。

スニペッドにはGAのページで発行される以下のようなコードをまるっと入れましょう。

```html
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-xxxxxxxxxxxx"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-xxxxxxxxxxxxx');
</script>
```

![](https://i.gyazo.com/28d06f5bd2d407792f6486b742eefb1b.png)

以上です。簡単ですね。

## 所感

Nuxt.jsでビルドされたHTMLに後からインジェクション出来るのは他の使い方でも使えそうだし、ソースコード触らせないで管理画面だけ別の人に触らせる運用とかにも使えそうな気がしますね。

大元の原因を解明できてないのでなんとかさせたい気持ちですが、取り急ぎはちゃんと読み込めてるから良さそう。
