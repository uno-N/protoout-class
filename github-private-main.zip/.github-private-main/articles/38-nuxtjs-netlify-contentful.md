---
title: "Nuxt.js+Netlify+Contentfulの環境でアクセストークンエラーになる現象のメモ" # 記事のタイトル
emoji: "🏘" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["Netlify", "Nuxt.js", "JavaScript", "HTML", "Contentful"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

> 2019年7月8日に公開された記事の移植です。

## 現象

ローカルで動かすと問題ないけど、Netlify上でデプロイするとうまくいかず。AccessTokenがセットされてない雰囲気のエラーになるやつです。

![](https://i.gyazo.com/b26366b1214291226153889e093bd644.png)

## 環境

* Nuxt.js 2.8
* Node.js 12.6
* Netlify
* Contentful

いわゆるJAM Stackってやつですね。

## 基本構成

### @nuxtjs/dotenvで環境変数を利用

ローカル開発の時は`@nuxtjs/dotenv`を利用して、`.env`ファイル内に以下のようにContentfulのトークンとSPACE IDを格納しておきます。

```.env
CTF_SPACE_ID=xxxx
CTF_CDA_ACCESS_TOKEN=xxxxxxxxxxxxxxxxxxxxxxxx
```

### Netlify側も環境変数を格納

![](https://i.gyazo.com/701a99423a7a3b0b69249547d79cc41a.png)

### plugins/contentful.js

[チュートリアル](https://www.contentful.com/developers/docs/javascript/tutorials/integrate-contentful-with-vue-and-nuxt/)を見るとpluginsにcontentful.jsを作成して読み込ませる記述があります。

```plugins/contentful.js
const contentful = require('contentful')
/**
 * Export the createClient function with
 * the default config
 */
const createClient = () => {
  return contentful.createClient({
    space: process.env.CTF_SPACE_ID,
    accessToken: process.env.CTF_CDA_ACCESS_TOKEN
  })
}

export default createClient
```

ここの`accessToken: process.env.CTF_CDA_ACCESS_TOKEN`の箇所が今回の問題ポイントでした。

これでローカル時は`.env`から、デプロイ時にはNetlifyで設定した環境変数からトークンを読み込んでくれるはずでした。

が、冒頭に載せたキャプチャのようにコンソールにエラーが出ます。
サーバーサイドでビルドしてるのでコンテンツの表示には支障はないですが、気持ち悪い感じ。

## nuxt.config.jsのenvキーで解消

色々調べたり触ったりしてて発見したのが`nuxt.config.js`のenvキーです。

[equinusocio/nuxt-contentful-starter](https://github.com/equinusocio/nuxt-contentful-starter/blob/master/nuxt.config.js#L13-L14)のコードを参考に、envを設定しました。

```nuxt.config.js
module.exports = {
  env: {
    CTF_SPACE_ID: process.env.CTF_SPACE_ID,
    CTF_CDA_ACCESS_TOKEN: process.env.CTF_CDA_ACCESS_TOKEN 
  },
 
省略
```

これを設定することでNetlify側でビルドをしてもエラーが出なくなり、問題が解消しました。

## 所感

Netlify側なのかContentfulのSDKなのか、Nuxt.jsなのかdotenvなのか、今回は対象箇所が多くて原因特定が難しかったです。 その辺の感度上げていきたい。
