---
title: "Visual Studio Codeで開発をはじめよう" # 記事のタイトル
emoji: "🌤" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["Visual Studio Code","javaScript","Node.js"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

ここでは、ダウンロードした **Visual Studio Code**（以下VSCodeとも略記します）を使ってスクリプトを書き、VSCode内のターミナルからそのスクリプトを実行するまでを行います。  
早速「Node.js」を取り扱っていきますが、あまり深く考えず、手を動かして開発手順を覚えていきましょう。

## 1. Visual Studio Code の使い方を覚えよう

VSCodeは、Microsoft開発の優れたソースコードエディタです。  
無料でオープンソース、マルチプラットフォーム（Windows, macOS, 各種Linux）で動作します。

- マルチカラム画面で、エディタ・シェル操作・ファイルエクスプローラが統合されている
- JavaScript と Node.js の効率的な操作性
- Gitリポジトリの操作に対応
- シンタックスハイライト
- 拡張機能を追加することで、言語サポートや環境を柔軟にカスタマイズ可能

### 1-1. 作業の始め方

![image](https://i.gyazo.com/6d6ef49e6838fe612dd526e58a2e8472.png)

`01-01-helloworld` というフォルダ名で新規フォルダを作成しましょう。  
場所はどこでもよいです。（デスクトップなど）  
**フォルダ名は必ず英語で作成**してください。

### 1-2. Visual Studio Code を開きます

VSCodeのアイコンをダブルクリックして開きます。

![image](https://i.gyazo.com/0305aba9c178383447bce85d4a9d6cc2.png)

メニュー → New Window（新しいウィンドウ）で新しくウィンドウを開きます。

![image](https://i.gyazo.com/926c7b822a12e695e8ad64f461c8d58c.png)

つづいて、

![image](https://i.gyazo.com/be0d383c0d01713fea0b690f08c5e64c.png)

メニュー → Open Folder（開く…）をクリックして、先ほどのフォルダを選択します。

![image](https://i.gyazo.com/ff1e9750a0642a9db32396a82d95b49c.png)

これで `01-01-helloworld` フォルダの中で作業を開始できます。

![image](https://i.gyazo.com/01fb4a399edcf4b5c0e8cc058e8bcd5e.png)

### 1-3. 左メニューについて

![image](https://i.gyazo.com/2b025672d6cb399810f61eb311cf9d1d.png)

1. エクスプローラ：現在のフォルダの中身を表示します。
1. ファイル検索（基本的に使用しません）
1. Git管理：フォルダがGitリポジトリの場合、差分確認やブランチ切替などができます。
1. Run & Debug（基本的に使用しません）
1. 拡張機能検索：拡張機能を検索して追加することができます。

![image](https://i.gyazo.com/9c455f5e6f33e00844eba66efcfda07c.png)

この時点で、このようにエクスプローラが表示されていない場合はクリックして表示させましょう。

### 1-4. ターミナルを使えるようにする

![image](https://i.gyazo.com/2207eff193aeefa16ff6816f74c5762d.png)

メニュー → New Terminal（ターミナル）をクリックします。

![image](https://i.gyazo.com/cd32cb871e44012b3830ec05d44083df.png)

下部にターミナル（Windowsの場合PowerShell）が開きます。

### 1-5. ファイルの作成

![image](https://i.gyazo.com/f1c102d93042db2cbb3b37c7fa8170fe.png)

New Fileをクリックします。

![image](https://i.gyazo.com/582d658fe02787fedac0d5c3b680992a.png)

ファイル名を入力できるようになります。

![image](https://i.gyazo.com/0fc0d2378e9e32f880dd0d4bc85c9a1b.png)

`app.js` と入力します。

![image](https://i.gyazo.com/1582315b3f7dcec7806f9312ac706d1b.png)

エディタに `app.js` タブが表示されて編集できるようになります。

### 1-6. ファイルに入力して保存

以下のソースコードを `app.js` に書いてください。

```javascript
console.log('Hello ProtoOut!');
```

![image](https://i.gyazo.com/11683b82c10c7899f924050b66eedb33.png)

タブが ● になっているのは、まだ保存されていないというマークです。

![image](https://i.gyazo.com/875a0bf5b12281d2fc7874e11dd2bc6d.png)

メニュー → Save（保存）を押してファイルを保存します。  
Windowsは`Ctrl+S`、Macは`⌘+S`のショートカットキーで、こまめに保存することを心がけましょう。

![image](https://i.gyazo.com/f074c2d9265e8173ae9b0db62f1eb88b.png)

× マークになると保存済みとなり、クリックすることでファイルを閉じることができます。

### 1-7. 自動保存を有効化

有効にしておくと、ファイルを自動で保存してくれるようになります。  
チェックマークがついていれば自動保存が有効になっています。

[![Image from Gyazo](https://i.gyazo.com/1d52853ea1540133a086281c032e489f.png)](https://gyazo.com/1d52853ea1540133a086281c032e489f)

## 2. ターミナルを使ってみよう

![image](https://i.gyazo.com/a361aad2b4ecc1c381bae235baeb0d34.png)

こちらの赤枠のエリア「ターミナル」で、コマンド入力を実際に行っていきます。  
これ以降、皆さんのPCの環境によっては、**このVSCodeのターミナルでエラーが発生する場合があります**。その際は指示をいたしますので、講師が発言中でも必ず報告いただくようお願いいたします。

### 2-1. ターミナルの役割

[![Image from Gyazo](https://i.gyazo.com/7329089b065b763dc791d4b4eb86a6da.jpg)](https://gyazo.com/7329089b065b763dc791d4b4eb86a6da)

コンピュータと人間とのあいだで情報をやりとりするには、まず「インターフェース」というものが必要になります。図形やボタンなどできれいにわかりやすく作ってあるインターフェースは「GUI」といい、逆に文字だけでシンプルに構成されているインターフェースは「CUI」と言われます。

「ターミナル」は、CUIの1つです。  
どのようなことをしたいのか？　を示す「コマンド文字列」を入力して送信することで、コンピュータに要求を送り、操作することができます。要求に対する答えも、ターミナル上に文字として表示することで人間側に伝えます。

ターミナルはあくまで「インターフェース」つまり操作画面を提供するアプリケーションのことであり、中身で実際に文字を受け取ったり表示させたりしているのは「シェル」という、また別のアプリケーションです。シェルは人間の打ったコマンドを理解し、OSの中枢に直接アクセスすることができる、いわばコンピュータと人間のあいだの仲介者ともいえるアプリケーションです。

シェルは、Windowsの場合は「PowerShell」、macOSの場合は「bash」や「zsh」といったものがよく利用されます。とはいえ1つのアプリケーションですので、もちろん自分で新たにインストールすることも可能です。

#### 2-1-1.  補足: WindowsのCUI

- コマンド プロンプト  
  [Windows10 - コマンドプロンプトの起動 - PC設定のカルマ](https://pc-karuma.net/windows10-open-command-prompt-window/)
- PowerShell  
  [Windows10 - PowerShellを起動する方法（管理者も） - PC設定のカルマ](https://pc-karuma.net/windows-10-powershell/)
- Windows Terminal  
  [ついに完成「Windows Terminal」の機能と使い方まとめ：Windows 10 The Latest - ＠IT](https://www.atmarkit.co.jp/ait/articles/2005/28/news018.html)

### 2-2. コマンド実行してみよう

ターミナルに実際に基本的なコマンドを打ち込み、結果を表示してみます。

#### 2-2-1.  pwd

pwd コマンドは positioning working directory の略で、現在作業しているディレクトリのフルパス（ファイル・フォルダの位置）を出力するコマンドです。  

```bash
pwd
```

というコマンドを実行すると

```bash
C:\Users\****\
```

といったような実行結果が返ってきます。これは Windows の例です。  
ここは皆さんの実行しているディレクトリ（フォルダ）によって変わります。

#### 2-2-2.  ls

ls コマンドはディレクトリの内容を表示するコマンドです。  
主に、特定のディレクトリにあるファイル一覧を知りたいときに使います。

```bash
ls
```

というコマンドを実行すると

```bash
-a----       2020/04/27     21:26             29 app.js
```

といったような実行結果が返ってきます。これは Windows の例です。

#### 2-2-3.  cd

cd コマンドは change directory の略で、現在の作業ディレクトリを変更するコマンドです。  

>「ディレクトリ」と「フォルダ」は、文脈によって呼び方が変わる場合がありますが、基本的には同じ意味です。  
> CUI環境やファイルシステムに関する話題では「ディレクトリ」、それ以外のGUI環境では「フォルダ」と呼ばれることが多いです。

![image](https://i.gyazo.com/f216b2c90a7b6c77860aa0d24ff6d57f.png)

エクスプローラから新しいディレクトリ newfolder を作ります。

![image](https://i.gyazo.com/63b1b824fe6083ae8867a33ff9b838de.png)

フォルダが作成されたか確認します。

```bash
pwd
```

で、 `01-01-helloworld` の一番上の階層にいることを確認したうえで、

```bash
cd newfolder
```

というコマンドを実行すると、`01-01-helloworld` から `01-01-helloworld/newfolder` に移動します。  
`pwd` コマンドをもう一度実行し、確かめてみましょう。

確認ができたら、

```bash
cd ..
```

というコマンドを実行してみましょう。`..` というのは、一つ上のディレクトリ階層のことを示します。もう一度`pwd`を実行し、もとのディレクトリに戻っていることを確認しましょう。

### 2-3. nodeコマンドでapp.jsを実行してみよう

#### 2-3-1.  先ほどの app.js の確認

`01-01-helloworld` の app.js をもう一度クリックして内容を見てみましょう。

![image](https://i.gyazo.com/f0916019f65b4763d30ccd424e7b84cf.png)

このファイルは、実体としては「テキストファイル」ですが、中身は「Node.jsで実行可能なスクリプトファイル」となっており、それを示すための「.js」という拡張子がファイル名につけられています。

```javascript
console.log('Hello ProtoOut!');
```

#### 2-3-2.  実行してみる

ターミナルで「app.jsに記述された内容をNode.jsで実行する」コマンドを入力、Enterを押します。

```javascript
node app.js
```

[![Image from Gyazo](https://i.gyazo.com/7d8df1510991fcd762e97ec7d5434b62.jpg)](https://gyazo.com/7d8df1510991fcd762e97ec7d5434b62)

コマンドはこのような形式になっています。  
Node.js以外でも、アプリケーションによりますが、ターミナルで何かしらを実行するときはこのような形式になっていることが多いですので、覚えておいてください。  

「node」は、Node.jsにおいては固定ですが、「app.js」は、今後はみなさんがご自身で作成したファイルの名前と置き換えて使っていくようにしてください。現在のディレクトリ位置との関係も忘れずに。

![image](https://i.gyazo.com/f4a0e180da0cdd09733a9f5043b0e96e.png)

このように `Hello ProtoOut!` と表示されればOKです！
