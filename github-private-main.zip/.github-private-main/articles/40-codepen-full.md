---
title: "CodePenで作成したページを大きいサイズで表示する" # 記事のタイトル
emoji: "🖋" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["codepen", "html", "css", "javascript"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

## Penにはエディタが表示される

CodePenの`Share > Copy Link`でコピーできるURLは、下記のようなエディタが表示されてしまいます。
コードを読んでもらいたい場合には良いですが、ページだけを見てもらいたい場合には少し邪魔ですね。

[![Image from Gyazo](https://i.gyazo.com/f074137af389a9abd6f5997e82735212.png)](https://gyazo.com/f074137af389a9abd6f5997e82735212)

そこで、フルサイズビューのURLを発行する方法を紹介します。

## フルサイズビューで表示する

ページ下部の`Open Live View in a New Window`ボタンをクリックします。

[![Image from Gyazo](https://i.gyazo.com/2127435d644ccc621f7f815a1369a219.png)](https://gyazo.com/2127435d644ccc621f7f815a1369a219)

> ちなみにフリープランでは、Live ViewではなくFull Page Viewになります。

以下のようなフルサイズのビューが表示されます。

[![Image from Gyazo](https://i.gyazo.com/640fbf9b1f98ed4bbee788c9152f591b.png)](https://gyazo.com/640fbf9b1f98ed4bbee788c9152f591b)

CodePenのヘッダーは残りますが、画面が大きく表示されます。
こちらのURLをコピーして、記事で利用しましょう。
