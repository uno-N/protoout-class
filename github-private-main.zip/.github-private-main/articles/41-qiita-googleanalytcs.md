---
title: "QiitaでGoogle Analyticsを利用しよう" # 記事のタイトル
emoji: "🗒" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["Google Analytics", "JavaScript", "HTML"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---


## QiitaへのGoogle Analitics(GA)を導入方法

Qiitaでは[Google Analitics](https://ja.wikipedia.org/wiki/Google_Analytics)(GA)を導入することで、noteはデフォルトのダッシュボードでデータの分析が可能です。


- 下記の記事を参考に測定IDを取得し、QiitaでGoogleアナリティクス設定を行なってください。

  1. [GA4での測定ID取得手順 | ZennでのGoogleアナリティクス(GA4)の設定方法](https://zenn.dev/masakiyo/articles/76ca3b774c6746#ga4%E3%81%A7%E3%81%AE%E6%B8%AC%E5%AE%9Aid%E5%8F%96%E5%BE%97%E6%89%8B%E9%A0%86)
      - 上記の記事では、`GA4での測定ID取得手順`以降の手順のみを実施し、`測定ID`を取得してください。
      - 途中で設定する`ウェブサイトのURL`は`qiita.com`としてください。
      - ZennのGoogleアナリティクス設定は行わなくて大丈夫です。
      
  2. [QiitaのGoogle Analytics設定ページ](https://qiita.com/settings/analytics)を開き、取得した測定IDを貼り付けてください。
      - [![Image from Gyazo](https://i.gyazo.com/13ba70ebcc045aca271ce38da7831600.png)](https://gyazo.com/13ba70ebcc045aca271ce38da7831600)
      
  3. 設定は以上で完了です！
  
- 過去に投稿したQiita記事を開き、そのままGAの`リアルタイム`レポートを開きます。
  - 少し待つとデータが更新されるので、`過去30分間のユーザー`が1人以上になっていることを確認してください。
  - [![Image from Gyazo](https://i.gyazo.com/5d1bedbebbbd49af46bf3704dfdc8bf8.png)](https://gyazo.com/5d1bedbebbbd49af46bf3704dfdc8bf8)
  - Qiita記事を開いてからGAにデータが表示されるまでラグが発生することがあります(長くて1〜2分)。
    - 少し待っても`過去30分間のユーザー`が増えない場合は、Qiita記事・GAを何度かリロードしてみてください。
    - それでも解決しない場合はQiitaでのGA設定がうまくいっていない可能性が高いです。設定手順を見直した上で、講師にご相談ください。
    
- note記事の分析には、ダッシュボードを利用します。
  - 利用開始の設定は不要です。
  - [ダッシュボードでアクセス状況をみる – noteヘルプセンター](https://www.help-note.com/hc/ja/articles/360010324194-%E3%83%80%E3%83%83%E3%82%B7%E3%83%A5%E3%83%9C%E3%83%BC%E3%83%89%E3%81%A7%E3%82%A2%E3%82%AF%E3%82%BB%E3%82%B9%E7%8A%B6%E6%B3%81%E3%82%92%E3%81%BF%E3%82%8B)


