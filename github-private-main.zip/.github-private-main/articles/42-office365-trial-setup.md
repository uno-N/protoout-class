---
title: "Office 365 E3 試用版のアカウントセットアップ" # 記事のタイトル
emoji: "🚵‍♀️" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["Office365","Power Automate","Power Apps"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

> 2021年12月18日時点の情報に少し追記しています。画面が変わってる箇所などがあれば適宜読み替えて下さい。（2022/10/20更新）

無料でPower AutomateやPower Appsの利用を試すにあたり、`Office365 E3 試用版`のアカウント作成をする必要があります。

## 0. 前準備 - シークレットモード

ブラウザのシークレットモードでアカウント作成やログインをしましょう。

過去にOffice365のアカウントを作成したりログインしたことがある場合、ブラウザに情報が残っていて、挙動がおかしくなる場合もあるので、**シークレットモードでの作業を強く推奨します。**

> 参考: [シークレット ブラウジング](https://support.google.com/chrome/answer/95464?hl=ja&co=GENIE.Platform%3DDesktop)

## 1. メールアドレスの取得

`Office365 E3 試用版`のアカウント作成は、GmailやYahooメールのようなアドレスでは利用できませんが、TEMPMAILというサービスで取得したメールアドレスであれば利用することが可能です。

> ![8b2f234a103d7fc54929d8460b90a8e5.jpg](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/19433a01-7c1b-8a8e-e579-7e06fee41057.jpeg)
> https://temp-mail.org/

[TEMP MAIL](https://temp-mail.org/)にアクセスし、表示されたメールアドレスをコピーしましょう。


## 2. Office365 E3 試用版の登録

[Office 365 E3のページ](https://www.microsoft.com/ja-jp/microsoft-365/enterprise/office-365-e3)にアクセスし、「無料試用版」をクリックしてください。

> ![](https://i.gyazo.com/d04c7fb2365c270d30a0e051ba1cc6de.png)

次に進むと、情報を入力する画面が表示されるので、このメール欄に先ほどのTEMP MAILでコピーしたアドレスを張り付けます。

> ![aa274a9c9411d78ac6cf33ebfbdd8e70.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/c480980c-a1bf-aab0-c0a2-c9d9eed8429c.png)

「アカウントのセットアップ」をクリックして進めます。

> ![6195b067079a66df716cf6b65219e587.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/88138682-54a0-0efe-bfb1-dfe75fa318c6.png)

`アンケートのお願い`という項目も埋めていきます。

名前や会社名、規模などは適当で大丈夫です。

勤務先の電話番号は`自分の携帯番号`を入力しましょう。

> ![b52294cfad8922d050861037907d555c.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/7f619085-fef7-e900-1f14-cbdf6d8244fd.png)

このように入力を進めます。

> ![bf715afcb9d35ff37607887d94ed25e4.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/bddfb4b0-93a9-35e8-2b00-d81794f1facc.png)

記入し終わり「次へ」をクリックするとこのような画面が出てきます。

「自分にテキストメッセージを送信」にチェックを入れて、自分の電話番号を入力して「認証コードを送信」のボタンをクリックします。

> ![eb5e13275786304fe5893c3148c3ecbe.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/27b511bc-fe38-5eeb-07ab-182f88202401.png)

そうすると自身の携帯電話に認証コードがMicrosoftからのメッセージとして届いていると思うので、その番号を入力します。

> ![Inkeddeede5f04bf56ab55ad692efa50cef18_LI.jpg](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/3fc1d1cb-ed8f-4015-b868-e82c325b780f.jpeg)

次にユーザー名とパスワードの設定です。

ユーザー名とドメイン名は、なんでも大丈夫なのですがわかりやすいように、
お名前＋作成した日付などを入力することをオススメします。

> ![7ac704eb0884309b1f195b6f8e3287fd.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/1c7bcc2a-f99b-3ac5-92bf-72f488792cdb.png)

パスワードは大文字、小文字、数字が入っている必要がありますので注意してください。

チェックボックスはどちらも外してしまって大丈夫です。

> ![fb1b2aa1fe989d8f0084a0f91ec997c7.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/91655b30-4e02-4adb-c110-78df002b2f11.png)

ちなみに、すでに利用されていて使えない文字列ですと、このようにエラーメッセージがでるので別の文字列に変えてみてください。

> ![9ae9612088cfe15b4ea2451ae581e721.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/ff7a1be0-de77-a5ce-c265-a4dca2a08f27.png)

最後に`次へ`を選択します。

> ![](https://i.gyazo.com/6754fad8c1f373577c0a6b7c156280f6.png)

上手くいくと`アカウントを作成しています。`といった表示になります。

少し待ちましょう。

> ![ab4d48bb7ee0c58c6f9892df2e50fb3d.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/aac38405-de82-58ab-2317-138362a3bed3.png)

この際に **「数量と支払い」** という画面が表示されます。

<!-- > ![Inked5c6cece2231e5c8559b7bac7c37e47a8_LI.jpg](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/f49fbba0-6387-32d0-ed96-12bdabac791a.jpeg) -->

クレジットカードなどの登録をしないといけないのかと焦りますが、この時点でアカウント作成は終了しているので、とくにクレジットカードの登録などはせず**無視して大丈夫です。** 

ここで止めると勝手に請求されることなどもありません。

※Power Appsを使う場合は、この手順で大丈夫でしたが、エクセルなどを利用するためにはクレジットカードの登録までが必要そうでした。

> ![](https://i.gyazo.com/cbd8ada784ffa33ce708e16546865bee.png)

**「数量と支払い」** の画面はとくに操作せず、ブラウザの別のタブなどで[Officeのホーム画面](https://office.com/)にアクセスしましょう。

以下のような画面が開けたら完了です。

> ![](https://i.gyazo.com/29935a573cdef6230eeb3d31fb76d8ff.png)

これで`Office 365 E3試用版`のアカウント作成は終了です。
