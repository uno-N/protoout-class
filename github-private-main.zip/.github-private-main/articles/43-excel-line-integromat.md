---
title: "Excelを編集したらLINEに通知する仕組みを作る" # 記事のタイトル
emoji: "📲" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["Office365","Integromat","LINE","Excel"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

> 2022年1月5日時点の情報です。画面が変わってる箇所などがあれば適宜読み替えて下さい。

## 1. Integromatを用いて接続

Integromatを用いてExcelとLINEを接続してみます。

**Excelが変更されるとLINEに通知をする仕組み**を作ります。

```
Excel ---(Integromat)--> LINE
```

Integromatはサービスとサービスをプログラミング無しで連携させるサービスです。

ノーコードやiPaaS、RPAといったキーワードで紹介されることが多いサービスとなっています。

## 2. アカウントの準備

### Integromatの登録

Integromatのアカウントを作成します。

https://zenn.dev/protoout/articles/12-integromat-signup

### Office 365

Excelを利用するためにOffice 365のアカウントを作成します。

以下のどちらかでアカウント作成をしましょう。既にアカウントがある方は既存所持しているアカウントでも（おそらく）大丈夫です。

- E3の試用版アカウントを作成する

https://zenn.dev/protoout/articles/42-office365-powerapps-login

- 個人の無料版を作成する

https://zenn.dev/protoout/articles/14-office365-account-setup

### LINE Notify

LINE NotifyというLINEに通知を行える仕組みを利用します。

https://zenn.dev/protoout/articles/18-line-notify-setup

## 3. ExcelデータとOneDriveフォルダの準備

こちらを参考に、利用したいExcelファイルの準備とOneDriveのフォルダを準備しましょう。

Excelファイルは忘れずにテーブル化して下さい。

https://zenn.dev/protoout/articles/44-office365-excel-onedrive

## 4. Integromatで連携

Integromatを使ってExcelとLINEの連携をしていきましょう。

### 4-1. Integromatでシナリオ編集画面を開く

Integromatにログインをしたら、このような画面になります。

※初回ログイン時のみ、英語でアンケートの回答を求められますが、適当に回答して大丈夫です。

右上の`Create a new scenerio`を選択しましょう。

> ![](https://i.gyazo.com/af49aeb3316f32cb9f0e92afbc00f41a.png)

そうすると以下のような画面になります。

> ![](https://i.gyazo.com/68fd10a56b15e2f27481ebab535f4ef6.png)

### 4-2. Excelの連携

真ん中の+ボタンを押すと、色々なサービス名が表示されるウィンドウが出てきます。検索ボックスに`Excel`と入れると候補が絞り込まれるので`Microsoft 365 Excel`を選択しましょう。

> ![](https://i.gyazo.com/cba0e92b29231278232232ba24236ca7.png)

> ちなみにMicrosoft 365は古い呼び方な気がしてますので、そのうちOffice 365にここの表示が変わるかもしれません。

次に`Watch Worksheet Rows`を選択します。

> ![](https://i.gyazo.com/990741103bcfaea6d0199c3fea7d788b.png)

次にOffice 365のアカウントの認証をします。Addボタンを押しましょう。

> ![](https://i.gyazo.com/bdb6ea4623222666a99f14c3c205802b.png)

`コネクション名`を入力するフォームが表示されるので、任意の名前を入力して`Continue`を選択します。

> ![](https://i.gyazo.com/859ba52a8501288c7db70d05829a8b70.png)

Office 365のアカウントにログインをさせるウィンドウが出てくるのでExcelの準備などをしたアカウントでログインします。

> ![](https://i.gyazo.com/3fc3a5d87105582479efd01d5bb3eb7a.png)


IntegromatがExcelなどのデータにアクセスすることの許可を求められますので`承認`しましょう。

> ![](https://i.gyazo.com/063b5f962ba2b91f532371444d2dc0fa.png)

元のIntegromatの画面に戻るので、`Workbookの項目をクリック` > `作成したフォルダを選択` > `作成したエクセルファイルを選択` と進めます。

> ![](https://i.gyazo.com/7ec9fd62f4f71dfebe835ecce0a99847.png)

次にWorkSheetの項目でシートを選択します。
デフォルトのままであればSheet1が候補に出てきます。

Limitは2のままで大丈夫です。
OKを押して進みましょう。

> ![](https://i.gyazo.com/e770f7c34c13d9515634b487a9bceb7c.png)

最後に`Choose where to start`の選択肢は`All`にして進みます。

> ![](https://i.gyazo.com/5a1fe8be49c4784354ece47a0536d998.png)

これでIntegromat上でExcelを利用する準備が出来ました。

### 4-3. LINE Notifyの連携

次にLINE Notifyの連携です。

右下の`+ボタン` > `LINEで検索` > `LINEを選択`と進みます。

> ![](https://i.gyazo.com/b034aeaaddd930a2518d6eb4a4697565.png)

次に`Send a Notification`を選択します。

> ![](https://i.gyazo.com/d37b0185d3a340c05a06942cb43efdeb.png)

この時点で、以下のように二つのサークルが線で接続されているか確認し、接続されてない場合はドラッグ&ドロップで接続して下さい。

> ![](https://i.gyazo.com/6132304ebd80e2c969cdb31aca7c45b6.png)

`Addボタン` > `Connection nameに任意の名前を入力` > `Continue` と進みます。

> ![](https://i.gyazo.com/776a1847386636717b41b242529a5239.png)

LINEアカウントへのログインウィンドウが表示されるので、自身のアカウントでログインしましょう。

> ![](https://i.gyazo.com/95dabf9155e787c3359dfce4217049e4.png)

`1:1でLINE Notifyから通知を受け取る`を選択します。

> ![](https://i.gyazo.com/919958728ac0243698c67dbc7ab2ff06.png)

下にスクロールすると同意ボタンがあるので選択します。

> ![](https://i.gyazo.com/c15f9947c1f823e6960f0feccba9f9ca.png)

LINE Notifyのアカウントから以下のような通知がきていれば連携成功です。

> ![](https://i.gyazo.com/684f31eecb9934a74f70c007b42a3a99.png)

連携が完了すると

Messageの箇所にどんなメッセージを送信するかの候補が出てきます。

候補を選択しつつ、任意のテキストも入力し、以下のように設定してみましょう。設定出来たらOKで進みます。

> ![](https://i.gyazo.com/0933610891477752586ef67a3ffdc386.png)

これでLINE Notify側の設定も完了です。

### 4-4. 動かして試してみる

左下の`Run Once`を押すことで試すことができます。

> ![](https://i.gyazo.com/d955acc7686ee4cd1626146eedc15537.png)

Run Onceを押した状態で、Excelにデータが追加されるとLINEに通知がいきます。

> ![](https://i.gyazo.com/e10d992a5a93fb4b8cb05b6d2feafce8.png)

ここまでお疲れ様でした。

## 5. スケジュール実行

ここまでの手順だとRun Onceを手動で押さないと動作してくれません。

最後に、作ったこの連携の仕組みを自動的に動作するように設定します。

といっても、左下のスケジュールをONにするだけです。

> ![](https://i.gyazo.com/63906c01c8b7976efd577f37349cf125.png)

Integromatの無料プランだと15分間隔がミニマムな模様です。

**15分に一回Excelファイルの更新をチェックして、更新があればLINEに通知をしてくれる仕組み**が出来ました。

お疲れ様でした。