---
title: "他サービスとの連携用にExcelとOneDriveの準備をする" # 記事のタイトル
emoji: "🚘" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["Office365","OneDrive","Excel","Power Apps", "Power Automate"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

> 2022年1月5日時点の情報です。画面が変わってる箇所などがあれば適宜読み替えて下さい。

Power AppsやPower Automate、Integromatなど他サービスからExcelのデータにアクセスできるようにするための手順を紹介します。

## 1. Office365にログイン

作成したOffice365アカウントでログインしましょう。

> ![1c3aeff4b261ff17737b29dc4e3058c5.jpg](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/75fbf682-c5ba-d864-e2db-7a3b34c0806b.jpeg)

ログインすると以下のような画面になります。

> ![68747470733a2f2f71696974612d696d6167652d73746f72652e73332e61702d6e6f727468656173742d312e616d617a6f6e6177732e636f6d2f302f33353338372f61353966323463642d333364332d666339622d666363622d3364353533363238653763352e706e67.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/dda7f240-4cd0-ed05-fd6f-28f3db2b31f8.png)


### ※アカウント作成がまだの人

Office365のアカウント作成をしていない人は以下を参考にアカウント作成を行いましょう。

- E3の試用版アカウントを作成する

https://zenn.dev/protoout/articles/42-office365-powerapps-login

- 個人の無料版を作成する

https://zenn.dev/protoout/articles/14-office365-account-setup

## 2. エクセルを起動

左のメニューからエクセルを選択します。

> ![68747470733a2f2f71696974612d696d6167652d73746f72652e73332e61702d6e6f727468656173742d312e616d617a6f6e6177732e636f6d2f302f33353338372f39303831333630332d346338392d633534312d633166362d6661653138613037303237642e706e67.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/23859f12-6c28-4564-b6ec-ceac796e5320.png)

新しい空白のブックを選択しましょう。

> ![68747470733a2f2f71696974612d696d6167652d73746f72652e73332e61702d6e6f727468656173742d312e616d617a6f6e6177732e636f6d2f302f33353338372f32323961633162652d316462322d343930372d303238332d6639353938626637333939612e706e67.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/836a6a52-5b37-9bbd-bc6a-96c348d79582.png)

エクセルが起動します。プライバシーオプションのウィンドウが表示されたら閉じるを押しましょう。

> ![68747470733a2f2f71696974612d696d6167652d73746f72652e73332e61702d6e6f727468656173742d312e616d617a6f6e6177732e636f6d2f302f33353338372f39666164393030312d333532622d363130302d656466352d6631363633386661656538312e706e67.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/ca62871b-e899-dde2-216d-50a5cbc846ed.png)

## 3. データの準備

Excelを起動したらデータを定義します。

ここでは、買い物メモアプリケーションを作成する際の例を紹介します。

`1行目にデータのフィールド名`（以下の画像だと、商品名/在庫数/単価）、`2行目以降に実際のデータ`（以下の画像だと、りんご/30/100など）を入力します。

> ![](https://i.gyazo.com/3b7435df66944050066ba5b0f26f7eb5.png)

## 4. データのテーブル化

作成したデータをテーブル化させます。

**テーブル化をしないままだと他サービスとの連携で利用できないので注意しましょう。**

`作成した範囲を選択 -> メニューの挿入 -> テーブル`のボタンを押します。

> ![](https://i.gyazo.com/18cae44b7d33b6cea14c255e5f06b053.png)

先頭行をテーブルの見出しとして使用する。にチェックを入れてOKで進みます。

> ![485eb302b9e2189ba3da920c07fcae2d.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/5fdaf600-db00-dc03-91d9-0abb6d3ba70f.png)

Excelの準備はこれでおしまいです。

## 5. OneDriveに共有フォルダを作成

OneDriveで任意のフォルダを作成し、先ほどの手順で作成したExcelファイルをフォルダ内に移動させます。

OneDriveを開きましょう。

Excelの`左上のメニューボタン（9つのマスが並んでるような）`を押してOneDriveを選択します。

> ![74839c69cbe4127d850cf0aee167c7cf.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/3eb7c347-66d1-829f-0ead-9a9b8c05a568.png)

> ![3a857e5bded10da865238e5eb9931b4b.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/dee2f6a4-d484-0eb6-f067-c450c480be32.png)

OneDriveを開くことができたら、**Excelのタブは閉じましょう**

<font color="Red">**注意**
 Excelを開いたままだと他サービスとの連携の際にうまく読み込みができない場合があるので閉じるのを忘れないようにしましょう。
</font>

OneDriveを開くと（特に指定してない場合）`ブック.xlsx`などのファイル名で先程のExcelファイルが保存されていることが分かります。

`新規 -> フォルダー`を選択します。

> ![68747470733a2f2f71696974612d696d6167652d73746f72652e73332e61702d6e6f727468656173742d312e616d617a6f6e6177732e636f6d2f302f33353338372f34643433613235342d333832352d343333362d323565612d3532303064643534373538312e706e67.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/13ca8ac6-84af-3eb0-7289-cb577e3d4fcd.png)

任意のフォルダを作成します。

> ![](https://i.gyazo.com/d35218f25040dae72a474b0b78640d40.png)

作成されるとフォルダが追加されます

> ![](https://i.gyazo.com/f5d768ec9c0288eab2685ff47b32f6de.png)

Excelファイルを作成したフォルダにドラッグ&ドロップで移動させます。

> ![ダウンロード.gif](https://i.gyazo.com/f1942e2a8bba7f77ffda66102b9d26f8.gif)


移動できたら完了です。

### OneDriveのTips

先ほど作成したエクセルファイルが保存されるクラウド上の保存領域（ストレージ）がOneDriveになります。

Office365では作成するファイルは特に指定しない限り、自動的にOneDriveに保存されます。

Microsoft版のGoogle DriveやDropboxだと思ってください。
