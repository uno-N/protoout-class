---
title: "ExcelとNode-REDを連携する" # 記事のタイトル
emoji: "🔌" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["Office365","Node-RED","Excel","Power Apps", "Integromat"] # タグ。["markdown", "rust", "aws"]のように指定する
published: false # 公開設定（falseにすると下書き）
---

> 2022年1月8日時点の情報です。画面が変わってる箇所などがあれば適宜読み替えて下さい。

Integromatを経由してOffice365のExcelとNode-REDを連携させる方法を紹介します。

## 1. IntegromatやExcelの準備

こちらの資料をもとにIntegromatでExcelを使えるようにしておきましょう。

https://zenn.dev/protoout/articles/43-excel-line-integromat

以下の手順では、Integromat上でExcelのモジュールを連携させたところからスタートします。

## 2. Node-REDでサーバーを作成

Node-REDでHTTP通信を行えるサーバープログラムを作成します。

ここでは[enebular](https://enebular.com)というNode-REDを内包しているサービスの画面をベースに紹介していきます。

Node-REDが何か、使い方の基礎は割愛します。

まずは

- `http in`
- `http response`
- `debug`

の各ノードを以下のように配置します。

> ![](https://i.gyazo.com/5471ee9b9b2c014d2fb757fc4ddb91e1.png)

`http in`のノードをクリックし、URLの箇所に`/protoout`などと入力します。この文字列は任意の文字列で大丈夫です。（**パス**と呼びます。）

`完了`を押しましょう。

> ![](https://i.gyazo.com/f2729d55f6445525becf580a6ab61ee7.png)

右上のデプロイボタンで設定が保存されます。

また、デプロイボタンの`Iマーク`をホバーするとURLが表示されます。

> ![](https://i.gyazo.com/177f8a31be02828a08752735396c3a85.png)

ここで`表示されるURL+先ほど指定したパスの文字列`を後ほど利用します。


## 3. HTTPモジュール

IntegromatでHTTPモジュールを検索して追加します。

> ![](https://i.gyazo.com/f4bbc68dfe068e2931617fbd13ff8778.png)

`Make a request`を選択します。

> ![](https://i.gyazo.com/c42e2c25a0d7eb1c868ef61a5c8bbf2c.png)

Office365のアカウント作成をしていない人は以下を参考にアカウント作成を行いましょう。

- E3の試用版アカウントを作成する

https://zenn.dev/protoout/articles/42-office365-powerapps-login

- 個人の無料版を作成する

https://zenn.dev/protoout/articles/14-office365-account-setup

## 2. エクセルを起動

左のメニューからエクセルを選択します。

> ![68747470733a2f2f71696974612d696d6167652d73746f72652e73332e61702d6e6f727468656173742d312e616d617a6f6e6177732e636f6d2f302f33353338372f39303831333630332d346338392d633534312d633166362d6661653138613037303237642e706e67.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/23859f12-6c28-4564-b6ec-ceac796e5320.png)

新しい空白のブックを選択しましょう。

> ![68747470733a2f2f71696974612d696d6167652d73746f72652e73332e61702d6e6f727468656173742d312e616d617a6f6e6177732e636f6d2f302f33353338372f32323961633162652d316462322d343930372d303238332d6639353938626637333939612e706e67.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/836a6a52-5b37-9bbd-bc6a-96c348d79582.png)

エクセルが起動します。プライバシーオプションのウィンドウが表示されたら閉じるを押しましょう。

> ![68747470733a2f2f71696974612d696d6167652d73746f72652e73332e61702d6e6f727468656173742d312e616d617a6f6e6177732e636f6d2f302f33353338372f39666164393030312d333532622d363130302d656466352d6631363633386661656538312e706e67.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/ca62871b-e899-dde2-216d-50a5cbc846ed.png)

## 3. データの準備

Excelを起動したらデータを定義します。

ここでは、買い物メモアプリケーションを作成する際の例を紹介します。

`1行目にデータのフィールド名`（以下の画像だと、商品名/在庫数/単価）、`2行目以降に実際のデータ`（以下の画像だと、りんご/30/100など）を入力します。

> ![](https://i.gyazo.com/3b7435df66944050066ba5b0f26f7eb5.png)

## 4. データのテーブル化

作成したデータをテーブル化させます。

**テーブル化をしないままだと他サービスとの連携で利用できないので注意しましょう。**

`作成した範囲を選択 -> メニューの挿入 -> テーブル`のボタンを押します。

> ![](https://i.gyazo.com/18cae44b7d33b6cea14c255e5f06b053.png)

先頭行をテーブルの見出しとして使用する。にチェックを入れてOKで進みます。

> ![485eb302b9e2189ba3da920c07fcae2d.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/5fdaf600-db00-dc03-91d9-0abb6d3ba70f.png)

Excelの準備はこれでおしまいです。

## 5. OneDriveに共有フォルダを作成

OneDriveで任意のフォルダを作成し、先ほどの手順で作成したExcelファイルをフォルダ内に移動させます。

OneDriveを開きましょう。

Excelの`左上のメニューボタン（9つのマスが並んでるような）`を押してOneDriveを選択します。

> ![74839c69cbe4127d850cf0aee167c7cf.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/3eb7c347-66d1-829f-0ead-9a9b8c05a568.png)

> ![3a857e5bded10da865238e5eb9931b4b.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/dee2f6a4-d484-0eb6-f067-c450c480be32.png)

OneDriveを開くことができたら、**Excelのタブは閉じましょう**

<font color="Red">**注意**
 Excelを開いたままだと他サービスとの連携の際にうまく読み込みができない場合があるので閉じるのを忘れないようにしましょう。
</font>

OneDriveを開くと（特に指定してない場合）`ブック.xlsx`などのファイル名で先程のExcelファイルが保存されていることが分かります。

`新規 -> フォルダー`を選択します。

> ![68747470733a2f2f71696974612d696d6167652d73746f72652e73332e61702d6e6f727468656173742d312e616d617a6f6e6177732e636f6d2f302f33353338372f34643433613235342d333832352d343333362d323565612d3532303064643534373538312e706e67.png](https://qiita-image-store.s3.ap-northeast-1.amazonaws.com/0/2381333/13ca8ac6-84af-3eb0-7289-cb577e3d4fcd.png)

任意のフォルダを作成します。

> ![](https://i.gyazo.com/d35218f25040dae72a474b0b78640d40.png)

作成されるとフォルダが追加されます

> ![](https://i.gyazo.com/f5d768ec9c0288eab2685ff47b32f6de.png)

Excelファイルを作成したフォルダにドラッグ&ドロップで移動させます。

> ![ダウンロード.gif](https://i.gyazo.com/f1942e2a8bba7f77ffda66102b9d26f8.gif)


移動できたら完了です。

### OneDriveのTips

先ほど作成したエクセルファイルが保存されるクラウド上の保存領域（ストレージ）がOneDriveになります。

Office365では作成するファイルは特に指定しない限り、自動的にOneDriveに保存されます。

Microsoft版のGoogle DriveやDropboxだと思ってください。
