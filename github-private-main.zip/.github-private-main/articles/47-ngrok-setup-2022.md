---
title: "アカウントが必要になったngrokの利用準備手順"
emoji: "🕳" 
type: "tech"
topics: ["ngrok","npm","LINE"]
published: true
---

## はじめに

[ngrok](https://ngrok.com/)を利用することで、ローカルで実行しているサーバーを外部に公開できます。

以前は設定なしで利用できていましたが、少し前にアカウント登録が必要になりました。  
本資料では、アカウント登録＆設定手順とトンネリングのやり方を解説します。

## アカウント登録＆設定手順

### アカウント登録する

[ngrok](https://ngrok.com/)のWebサイトでアカウント登録を行い、`Authトークン`を取得します。

1. [ngrok](https://ngrok.com/) へアクセス
   - https://ngrok.com/
2. 右上の`Sign up`を押す
   - [![Image from Gyazo](https://i.gyazo.com/5c2dc9f08da565f5ad170b811609a20f.png)](https://gyazo.com/5c2dc9f08da565f5ad170b811609a20f)
3. メールアドレス、パスワード等入力し、アカウント作成
   - GitHubやGoogleアカウントから作成してもかまいません
   - [![Image from Gyazo](https://i.gyazo.com/1f92cdacddb9b8a794472cde195d9b29.png)](https://gyazo.com/1f92cdacddb9b8a794472cde195d9b29)

### Authトークンを取得する

ログインします。
ログイン後、左側メニューの`Your Authtoken`をクリックし、トークンをコピーします。

[![Image from Gyazo](https://i.gyazo.com/3616df34d446576989bb7a2e2e028ec0.png)](https://gyazo.com/3616df34d446576989bb7a2e2e028ec0)

## Authトークンを設定する

ターミナルを立ち上げて、下記のコマンドを実行する

```bash
npx ngrok authtoken 前手順で取得したトークン
```

[![Image from Gyazo](https://i.gyazo.com/a56ae3cb99f326c27bb33392f13af1c1.png)](https://gyazo.com/a56ae3cb99f326c27bb33392f13af1c1)

これで設定は完了です。ngrokでトンネリングしてみましょう。

## トンネリングする

ターミナルで以下のコマンドを実行します

```
npx ngrok http 3000
```

> `3000`は使用しているポート番号に置き換えてください

実行すると、URLがいくつか表示されるので`https`から始まるものをコピーして利用しましょう。

[![Image from Gyazo](https://i.gyazo.com/a12ed66cd6a8bfc4714dc84eb223d513.png)](https://gyazo.com/a12ed66cd6a8bfc4714dc84eb223d513)

LINE Botを作るときは、上記でコピーしたURLをLINE DevelopersコンソールのWebhook URLに設定して利用しましょう。
その他にも、Webサーバーを一時的に外部公開したいときなどに利用できます。

手順は以上で終わりです。お疲れさまでした。

## 注意点

`auth`トークンは公開しないようにしましょう

:::details 誤ってauthトークンを公開してしまったときの対応手順
   1. もし公開してしまったら、ダッシュボードの`Your Authtoken`内の一番下にリセットボタンがあるので、作りなおす  
   [![Image from Gyazo](https://i.gyazo.com/f6f4490e1ea6cfdaa651fa387a235cbb.png)](https://gyazo.com/f6f4490e1ea6cfdaa651fa387a235cbb)
   1. Windowsだと `C:\Users\[ユーザー名]\.ngrok2` にある `ngrok.yml` ファイルを削除  
   [![Image from Gyazo](https://i.gyazo.com/749d91a1e1c3405b05c7c9fe80ab4640.png)](https://gyazo.com/749d91a1e1c3405b05c7c9fe80ab4640)  
   Macは `/Users/[ユーザー名]/.ngrok2`  
   [![Image from Gyazo](https://i.gyazo.com/e0b73b5af48438448d63f19aa917cfe8.png)](https://gyazo.com/e0b73b5af48438448d63f19aa917cfe8)
   1. 再び`npx ngrok authtoken [新しいauthトークン]`の実行
:::
