---
title: "GitHub Actions入門" # 記事のタイトル
emoji: "📲" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["GitHub","GitHub Actions","GitHub","CI"] # タグ。["markdown", "rust", "aws"]のように指定する
published: false # 公開設定（falseにすると下書き）
---

この項目では、

- GitHub Actionsの使い方を学ぶ
- リポジトリのプッシュをきっかけにしたGitHub ActionsからのLINE Notifyの動作
- 5分ごとなど定期的なタイミングをきっかけにしたGitHub ActionsからのLINE Notifyの動作

という内容を進めます。

そうすることで、

- GitHub Actionsを使って、何かのきっかけで動作できるAPIなどを仕組みの理解と実践
- GitHub PagesやGitHub Actionsのように今回の集中講座においてGitHubの機能を使って発想を広げていく

ところを目指します。

## GitHub Actions とは

> ![](https://i.gyazo.com/6936bf2f44f6aa5c870c6d514cbad822.png)

GitHub Actionsは、GitHubのリポジトリ、つまりコードを保存するのと同じ場所でソフトウェア開発のワークフローを自動化します。

自動化は、たとえば、リポジトリへプッシュするタイミングであったり、5分ごと・1日ごとなど定期的なタイミングも作ることができます。そのほかにも、さまざまなタイミングがあります。

それぞれのタスクを用意してアクションを呼び出し、それらを組み合わせて自動的に動作するワークフローと呼ばれる仕組みを作成できます。

## 作業のはじめ方

VS Codeは、`01-06-git`のフォルダーで作業を進めましょう。GitHubの`git-firststep`リポジトリとも関連づいているので始めやすいです。

> ![](https://i.gyazo.com/f781d7c5ac74d20c3206cc9724cd8c72.png)