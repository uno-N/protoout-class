---
title: "obniz（1Y）初期設定"
emoji: "備"
type: "tech"
topics: ["obniz","npm","JavaScript","Node.js","Wi-Fi"]
published: true
---

基本的に、**授業日の前にobnizがWi-Fiにつながることを確認してください！**

[公式のドキュメント](https://obniz.com/ja/doc/reference/board-1y/quick-start/)も参考にしてみてくださいね。

## 1. 初期設定（Wi-Fi接続）

[![Image from Gyazo](https://i.gyazo.com/c266201bd9b461e7f92e2d8c8e6787ae.png)](https://gyazo.com/c266201bd9b461e7f92e2d8c8e6787ae)

obniz 1Yを開封すると、写真のように本体と説明書が入っています。  
USBケーブル（標準A - タイプC）を用意して、説明書に書かれている手順で初期設定を進めましょう。

[![Image from Gyazo](https://i.gyazo.com/9085965c70f8fda679c0fb20735c5560.png)](https://gyazo.com/9085965c70f8fda679c0fb20735c5560)

設定が完了し、Wi-Fiにもうまくつながれば上記のような表示になります。  

アップデートが始まってしまった場合は、以下の「3の手順」を先に行いながらしばらく待ちましょう。

ここでは、[![Image from Gyazo](https://i.gyazo.com/f8079ab7925d09fee5a9a484e82b1306.png)](https://gyazo.com/f8079ab7925d09fee5a9a484e82b1306)

これらの情報が漏れた場合は他人から自身のobnizが操作可能となってしまいます。  

記事発信をするときなどにも写り込まないようにするか、画像加工をするなどして取り扱いには十分注意しましょう。

## 2. 自分の obniz ID をメモしておこう

[![Image from Gyazo](https://i.gyazo.com/ffe991f6fd2fe7e86a5ff68538cc7e09.png)](https://gyazo.com/ffe991f6fd2fe7e86a5ff68538cc7e09)


## 3. Developer’s Consoleへの登録

> [obniz - developer's console](https://obniz.com/ja/console)

上記のページ右上の「サインイン/サインアップ」からユーザー登録を行ってアカウントを作ってください。  

個人のGoogleアカウントなどと紐づけて作ってしまって問題ありません。

確認メールがすぐに来るため、メール中のリンクにアクセスして有効化を完了させておきましょう。

## 4. サンプルを動かしてみよう

[![Image from Gyazo](https://i.gyazo.com/9085965c70f8fda679c0fb20735c5560.png)](https://gyazo.com/9085965c70f8fda679c0fb20735c5560)

ご自身のobnizに表示されているQRコードを、スマートフォンで読み取り、表示されたURLにアクセスしてください。

- [iPhone・AndroidでQRコードを最速で読み取る方法 アプリ不要でLINE登録・決済にも｜TIME＆SPACE by KDDI](https://time-space.kddi.com/mobile/20190403/2611)  
- [スマホでQRコードを読み取る方法【iPhone＆Android 2021年版】 | できるネット](https://dekiru.net/article/19468/)

> [![Image from Gyazo](https://i.gyazo.com/672d707686b3ba19384832f07d28a9d0.jpg)](https://gyazo.com/672d707686b3ba19384832f07d28a9d0)

[![Image from Gyazo](https://i.gyazo.com/14bbfa6ac44727e7de1916ad952e7c12.png)](https://gyazo.com/14bbfa6ac44727e7de1916ad952e7c12)

アクセス先のページにある「再生ボタン」のようなものをクリックしてしばらく待ち、obnizのディスプレイに「Hello World」と表示されれば成功です。  

obnizからはさまざまなハードウェアを制御したり、センシングによってデータをとってきたりすることが可能で、さらにこのサンプルのようにスマートフォンやPCなどから直接それらにアクセスできます。IoTの世界をぐっと近くしてくれるobnizをこれからどんどん触っていきましょう！
