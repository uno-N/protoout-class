---
title: "Gitpodのはじめ方"
emoji: "🫖"
type: "tech"
topics: ["github","Gitpod","VS Code"]
published: true
---

授業などで利用するGitpodのはじめ方を紹介します。

Gitpodを使うことでローカル環境を汚すことなくブラウザ上でプログラミング環境を構築できます。

## Gitpodのアカウント作成

GitHubアカウントがあると簡単に作成できます。

https://zenn.dev/protoout/articles/50-howto-github-setup

アカウントがない方は、こちらの記事を見て作成しておきましょう。

## Gitpodを始める

[こちら](https://www.Gitpod.io)にアクセスしましょう。

https://www.Gitpod.io

> ![](https://i.gyazo.com/a47f2016df3f0df4598cdb48411df632.jpg)

右上の`Sign Up`ボタンからアカウント作成を行います。

とはいえGitHubなどのアカウントがあれば認証するくらいです。

GitHubを選択して進みます。

> ![](https://i.gyazo.com/6e62f0a39813e9cce0aad0e4d2125a6d.png)

GitHubの画面に遷移します。

（GitHubにログインしていなければログインを求められるのでログインしましょう。）

`Authorize Gitpod-io`という緑のボタンが表示されるのでクリックして進めます。

> ![](https://i.gyazo.com/2aeb9d8127eb652210ba974270ca17b5.png)

認証すると自動的にリダイレクトされて以下のようなホーム画面が表示されます。

> ![](https://i.gyazo.com/ff85701deab00e57eb15c04fc087a06d.png)

ここまででセットアップは終了です。

お疲れ様でした。