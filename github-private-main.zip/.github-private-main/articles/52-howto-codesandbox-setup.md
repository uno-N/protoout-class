---
title: "CodeSandboxのはじめ方"
emoji: "🚵‍♀️"
type: "tech"
topics: ["CodeSandbox","GitHub","プロトタイピング"]
published: true
---

授業などで利用するCodeSandboxのはじめ方を紹介します。

CodeSandboxを使うことでローカル環境（各自のパソコンの環境）を汚すことなくブラウザ上でプログラミング環境を構築できます。

（※ 利用する際はGoogle Chromeを利用しましょう。）

## GitHubのアカウント作成

GitHubアカウントがあると簡単に作成できます。

https://zenn.dev/protoout/articles/50-howto-github-setup

アカウントがない方は、こちらの記事を見て作成しておきましょう。

## CodeSandboxを始める

[こちら](https://codesandbox.io/)にアクセスしましょう。

https://codesandbox.io/

> ![](https://i.gyazo.com/f4c18f895968b8da4a9457686d92c693.png)

右上の`Sign In`ボタンからアカウント作成を行います。

とはいえGitHubなどのアカウントがあれば認証するくらいです。

GitHubを選択して進みます。

> ![](https://i.gyazo.com/4e90772c42c7f35f4359d93621552162.png)

GitHubの画面に遷移します。

（GitHubにログインしていなければログインを求められるのでログインしましょう。）

`Authorize codesandbox`という緑のボタンが表示されるのでクリックして進めます。

> ![](https://i.gyazo.com/8b1b2f96b6518951571022ac83b046a6.png)

認証すると自動的にリダイレクトされて以下のような画面が表示されます。

CodeSandbox上での名前を設定します。
自身のアカウント名などにしましょう。

> ![](https://i.gyazo.com/db1031411376cc110b15136415d0cd80.png)

入力したら`Finish Sign Up`で終了です。

以下のようなホーム画面にリダイレクトされます。

> ![](https://i.gyazo.com/b5b96232d45235174db87faa8321d1b7.png)

ここまででセットアップは終了です。

お疲れ様でした。