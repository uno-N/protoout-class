---
title: "Replitのはじめ方"
emoji: "🚵‍♀️"
type: "tech"
topics: ["Replit","GitHub","プロトタイピング"]
published: true
---

授業などで利用するReplitのはじめ方を紹介します。

Replitを使うことでローカル環境（各自のパソコンの環境）を汚すことなくブラウザ上でプログラミング環境を構築できます。

（※ 利用する際はGoogle Chromeを利用しましょう。）

## GitHubのアカウント作成

GitHubアカウントがあると簡単に作成できます。

https://zenn.dev/protoout/articles/50-howto-github-setup

アカウントがない方は、こちらの記事を見て作成しておきましょう。

## Replitを始める

[こちら](https://replit.com/)にアクセスしましょう。

https://replit.com/

> ![](https://i.gyazo.com/19213da66e791df0faf098f2e3d6192e.png)

右上の`Sign Up`ボタンからアカウント作成を行います。

とはいえGitHubなどのアカウントがあれば認証するくらいです。

GitHubを選択して進みます。

> ![](https://i.gyazo.com/33fbbf62eae3c87b8cdae0487a711671.png)

GitHubの画面に遷移します。

（GitHubにログインしていなければログインを求められるのでログインしましょう。）

`Authorize Replit Online IDE`という緑のボタンが表示されるのでクリックして進めます。

> ![](https://i.gyazo.com/501b36ec1e13c4b28602732f8dac1ad5.png)

認証すると自動的にリダイレクトされて以下のような画面が表示されます。

簡単なアンケートのようなものなので`Skip`して大丈夫です。

> ![](https://i.gyazo.com/ac8750d96a80cff0ff46070a9a98bca0.jpg)

初回ログインの際にはチュートリアルのポップアップウィザードが表示されますが、✖️ボタンで閉じて大丈夫です。

> ![](https://i.gyazo.com/794061fac9bddda3870e9999eeb72900.png)

以下のようなホーム画面になります。

> ![](https://i.gyazo.com/88acf772dc8ed5f69c06ccbdfd22ebbe.png)

ここまででセットアップは終了です。

お疲れ様でした。