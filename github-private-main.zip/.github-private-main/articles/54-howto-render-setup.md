---
title: "Renderのはじめ方"
emoji: "🏊‍♀️"
type: "tech"
topics: ["Render","Heroku","PaaS","Node.js"]
published: true
---

授業などで利用するRenderのはじめ方を紹介します。

## Render

無料枠でかなり活用できるPaaSサービスです。
作ったプログラムをインターネット上に無料公開するなどができます。

※これまでNode.jsなどを動かすためのPaaSとしてHerokuがありましたが、2022/11/28からは無料枠が使えなくなるとのことで代替として良さそうです。

> https://blog.heroku.com/next-chapter

個人開発の場合、代替案としてRenderが有効です。

https://render.com/

## GitHubのアカウント作成

GitHubアカウントがあると簡単に作成できます。

https://zenn.dev/protoout/articles/50-howto-github-setup

アカウントがない方は、こちらの記事を見て作成しておきましょう。

## Renderを始める

トップページから`GET STARTED`のボタンを押すか、[こちら](https://dashboard.render.com/register)から新規登録を行います。

> ![](https://i.gyazo.com/d3fc12a1f859ac2a45feeb254a645edc.png)

### GitHub認証

GitHubのアカウント経由でアカウント作成を進めます。

> ![](https://i.gyazo.com/bf71d3f99773fc8ccb4d51f4505621da.png)

GitHubのボタンを押すとGitHubの認証ページにリダイレクトします。

（GitHubにログインしていなければログインを求められるのでログインしましょう。）

> ![](https://i.gyazo.com/6db50bdf77337c0bb5350d32fa1a62b8.png)


`Authorize Render`という緑のボタンが表示されるのでクリックして進めます。

> ![](https://i.gyazo.com/7864b986de8b7a3de749b95ca1b8c7df.png)

認証すると自動的にリダイレクトされて以下のような画面が表示されます。

> ![](https://i.gyazo.com/f86f5d2698fd42754a1925e78172604f.png)

`COMPLETE SIGN UP`で進みます。

> ![](https://i.gyazo.com/8a179aba61405c98cabccd4153f5de92.png)

このような画面になります。

### メール認証

登録したメール宛に認証のリンクが送られてくるのでクリックしましょう。（※メールが届かない人は迷惑メールフォルダーを確認したり、メールアドレスが間違ってないかを再確認しましょう。）

> ![](https://i.gyazo.com/6bc6b0a37caf3026623f582f6bac6406.png)

### ホーム画面へ

以下のような画面になれば完了です。

> ![](https://i.gyazo.com/6f04b44adc30c00fddcb65fa23514799.png)

ここまででセットアップは終了です。

お疲れ様でした。