---
title: "Node-REDをRenderにインストールする"
emoji: "🏊‍♀️"
type: "tech"
topics: ["Render","Heroku","PaaS","Node.js","Node-RED"]
published: true
---

授業などで利用するNode-REDをRenderで利用するための準備を紹介します。

## Node-REDの簡単な紹介

Node-REDはローコード開発ツールなどと言われていてプログラミング不要で色々なソフトウェア開発が行えるソフトウェアです。

通常はパソコンにインストールして利用するのですが、今回はクラウド環境でパソコンを借りて利用できるような仕組み（PaaS）を利用してNode-REDをインストールします。

## Renderのアカウント準備

こちらの資料をもとにRenderのアカウント作成をしましょ。

https://zenn.dev/protoout/articles/54-howto-render-setup

ログインしてホーム画面が表示される状態にしてください。

> ![](https://i.gyazo.com/6f04b44adc30c00fddcb65fa23514799.png)

## RenderにNode-REDをインストール

右上の`New +`ボタンから`Web Service`を選択します。

> ![](https://i.gyazo.com/c7e02c67292c94cd3e321109ea856130.png)

遷移したページの1番下の`Public Git repository`のフォームに以下のURLをコピペして`Continue`ボタンを押しましょう。

```
https://github.com/n0bisuke/node-red-express
```

> ![](https://i.gyazo.com/c9047b74cbba98139884a92e4590cc90.gif)

`Name`のフォームに`nodered-protoout-自身の名前`といった形で独自の名前を設定しましょう。

ちなみに、この名前は全世界のRenderユーザーで被らないようにする必要があるので、`20220831-n0bisuke`のような形で日付の数字などを入れると被りにくくて良いと思います。

> ![](https://i.gyazo.com/e292c24100cdae6d41cd5acaeff4283e.png)

次に`Region`を`Singapore`（シンガポール）に設定してください。

※デフォルトだとOregonになってしまう場合がありますが、何回か検証していたらOregonだと上手く動かず、Shingaporeだと上手く行った事象がありました。ご注意ください。

> ![](https://i.gyazo.com/6562d3329305bbf8d99fbb358c7b4061.png)

他の項目は触らずに、左下の`Create Web Service`ボタンを押して進みます。

> ![](https://i.gyazo.com/7048e5187020d87b77bdc45d5e64e436.png)

以下のような画面になります。
インストールに少し時間が掛かりますが少し待ちましょう。

> ![](https://i.gyazo.com/899a756cf2e8fd71a7b5471cbfad1b4d.png)

ログが表示されますが、そのまま待ちましょう。
結構時間が掛かるのでコーヒーなど飲んで待ちましょう。

ちなみに、課金をするとこの時間が早くなる模様です。

> ![](https://i.gyazo.com/d756dfa7a66078b1aeba164a23f73dac.png)

しばらく待ち、`Live`という表示になったら、インストールが完了です。

左上の`https://nodered-protoout-xxxxxx.onrender.com/`といったURLにアクセスしましょう。

> ![](https://i.gyazo.com/fb1ea362d69b60154bc292a50b322bcf.png)

URLにアクセスし、以下のような画面が表示されたら完了です。

> ![](https://i.gyazo.com/1a42a0c132e4603515059797fdc50623.png)

これでNode-REDのインストールができています。

お疲れ様でした。