---
title: "RenderにLINE Botをデプロイする"
emoji: "🏊‍♀️"
type: "tech"
topics: ["Render","Heroku","PaaS","Node.js","line"]
published: true
---

## LINE Botの準備

こちらの資料をもとに、LINE Botアカウントの作成しましょう。
その後、2つのキー（チャンネルシークレット・チャンネルアクセストークン）を取得してコピーしておいてください。

https://zenn.dev/protoout/articles/16-line-bot-setup

## Renderのアカウント準備

こちらの資料をもとにRenderのアカウント作成をしましょ。

https://zenn.dev/protoout/articles/54-howto-render-setup

ログインしてホーム画面が表示される状態にしてください。

> ![](https://i.gyazo.com/6f04b44adc30c00fddcb65fa23514799.png)

## RenderにLINE Botのコードをデプロイする

右上の`New +`ボタンから`Web Service`を選択します。

> ![](https://i.gyazo.com/c7e02c67292c94cd3e321109ea856130.png)

遷移したページの1番下の`Public Git repository`のフォームに以下のURLをコピペして`Continue`ボタンを押しましょう。

```
https://github.com/mitsuoka0423/render-line-bot-trial
```

> ![](https://i.gyazo.com/c9047b74cbba98139884a92e4590cc90.gif)

`Name`のフォームに`linebot-protoout-自身の名前`といった形で独自の名前を設定しましょう。

ちなみに、この名前は全世界のRenderユーザーで被らないようにする必要があるので、`20220831-mitsuoka`のような形で日付の数字などを入れると被りにくくて良いと思います。

> ![](https://i.gyazo.com/6158809e1e890c3cdee028cb9fbea6c1.png)

次に`Region`を`Singapore`（シンガポール）に設定してください。

※デフォルトだとOregonになってしまう場合がありますが、何回か検証していたらOregonだと上手く動かず、Shingaporeだと上手く行った事象がありました。ご注意ください。

> ![](https://i.gyazo.com/6562d3329305bbf8d99fbb358c7b4061.png)

次に、`Build Command`を`npm i`、`Start Command`を`node index.js`に設定してください。

> ![](https://i.gyazo.com/8910e59c285220eefea54b86a7ebcbfb.png)

他の項目は触らずに、左下の`Create Web Service`ボタンを押して進みます。

> ![](https://i.gyazo.com/7048e5187020d87b77bdc45d5e64e436.png)

以下のような画面になります。

続いて、環境変数の設定を行います。
サイドバーの`Environment`を開いて、`CHANNEL_ACCESS_TOKEN`と`CHANNEL_SECRET`を登録しましょう。

`Value`に設定する内容は、`LINE Botの準備`でコピーしたチャンネルアクセストークンとチャンネルシークレットです。

> ![](https://i.gyazo.com/ba71523077e8ea36b00e03e7c7774891.png)

インストールに少し時間が掛かりますが少し待ちましょう。

> ![](https://i.gyazo.com/899a756cf2e8fd71a7b5471cbfad1b4d.png)

ログが表示されますが、そのまま待ちましょう。
結構時間が掛かるのでコーヒーなど飲んで待ちましょう。

ちなみに、課金をするとこの時間が早くなる模様です。

> ![](https://i.gyazo.com/d756dfa7a66078b1aeba164a23f73dac.png)

しばらく待ち、`Live`という表示になったら、インストールが完了です。

左上の`https://linebot-protoout-xxxxxx.onrender.com`といったURLをコピーしましょう。

> ![](https://i.gyazo.com/3bbae26ab22ef0671276f0202c0a8be6.png)

[LINE Developers](https://developers.line.biz/console/)で今回作成したLINE Botアカウントを開き、`Webhook URL`を設定します。
また、`Webhookの利用`をオンにします。

`https://linebot-protoout-20220909-mitsuoka.onrender.com/webhook`

最後に`/webhook`をつけるのを忘れないようにしてください。

これで設定は完了です。

LINEで動作確認してみましょう。
送信した文字がそのまま返って来れば完成です。

![](https://i.gyazo.com/d8089fc120d4a3e958da9f29bbe54288.png)

お疲れさまでした。
