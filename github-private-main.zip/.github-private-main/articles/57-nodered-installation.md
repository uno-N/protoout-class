---
title: "Node-REDのインストールと起動"
emoji: "🏃"
type: "tech"
topics: ["Node-RED","Node.js"]
published: true
---

## インストール

### Node.jsのダウンロード

[![Image from Gyazo](https://i.gyazo.com/f803e065a2413388fa9222ac6dd09898.png)](https://gyazo.com/f803e065a2413388fa9222ac6dd09898)

[Node.jsのダウンロードページ](https://nodejs.org/ja/)に移動し、2つあるボタンのうち「推奨版」と書かれている左側のボタンをクリックして、インストーラをダウンロードしましょう。

- 上記画像はWindowsの場合ですが、Macでも同様です。
- **2022/09/10 時点での最新の推奨版は `16.17.0 LTS` です**。

### Node.jsのインストール

ダウンロードしたインストーラーを実行します。  
途中で選択が必要なところはありませんので、「Next」・「次へ」・「承諾」などのボタンをクリックして、インストールを完了させてください。

### Node-REDのインストール

Node-REDはブラウザからのダウンロードではなく、npmコマンド（Node.jsと同時にインストールされる）を使って直接インストールを実施します。

#### Windowsの場合

[![Image from Gyazo](https://i.gyazo.com/dc3d67f8fc9618df0ad1fdfaafe8d18e.png)](https://gyazo.com/dc3d67f8fc9618df0ad1fdfaafe8d18e)

「Windows Power Shell」を開いてください。

[![Image from Gyazo](https://i.gyazo.com/e6621916a7bf797dcd49384e0a035f67.png)](https://gyazo.com/e6621916a7bf797dcd49384e0a035f67)

`npm install -g node-red` と入力し、Enterキーを押します。英字とスペースは全て半角であることに気をつけてください。うまくインストールできると上図のようになります。

#### Macの場合

「ターミナル.app」を開き、`sudo npm install -g node-red` と入力し、Enterキーを押します。パスワードが求められるので入力（画面には表示されない）し、もう一度Enterキーを押してください。うまくインストールできると、上図のWindowsの場合と似たような文字列が出てきます。

## 起動

Windowsなら「Windows Power Shell」、Macなら「ターミナル.app」を開いたままで `node-red` と入力してEnterキーをクリックします。

[![Image from Gyazo](https://i.gyazo.com/47c0bd4446854002fd82da73d54cc77f.png)](https://gyazo.com/47c0bd4446854002fd82da73d54cc77f)

このような文字列が出てきたら、**Power Shellまたはターミナルは閉じずに**、Chromeブラウザで新しいタブを開いて [http://localhost:1880](http://localhost:1880) にアクセスしてください。

[![Image from Gyazo](https://i.gyazo.com/17113b56a68944ccbcaf989ba8d81391.png)](https://gyazo.com/17113b56a68944ccbcaf989ba8d81391)

うまく実行できていれば、上のような画面が出てきます。  
ここまでできればOKです。

> 以降は常に、先にPower Shellまたはターミナルで `node-red` を実行した状態で [http://localhost:1880](http://localhost:1880) にアクセスするようにしてください。  
> 閉じる際は、Chromeブラウザを閉じてから、Power Shellまたはターミナルを閉じればOKです。

### Windowsでエラーのようなものが出る場合

#### Power Shellで `node-red` 実行時に赤い文字が出てしまう場合

`Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser`  
と入力してEnterキーを押してください。

[![Image from Gyazo](https://i.gyazo.com/97cc42052d95d05e1694114a51f0a8e2.png)](https://gyazo.com/97cc42052d95d05e1694114a51f0a8e2)

「実行ポリシーを変更しますか？」と聞かれるので `Y` と入力してEnterキーを押してください。そのあとで再度 `node-red` を実行してみてください。

参考: https://qiita.com/ponsuke0531/items/4629626a3e84bcd9398f

#### 「セキュリティの重要な警告」ウインドウが出る場合

[![Image from Gyazo](https://i.gyazo.com/909c7da2d211de7988651c8303fb4eae.png)](https://gyazo.com/909c7da2d211de7988651c8303fb4eae)

チェックボックスを2箇所ともにチェックして「アクセスを許可する」ボタンをクリックしてください。