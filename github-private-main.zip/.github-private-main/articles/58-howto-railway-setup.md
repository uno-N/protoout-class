---
title: "Railwayのはじめ方"
emoji: "🚊"
type: "tech"
topics: ["Railway","Heroku","PaaS","Node.js"]
published: true
---

授業などで利用するRailwayのはじめ方を紹介します。

## RailWay

無料枠でかなり活用できるPaaSサービスです。

執筆時点（2022年9月15日）では1か月あたり500時間まで利用可能だそうです。

作ったプログラムをインターネット上に無料公開するなどができます。

※これまでNode.jsなどを動かすためのPaaSとしてHerokuがありましたが、2022/11/28からは無料枠が使えなくなるとのことで代替として良さそうです。

> https://blog.heroku.com/next-chapter

Herokuの代替としてRailwayも有用です。

https://railway.app/

## GitHubのアカウント作成

GitHubアカウントがあると簡単に作成できます。

https://zenn.dev/protoout/articles/50-howto-github-setup

アカウントがない方は、こちらの記事を見て作成しておきましょう。

## Railwayを始める

トップページの右上の`Login`ボタンから進みましょう。

> ![](https://i.gyazo.com/54ae9f3d78e5d0a2cfabb8ddaa99b41f.png)

### GitHub認証

GitHubのアカウント経由でアカウント作成を進めます。

> ![](https://i.gyazo.com/12c7f94c8bd827bf8386b31252970d46.png)

GitHubのボタンを押すとGitHubの認証ページにリダイレクトします。

（GitHubにログインしていなければログインを求められるのでログインしましょう。）

> ![](https://i.gyazo.com/68c0d7b09d3cb378792c3d67ba43a4aa.png)


`Authorize Railway App`という緑のボタンが表示されるのでクリックして進めます。

> ![](https://i.gyazo.com/0795cfe2762d83e0ca2c6d391c0ac350.png)

認証すると自動的にリダイレクトされて以下のような画面が表示されます。

> ![](https://i.gyazo.com/c927acc2b8f517ed9871a8fa71c803f8.png)

これでアカウント登録は完了ですが、以下の手順を踏まないとGitHub連携などがうまく使えません。続けて以下の手順に進みましょう。

## 利用許諾に同意

ログイン直後の画面で`Please agree to the new terms to keep on using Railway`というアラートのようなメッセージが表示されます。

> ![](https://i.gyazo.com/708c0e86d7fbee9c2309bd03c2a034d6.png)

また、この時点だと利用枠が200時間になっていますね。

ボタンを押して、ポリシーに許可をします。



> ![](https://i.gyazo.com/b3d9de89b942f32551b70137f56e96a6.png)

次の画面でもボタンを押して進みます。

> ![](https://i.gyazo.com/85090f8fe2d51b676175f048cb43ec27.png)

これでアカウント認証が進み、利用枠が500時間になり、GitHubなどを利用したアプリケーションのデプロイができるようになります。

> ![](https://i.gyazo.com/c927acc2b8f517ed9871a8fa71c803f8.png)

ここまででセットアップは終了です。

お疲れ様でした。