---
title: "Node-REDをRailwayにインストールする"
emoji: "🚊"
type: "tech"
topics: ["Railway","Heroku","PaaS","Node.js","Node-RED"]
published: true
---

授業などで利用するNode-REDをRailWayで利用するための準備を紹介します。

## Node-REDの簡単な紹介

Node-REDはローコード開発ツールなどと言われていてプログラミング不要で色々なソフトウェア開発が行えるソフトウェアです。

通常はパソコンにインストールして利用するのですが、今回はクラウド環境でパソコンを借りて利用できるような仕組み（PaaS）を利用してNode-REDをインストールします。

## Railwayのアカウント準備

こちらの資料をもとにRailwayのアカウント作成をしましょ。

https://zenn.dev/protoout/articles/58-howto-railway-setup

ログインしてホーム画面が表示される状態にしてください。

![](https://i.gyazo.com/5425c991ac57b9f2ca2b38a75b33e004.png)

## GitHubのリポジトリをフォーク

https://github.com/n0bisuke/node-red-railway

こちらのリポジトリをフォーク（コピー）します。

右上の`Fork`ボタンを押して進みます。

> ![](https://i.gyazo.com/f593a5bc1cd271676a3550e3b1d5ba2c.png)

とくに設定を変えずに、`Create fork`のボタンを押しましょう。

> ![](https://i.gyazo.com/5c66db3c665c0d968b4c6ead33d23ae5.png)

見た目上はパッと見変わらないですが、そうするとリポジトリがコピーされます。

> ![](https://i.gyazo.com/5751196a72d68fd48dac548869e58e16.png)

いったんGitHub側の操作はここまででOKです。

## RailwayにNode-REDをインストール

右上の`+ New Project`ボタンから進みます。

### GitHubとRailwayの連携

GitHubアカウントとRailwayアカウントを連携させます。ログインでGitHubを利用している場合でも別途連携処理が必要な模様です。

遷移したページで`Deploy from GitHub Repo`を選択しましょう。

> ![](https://i.gyazo.com/edc547b2ef05550f04f1737bc1ca3655.png)

`Configure GitHub App`を選択して進みます。

> ![](https://i.gyazo.com/a85db999325ae25ec60d17b2cdadb52c.png)

GitHubの連携画面のウィンドウが表示されます。
人によってはGitHubアカウントがオーガナイゼーションに紐づいてる場合があります。利用するアカウントを選択しましょう。

とくにこだわりがない場合は、自身のアカウントを選択しましょう。

> ![](https://i.gyazo.com/f8f6e6e8763da7d19b7deaecd7822b4f.png)

次の画面でアプリの利用許可をします。
Railwayを信頼してページ下部の`Install & Authorize`ボタンを押して進みましょう。

> ![](https://i.gyazo.com/654bef83e33bb254eb78e9a7cdeb4cc2.png)

うまくいくとウィンドウが閉じられます。

これで連携完了です。

### Node-REDのデプロイ

少し前段階の準備がかかりましたが、いよいよNode-REDのデプロイ（インストール）に進みます。

再度`New Project`のページにいきます。先ほど同様に`Deploy from GitHub repo`を選択して進みましょう。

> https://railway.app/new
>
> ![](https://i.gyazo.com/311a9ac55a25d86b8052627cc6178218.png)

先ほどの手順でフォークした`node-red-railway`のリポジトリが表示されるので選択して進みます。

> ![](https://i.gyazo.com/50de043753a2cee6fbff1590c1fc1924.png)

`Deploy Now`を選択して進みます。

> ![](https://i.gyazo.com/2d62e2c4d109c5e9d9f5c75091430ad9.png)

うまくいくと次のような画面になります。

> ![](https://i.gyazo.com/84aa1fcec3be3dba0512da4a0c73c007.png)

`Success`と表示されていればデプロイは成功しているはずです。

### URLを発行する

通常のPaaSだと分かりやすい場所にアプリケーションアクセス用のURLが表示されているものですが、Railwayは**デフォルトで公開URLが発行されず、自身で発行する必要があります。**

Node-REDの画面へアクセスするために、URLを発行します。

`Settings`のタブを選択し、Domainsの項目にある`Generate Domain`ボタンを選択します。

> ![](https://i.gyazo.com/85eae52bbc1eacce9a8783acbad16fb8.png)

そうするとアクセス可能なURLが発行されます。
 
> ![](https://i.gyazo.com/4ef76335de2e06340a0d67fee92c6a7d.png)

このURLにアクセスするとNode-REDの画面が表示されます。

> ![](https://i.gyazo.com/89257832c2a08fdbcaf5418d97324708.png)

これでNode-REDのインストールができています。

お疲れ様でした。

## 補足: 連続稼働時間

https://docs.railway.app/reference/plans#execution-time-limit

> The user starts the month with 500 execution hours.

> With that current arrangement, their app will stay up for ~21 days.

ドキュメントによると、フリープランだと500時間、21日ほど稼働し続ける模様です。
