---
title: "音声メモに適したメディア"
emoji: "🎧" 
type: "idea"
topics: ["Audio","Radio","Podcast"]
published: true
---

音声メモに適したメディアをピックアップします。
（随時更新します。（2022/10/20））

## 音声メモの良さ

音声メモの良さは参考記事にもあるように

- トーク力の向上
- インプットとアウトプット】
- 日記としての機能
- 話すときの癖

などが挙げられます。プロトアウトスタジオでもインプットとアウトプットを短いサイクルで行っていきますが、その場その場での感情や思ったことを小さく記録する癖を付けましょう。

> 参考: [ボイス日記で得られる４つの効果](https://note.com/tattyann315/n/n53ac26c796ac)

ただメモとして残すだけではなく、外部公開もできる状態のメディア・ツールをピックアップします。

## note（ノート） 

note（ノート）はブログを書くメディアとして有名ですが、スマホアプリ版だと音声メモを収録できます。

- [iPhone版](https://apps.apple.com/jp/app/note-%E3%83%8E%E3%83%BC%E3%83%88/id906581110)
- [Android版](https://play.google.com/store/apps/details?id=mu.note&hl=ja&gl=US)

## Stand.fm（スタンドエフエム）

[Stand.fm](https://stand.fm/)は音声配信のSNSのようなプラットフォームです。
気軽に思ったことを配信するのに向いています。

ラジオ番組として展開しているユーザーも多いです。

> ![](https://i.gyazo.com/30baf0270fb6ed8c6ea0113ba4507a7a.jpg)

## Anchor（アンカー）

[Anchor](https://anchor.fm/)はSpotifyが展開しているポッドキャスト作成＆配信ツールです。

ポッドキャストという形式になるので音声メモと呼ぶには少し重たい印象ですが、手軽に音声を記録して公開できます。

> ![](https://i.gyazo.com/21e575d308e3cb6560c6a20685504fc2.jpg)

## Twitterスペース

Twitterに[スペース](https://help.twitter.com/ja/using-twitter/spaces)という機能があります。

少し昔にclubhouseという招待制の音声SNSアプリが話題になりましたが、似た機能となっています。

部屋を立ち上げて一人で話をしたり、誰かと会話もできます。

録音機能があるので会話したり話をした内容を記録することもできます。

録音した内容はスペースのツイートから録音再生できます。