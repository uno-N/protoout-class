---
title: "Power Appsのログインまで" # 記事のタイトル
emoji: "💪" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["Office365","Power Apps"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
---

ノーコードでアプリ開発ができるマイクロソフトのPower Appsの利用までの流れです。

## 1. Office 365 E3以上のアカウントの準備

Power Appsの利用を試すにあたり、`Office365 E3`のアカウント作成をする必要があります。無料で利用する場合は以下の手順で試用版アカウントを作成しましょう。

https://zenn.dev/protoout/articles/42-office365-trial-setup

## 2. Power Appsの画面を開く

次に、Power Appsの画面を開きましょう。[開始ページ](https://make.powerapps.com/)にアクセスします。

https://make.powerapps.com/

先ほどの画面の続きで、`作業の開始`ボタンを押して進みましょう。

担当者情報を入力するフォームが出てくるので入力します。執筆時点だと電話番号以外は自動的に入ってました。

送信ボタンを押して進みます。

> ![](https://i.gyazo.com/4a766d2c9a91c726ce95e98ac782ac1e.png)


初回のみチュートリアルのウィザードが出てくるのでスキップしましょう。

> ![](https://i.gyazo.com/3e7186434f24d42847aa9c0aa343da4e.png)

以下のようなホーム画面が表示されたら完了です。

> ![](https://i.gyazo.com/79cb885caa1639cc12fa802e9ef32f5a.png)

お疲れ様でした。