---
title: "Power Automateの利用開始まで" # 記事のタイトル
emoji: "💪" # アイキャッチとして使われる絵文字（1文字だけ）
type: "tech" # tech: 技術記事 / idea: アイデア記事
topics: ["Office365","Power Automate","RPA","iPaaS"] # タグ。["markdown", "rust", "aws"]のように指定する
published: true # 公開設定（falseにすると下書き）
publication_name: "protooutstudio"
---

作業の自動化などがノーコードで開発できるMicrosoftのPower Automateの利用準備をしていきましょう。

## 1. Office 365 E3以上のアカウントの準備

Power Appsの利用を試すにあたり、`Office365 E3`のアカウント作成をする必要があります。無料で利用する場合は以下の手順で試用版アカウントを作成しましょう。

https://zenn.dev/protoout/articles/42-office365-trial-setup

## 2. Power Automateの画面を開く

以下にアクセスします。

https://make.powerautomate.com/home

以下のような画面が表示されます。
画面真ん中の`開始する`ボタンを押して進みます。

> ![](https://i.gyazo.com/c6fffbac90da8053a1029c303d308fc4.png)

次に以下のような画面が表示されます。これがPower Automateのホーム画面になります。

> ![](https://i.gyazo.com/7fa0852c3485e5f1ec62a3e619331136.png)

この画面が開けていれば準備としてはいったん完了です。

## 3. テンプレートを眺める

左のメニューのテンプレートを選択しましょう。

https://make.powerautomate.com/templates

さまざまな業務の自動化レシピの例が掲載されています。一覧を眺めてイメージを膨らませましょう。

> ![](https://i.gyazo.com/2951a74859b95bd0b48191429760c165.png)

事前準備は以上です。

お疲れ様でした。