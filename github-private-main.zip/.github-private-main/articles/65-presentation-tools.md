---
title: "プレゼンで使えるツールまとめ"
emoji: "😃" 
type: "idea"
topics: ["Slide","presentation"]
published: true
publication_name: "protooutstudio"
---

プレゼンで利用できるツールを紹介します。

随時更新です。

- Microsoft PowerPoint
- Keynote
- Google Slides

はメジャーなので対象外です。

## スライド作成系

### Canva

https://www.canva.com/

元々はサムネイルを作るツールでしたが、動画、Webサイトなど色々と作れるように進化しています。

プレゼンも作れます。

### slides

https://slides.com/

Web上でスライド作成ができるツールです。

シンプルな使い方でおしゃれなプレゼンができます。

### Prezi

https://prezi.com/ja/

スライドという概念ではなく、一枚の大きな模造紙に絵を描いて、ズームインズームアウトをすることで話を進めるツールです。

パワポなどの紙芝居的な概念とは異なるのでとっかかりにくいかもしれないですが、独特のアニメーションになるのでインパクトは強いです。

### Pitch

https://pitch.com/

最近流行ってきてるツールです。

おしゃれなテンプレートが多いです。

### Slidev

https://sli.dev/

開発者向けのプレゼンツールです。

Markdownで記述した文書から美しいスライドを生成できます。

### reveal.js

https://revealjs.com/

Markdownで記述した文章からシンプルにスライドが作成できます。
Slides.comに見た目が似ています。

## アンケート系

### slido

https://www.slido.com/jp

リアルタイムに視聴者からアンケートを回収できるツールです。


## スライド置き場

### SlideShare

https://slideshare.net/

プレゼン資料を公開して置いておくツールといえばスライドシェアが老舗です。長らくLinkedInの傘下だったこともあり、ビジネス層も多く利用している印象です。

### SperkerDeck

https://speakerdeck.com/

GitHubが運営しているということもあり、開発者界隈だとほぼ一択になっています。