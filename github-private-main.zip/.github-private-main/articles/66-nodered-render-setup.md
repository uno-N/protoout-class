---
title: "Renderのアカウント作成とNode-REDのインストール"
emoji: "🏊‍♀️"
type: "tech"
topics: ["Render","PaaS","Node.js","Node-RED"]
published: true
---

- **Node-RED**は「ローコード開発ツール」や「ビジュアルプログラミング」などと言われていて、いわゆるソースコードをほぼ書くことなく色々なソフトウェア開発が行えます。  
  通常はパソコンにインストールし、Webブラウザをインターフェース（操作画面）として利用するのですが、今回はクラウド環境にインストールできるような仕組み（PaaS）を利用してNode-REDを扱ってみます。
- **Render**は、静的サイトやWebアプリなどを簡単に運用できるPaaS（サーバー）です。  
  無料プランでは、最後のアクセスから15分経過するとスリープ状態になったり、デプロイ（編集状態の反映）が遅かったりするなどの制限がありますが、個人開発で試す程度であれば十分でしょう。

## Renderアカウントの作成をする

1. https://render.com/ にアクセスし、`GET STARTED FOR FREE`からアカウントを作成してください。  
  [![Image from Gyazo](https://i.gyazo.com/3386b67f649906ff9819abe6577b13eb.png)](https://gyazo.com/3386b67f649906ff9819abe6577b13eb)
2. Googleアカウントで登録をしましょう。  
  GitHubアカウントでも登録ができますが、GitHubのアカウントを作成してから日が浅いとうまくRenderアカウント作成ができない場合があるため、できるだけGoogleアカウントを使用するようにしてください。  
  [![Image from Gyazo](https://i.gyazo.com/b83e58e1041cd84982c470ddb2872f67.png)](https://gyazo.com/b83e58e1041cd84982c470ddb2872f67)
3. 自分のGmailアドレスを確認し、`COMPLETE SIGN UP`をクリックします。Renderからのアップデート情報が欲しい方はチェックボックスを入れておくといいでしょう。  
  [![Image from Gyazo](https://i.gyazo.com/24ff964417f3a52a91318a2dc73685c6.png)](https://gyazo.com/24ff964417f3a52a91318a2dc73685c6)
4. Gmailを確認します。24時間以内にURLをクリックするよう求められていますので、クリックして接続します。  
  メールが届かない場合は、迷惑フォルダーなども確認しましょう。
5. もう一度 https://render.com/ にアクセスし、ダッシュボードが表示されれば登録完了です。  
  [![Image from Gyazo](https://i.gyazo.com/67dc3bae7d1f0a85841647c51f7f9f26.png)](https://gyazo.com/67dc3bae7d1f0a85841647c51f7f9f26)

## RenderにNode-REDのインストールをする

1. Renderの`Web Services`を使用するので、`New Web Service`をクリックします。  
  [![Image from Gyazo](https://i.gyazo.com/f078e8b21acf703d0360b1eb1cb21b06.png)](https://gyazo.com/f078e8b21acf703d0360b1eb1cb21b06)
2. `Connect GitHub`をクリックして、GitHubと連携します。  
  [![Image from Gyazo](https://i.gyazo.com/9ddb4912f65d42211a24d89da2179b95.png)](https://gyazo.com/9ddb4912f65d42211a24d89da2179b95)
3. `Authorize Render`をクリックします。
  もし以下のような表示が出てきたら、自分のGitHubアカウントをクリックし、  
  [![Image from Gyazo](https://i.gyazo.com/f40523e52b4f1627e77fafad7d41d990.png)](https://gyazo.com/f40523e52b4f1627e77fafad7d41d990)  
  `Install` をクリックして進めてください。  
  [![Image from Gyazo](https://i.gyazo.com/73cf8eac65da2d7af5700005bb5f9084.png)](https://gyazo.com/73cf8eac65da2d7af5700005bb5f9084)
  この場合ページが戻ってしまうことがあるので、そうなったらもう一度 `Web Services` をクリックしてください。
5. 接続ができたら、`Public Git repository`のURL記入欄に以下をコピペし、`Continue`をクリックします。  
    ```
    https://github.com/n0bisuke/node-red-express
    ```  
6. `Name`のフォームに`nodered-protoout-自分の名前`のように独自の名前で書きます。人と被らないようにすればよいです。  
  そして、Regionを`Singapore`に設定します。
  `Runtime`は`Node`に変更し、`Start Command`は`npm start`と書き込みます。  
  [![Image from Gyazo](https://i.gyazo.com/6c6d636e0ec2c80f31d620950b89ecc4.png)](https://gyazo.com/6c6d636e0ec2c80f31d620950b89ecc4)
7. `Create Service`をクリックするとインストールが始まるので、数分待機します。  
  [![Image from Gyazo](https://i.gyazo.com/b3e8024c67c616f90de36733d713a549.png)](https://gyazo.com/b3e8024c67c616f90de36733d713a549)
  `Live`という表示が出たら完了です。  
  [![Image from Gyazo](https://i.gyazo.com/49546f62631351da08eb23180b51f7fb.png)](https://gyazo.com/49546f62631351da08eb23180b51f7fb)
8. 先ほど自分の名前を付けたサービスの下にURLが表示されているので、それをクリックします。  
  [![Image from Gyazo](https://i.gyazo.com/1dfa669452708d8dc3ffe43ef48122a5.png)](https://gyazo.com/1dfa669452708d8dc3ffe43ef48122a5)
9. このような表示がでたらNode-REDのインストール完了です。  
  これはあなた専用のURLです。あとからいつでも接続して利用できるよう、**URLを控えておきましょう**。  
  [![Image from Gyazo](https://i.gyazo.com/b2831ae062e282390b3fa736e7ed2ec0.png)](https://gyazo.com/b2831ae062e282390b3fa736e7ed2ec0)

以上で、Node-REDがRenderに正しくインストールができています。  
お疲れ様でした。
