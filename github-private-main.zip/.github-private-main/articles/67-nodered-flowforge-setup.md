---
title: "FlowForgeアカウントの作成とNode-REDのインストール"
emoji: "🏊‍♀️"
type: "tech"
topics: ["FlowForge","PaaS","Node-RED"]
published: true
---

FlowForgeは、複数人のチームでNode-REDが扱える環境を、あらゆる環境に対してシームレスに提供してくれるサービスです。

- ローカル（自分のPC）上で動かす場合には、オープンソースとして無料でインストールすることができます。DockerやKubernetesといった仮想環境での提供もなされています。
- パブリッククラウド上での提供もされており、こちらは基本有償ですが自分のPCにインストールする手間がありません。ユーザー登録後30日間は、クレジットカード情報の入力も必要なく無償試用ができます。

## FlowForgeアカウントの作成をする

1. https://flowforge.com/ にアクセスし、`GET STARTED FOR FREE`からアカウントを作成してください。  
  [![Image from Gyazo](https://i.gyazo.com/751be296bba57522c29ed288633acd54.png)](https://gyazo.com/751be296bba57522c29ed288633acd54)
2. 必要な情報を入力してアカウントを作成しましょう。  
  記事執筆時点ではソーシャルログインに対応していないため、1つずつ入力する必要があります。  
  [![Image from Gyazo](https://i.gyazo.com/c30a9c0d53159be0285bbb0b13ae5687.png)](https://gyazo.com/c30a9c0d53159be0285bbb0b13ae5687)
3. メールが届きますので、メールの中のリンクをクリックします。  
  [![Image from Gyazo](https://i.gyazo.com/0cc5546fb634b901d425cb5be0498e2f.png)](https://gyazo.com/0cc5546fb634b901d425cb5be0498e2f)
4. クリックして新しいページを開き、真ん中にあるボタン `VERIFY MY EMAIL` をクリックします。そのあと、先ほど登録したユーザーIDかメールアドレスをクリックして `LOGIN` ボタンをクリックすると、パスワードを入力する欄が追加で出てくるので、パスワード入力してログインしましょう。  
  [![Image from Gyazo](https://i.gyazo.com/ad5b16d783abd56177c78c461e68b682.png)](https://gyazo.com/ad5b16d783abd56177c78c461e68b682)
  
5. 以下のような画面になっていればOKです。  
  [![Image from Gyazo](https://i.gyazo.com/036ff8b85fdc5761d831754d692bc3cd.png)](https://gyazo.com/036ff8b85fdc5761d831754d692bc3cd)

## Node-REDのインストールをする

1. `+ Create Apprication`をクリックします。  
  [![Image from Gyazo](https://i.gyazo.com/1ca790ca13b7bbe683256862eb4b57ca.png)](https://gyazo.com/1ca790ca13b7bbe683256862eb4b57ca)
2. 以下のようにアプリ名を入力して作成します。  
  [![Image from Gyazo](https://i.gyazo.com/b61d8196d293a8c688de70046606baf9.png)](https://gyazo.com/b61d8196d293a8c688de70046606baf9)
3. 作成直後は「インストール中です」のような表示が出ますが、完了すると以下のように `running` という表示になります。それが確認できたら `Open Editor` をクリックしてください。  

  [![Image from Gyazo](https://i.gyazo.com/d4d93e240bcb8f58ed3ba971076943a5.png)](https://gyazo.com/d4d93e240bcb8f58ed3ba971076943a5)
4. 新しいタブが開いて、Node-REDが表示されたら完了です。URLを控えておきましょう。  
  [![Image from Gyazo](https://i.gyazo.com/712532fd37c0a7d363a074a5e6308f50.png)](https://gyazo.com/712532fd37c0a7d363a074a5e6308f50)

以上で、FlowForgeのクラウド上でNode-REDを利用することができるようになりました。

無償で使えるのは登録後30日間までなので、それが過ぎたら課金するか、自分のPC上にインストールして利用することを検討しましょう。

お疲れ様でした。