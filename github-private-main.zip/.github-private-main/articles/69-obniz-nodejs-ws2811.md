---
title: "obnizでフルカラーLEDを制御（WS2811）"
emoji: "🚨"
type: "tech"
topics: ["JavaScript","obniz","IoT","電子工作","Node.js"]
published: true
---

## 1. フルカラーLED

通常の単色LEDと違ってRGB値を元に色の制御ができるLEDです。

PL9823-F8というフルカラーLEDに組み込まれている、WS2811というICを制御します。

> PL9823-F8
> https://akizukidenshi.com/catalog/g/gI-08412/
> ![](https://i.gyazo.com/c3acae1ba6a1dddfe7c249789cf8cc61.png)

## 2. 配線

フルカラーLEDの準備をします。フルカラーLEDのピンは4本あり、この写真のように置きましょう。このスタートが重要です。

> ![](https://i.gyazo.com/5e4ff0d2a567250f2f8761b2c8a9f2f1.jpg)

1番右のピンは利用しないため、目印に曲げておきます。

> ![](https://i.gyazo.com/0253a0e95e62455c88f0f60194dcdf75.jpg)

- LEDのピンを上方向にしたとき、脚の長さが「短・長・中・短」の順となる角度にLEDをまず置きます。
- その状態で、一番左のピンを軽く曲げてしまいます。（使用しないピンです）
- 一番長い脚をobnizの0番、
- 中ぐらいの脚をobnizの1番、
- 一番短い足をobnizの2番に接続します。

## 3. JavaScriptプログラム（Node.js）

obnizの公式ドキュメントはこちらです。

https://docs.obniz.com/ja/sdk/parts/WS2811/README.md

任意のファイル名で.jsファイルを作成しましょう。

```js
'use strict'

const Obniz = require('obniz');
const obniz = new Obniz(process.env.OBNIZ_ID);

obniz.onconnect = async function () {
  // RGB LEDを呼び出す
  const rgbled = obniz.wired('WS2811', {gnd:0, vcc: 1, din: 2});

  // ディスプレイ処理
  obniz.display.clear();  // 一旦クリアする
  obniz.display.print('Hello obniz!');  // Hello obniz!という文字を出す

  // スイッチの反応を常時監視
  obniz.switch.onchange = function(state) {
    if (state === 'push') {
      // 押されたとき
      console.log('pushed');
      // ディスプレイ処理
      obniz.display.clear();  // 一旦クリアする
      obniz.display.print('pushed');  // pushed という文字を出す
      // RGB LED 赤色 R値 255 G値 0 B値 0 なので rgbled.rgb(255, 0, 0);
      // 他のカラーコード参考 http://www.netyasun.com/home/color.html
      // green をみて、R値 0 G値 255 B値 0 の場合、なので rgbled.rgb(0, 255, 0);
      rgbled.rgb(255, 0, 0);
    } else if (state === 'none') {
      // none で押してないとき
      obniz.display.clear();  // 一旦クリアする
      // RGB LED OFF
      // RGB値をどれも点灯しない = 0というやり方
      rgbled.rgb(0, 0, 0);
    }
  }
}
```

## 実行結果

初回だけ青く光り、obnizのスイッチを押すと赤色に光ります。

> https://www.instagram.com/p/CB8vN1njTMU/
> ![](https://i.gyazo.com/09d9461448a1fd916aba96c11ed4672c.gif)