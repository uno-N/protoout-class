---
title: "obnizで温度センサーを制御（LM60BIZ）"
emoji: "🌡️"
type: "tech"
topics: ["JavaScript","obniz","IoT","電子工作","Node.js"]
published: true
---

## 1. 温度センサー

温度を測ることが出来るセンサーです。

温度だけじゃなく、湿度も一緒に測れるものがあったり、物によって何度から何度を測ることができる範囲が変わったりと性能が色々と違うので、用途と予算によってどんなセンサーを使うと良いか判断しましょう。

今回や精度は低いですが、安く試せるLM60BIZというセンサーを使います。

> LM60BIZ
> https://akizukidenshi.com/catalog/g/gI-02490/
> ![](https://i.gyazo.com/fd38d53e1cf6c095305d79a865807195.png)

## 2. 配線

脚が三つある黒いセンサーです。

> ![](https://i.gyazo.com/2bed351ae7aa770842e027e732327bda.jpg)

このように配線します。

> ![](https://i.gyazo.com/f4145742b24217c4ff4d07c9300271dd.png)

型番が記載されている面を"オモテ"にしてください。

> ![](https://i.gyazo.com/33f518b0117f6c62ab9c3a3ed26c5a0c.jpg)

左側から0,1,2のピンに差し込みます。
向きは気をつけてください。

**逆に差し込むとセンサーが高温になり火傷のリスクがあります。**

## 3. JavaScriptプログラム（Node.js）

obnizの公式ドキュメントはこちらです。

https://docs.obniz.com/ja/sdk/parts/LM60/README.md

任意のファイル名で.jsファイルを作成しましょう。

```js
'use strict'

const Obniz = require('obniz');
const obniz = new Obniz(process.env.OBNIZID);

obniz.onconnect = async () => {
    const tempsens = obniz.wired('LM60', { gnd: 0, output: 1, vcc: 2 });
    tempsens.onchange = function (temp) {
        console.log(temp);
    };
}
```

## 実行結果

ターミナルに温度が表示されたらOKです。