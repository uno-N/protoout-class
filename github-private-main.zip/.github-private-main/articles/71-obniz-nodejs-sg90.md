---
title: "obnizでサーボモータを制御（SG90）"
emoji: "⚙️"
type: "tech"
topics: ["JavaScript","obniz","IoT","電子工作","Node.js"]
published: true
---

電源ピンを利用するためobniz Boardではなく、[obniz Board 1Y](https://amzn.to/47HzQcr)での説明になります。

## 1. サーボモーター

小規模なIoTでもっともよく使われる「アクチュエータ」の1つです。 通常のモーターは電流を流すと回転し続けますが、サーボモータは特殊な電流を流すことで任意の角度を指定して回転させることができます。

設定可能な最大角度・回転トルク（強さ）・設定角度の細かさなどは、サーボモータの性能によって大きく変わってきます。

今回はホビー用途で使えて汎用的なモデルの`SG90`を利用します。

> SG90
> https://akizukidenshi.com/catalog/g/gM-08761/
> ![](https://i.gyazo.com/456747ffcb4962fe068e239656225e6a.png)

## 2. 配線

このように青い本体とジャンパワイヤがついています。

> ![](https://i.gyazo.com/6e51a64cd7b7ddbf16a7937a8561ee3a.jpg)

ジャンパワイヤを3本用意します。色はなんでも良いですが、ここでは仮に白、赤、青を使って説明します。

> ![](https://i.gyazo.com/40c0c435e5916504d78926791773b723.jpg)

以下それぞれ配線します。

- サーボモーター側のジャンパワイヤ茶: ジャンパワイヤ白
- サーボモーター側のジャンパワイヤ橙: ジャンパワイヤ赤
- サーボモーター側のジャンパワイヤ黄: ジャンパワイヤ青

> ![](https://i.gyazo.com/77ae0d964bfc433cd7275a72a08f0b35.jpg)

次にジャンパワイヤをobnizに接続します。
- ジャンパワイヤ赤: obniz Board 1Yの`プラス`ピン
- ジャンパワイヤ白: obniz Board 1Yの`マイナス`ピン
- ジャンパワイヤ青: obniz Board 1Yの2ピン

> ![](https://i.gyazo.com/53e5a5a9f49b7d5419192b3f63f0e806.jpg)

最後に、回転してるかわかりやすいようにサーボにプラスチックパーツをつけましょう。（このパーツのことをサーボホーンといいます）

好きな形状のもので構いません。

> ![](https://i.gyazo.com/3cdd335a66f606c2ec47128ec8119687.jpg)

## 3. JavaScriptプログラム（Node.js）

obnizの公式ドキュメントはこちらです。

https://docs.obniz.com/ja/sdk/parts/ServoMotor/README.md

任意のファイル名で.jsファイルを作成しましょう。

```js
'use strict'

const Obniz = require('obniz');
const obniz = new Obniz(process.env.OBNIZ_ID);

obniz.onconnect = async () => {
    const servo = obniz.wired('ServoMotor', {signal:2});

    const main = async () => {
        servo.angle(0);
        await obniz.wait(1000);
        servo.angle(180); // half position
        await obniz.wait(1000);
    }

    setInterval(main, 1000);
}
```

## 実行結果

サーボモータが動いたらOKです。

## 補足

### スライダー制御

公式のスターターガイドを元にスライダー制御を試すのも楽しいと思います。

https://docs.obniz.com/ja/guides/obniz-starter-guide/parts-library/servo-motor

### 旧型のobnizボードの場合

ちなみに、1Y以外の旧式obnizボードの場合は以下の公式サンプルを参考にしましょう。

配線とプログラム両方違うかつ、ブレッドボード中継をさせるという裏技が必要になる場合があります。

https://obniz.io/ja/lessons/lessons/lessons_servo_motor