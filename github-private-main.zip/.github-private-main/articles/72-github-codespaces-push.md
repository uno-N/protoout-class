---
title: "GitHub CodespacesでGitHubにPushする"
emoji: "💻"
type: "tech"
topics: ["GitHub Codespaces","GitHub","Git","VS Code"]
published: true
---

Git周り初めての人向けの解説です。

## 1. GitHub Codespacesって？

こちらを読みましょう。

https://zenn.dev/protoout/articles/68-github-codespaces-setup

## 2. GitHub Codespacesに置いたままだとコードが消える

すぐには消えませんが、しばらく使ってないと立ち上げてるマシンが消されてしまいます。

消えちゃう前にGitHubにプログラムを保存しておきましょう。

## 3. Git周り初めての人向けの解説です

- `.gitignore`ファイルを作成

プロジェクトのルート（自分が見えてるフォルダの最上層）`.gitignore`という名前でファイルを作成して、保存しましょう。

```.gitignore
node_modules
.env
```

このファイルに記載されているファイルやフォルダは保存対象外になります。
Node.jsを利用する際の依存ライブラリ（npm installしたときに入ってくるファイルたち）が格納されている`node_modules`フォルダは通常Git側に保存はしません。

- プッシュする

枝マークを選択 -> コミットメッセージに何か記述（更新など） -> Coomit&Pushを選択

> ![](https://i.gyazo.com/c31cf535b72d4e3e89bb2ab5422deda3.png)

> ![](https://i.gyazo.com/7cbd84fb4ee6078d544a8e19f7d4dd91.png)

これでGitHub側にプログラムなどがプッシュされます。

GitHub Codespacesのマシンが消えてもコードは残ります。

