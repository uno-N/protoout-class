---
title: "Hugging Faceにサインアップ & アクセストークンを取得する"
emoji: "🤗"
type: "tech"
topics: ["HuggingFace", "AI", "機械学習"]
published: true
---

## Hugging Faceにサインアップする

> サインアップ済みの方は、ログインしてください

### 操作

1. https://huggingface.co/ を開く
1. `Sign Up`を選ぶ
1. メールアドレスとパスワードを入力して先に進む
1. 必須項目を入力して先に進む
1. メールが届くので、確認リンクを開く
   1. メールタイトル：`[Hugging Face] Click this link to confirm your email address`
1. 画面に`Your email address has been verified successfully.`と表示されればOK

### イメージ

![image](https://i.imgur.com/uZowScN.png)

![image](https://i.imgur.com/A0wcXry.png)

![image](https://i.imgur.com/s5HsnzC.png)

![image](https://i.imgur.com/KIWNAAE.png)

![image](https://i.imgur.com/t8WanHw.png)

![image](https://i.imgur.com/DLGSNni.png)

### 詳細

- `Username`は他の人と重複しないユニークなものを設定しましょう

## アクセストークンを発行する

:::message alert
アクセストークンは他の人に教えないようにしましょう
悪用される恐れがあります
:::

### 操作

- （サインアップまたはログインしておく）
- https://huggingface.co/settings/tokens を開く
- `New token`を選ぶ
- 必須項目を入力して先に進む
- トークンが発行されるのでコピーする
  - `hf_{長い文字}`のような文字列がコピーされていればOKです

### イメージ

![image](https://i.imgur.com/DnXitYL.png)

![image](https://i.imgur.com/OjEQfyu.png)

![image](https://i.imgur.com/9p2Jjnl.png)
