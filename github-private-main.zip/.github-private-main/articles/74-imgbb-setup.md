---
title: "imgBBにサインインする"
emoji: "📷"
type: "tech"
topics: ["imgbb"]
published: true
---

## imgBBにサインインする

imgBBは画像をアップロードして公開できるサービスです

https://imgbb.com/

### 操作

- https://imgbb.com/ を開く
- サインインをクリックする
- 別アカウントでサインイン → Googleを選ぶ
- 自分のアカウントが表示されたらOK

### イメージ

![](https://i.ibb.co/HqdM4Mj/2023-11-03-15-19-49.png)

![](https://i.ibb.co/DRzB773/Monosnap-Img-BB-2023-11-03-15-20-45.png)

![](https://i.ibb.co/vYjm5tX/Monosnap-Takahiro-MITSUOKA-takahiro-mitsuok-Img-BB-2023-11-03-15-23-12.png)

### 詳細

- サインインはFacebookやアカウント作成してもOKです

> Twitter（現X）はエラーになりました。今は使えないようです。
