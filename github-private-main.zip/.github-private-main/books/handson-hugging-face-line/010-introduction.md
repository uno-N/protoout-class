---
title: "利用するサービス"
---

## 1-1. LINE

### 1-1-1. ざっくり説明

- 日本人の80〜90%の方が利用しているコミュニケーションアプリ
- Messaging APIを利用してBotを作ることができる
- LINEのUIを活用してアプリを実現できる & QRコードを読み取るだけで利用開始できるため、プロトタイプに向いている

### 1-1-2. 関連リンク

https://line.me/ja/

https://developers.line.biz/ja/services/messaging-api/

## 1-2. Hugging Face

### 1-2-1. ざっくり説明

- `Hugging Face Hub`
  - トレーニング済みのモデルやデータセットを共有し、探索するためのプラットフォーム
- `Spaces`
  - ユーザーが機械学習モデルを簡単にデプロイし、インタラクティブなアプリケーションとして公開できるプラットフォーム
- `Inference API`
  - APIを通じて、機械学習の知識がなくてもプロトタイピングにモデルを活用することができる

### 1-2-2. 関連リンク

https://huggingface.co/

https://huggingface.co/docs/api-inference/index

## 1-3. Make

### 1-3-1. ざっくり説明

- iPaaS
- ノーコードでサービスとサービスをつなぎ合わせて利用することができる
- Webhookが使えるので、LINE Botのバックエンドとしても利用できる

### 1-3-2. 関連リンク

https://www.make.com/en

https://www.youtube.com/watch?v=LjN0VW1bg5w