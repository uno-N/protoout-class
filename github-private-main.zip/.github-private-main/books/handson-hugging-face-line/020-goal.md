---
title: "完成イメージ"
---

## 2-1. テキストから画像を生成しよう（TextToImage）

https://twitter.com/mitsuoka0423/status/1721950557030760606

## 2-2. 画像をテキストに変換しよう（ImageToText）

https://twitter.com/mitsuoka0423/status/1721949815901438115

## 2-3. 音声をテキストに変換しよう（AudioToText）

https://twitter.com/mitsuoka0423/status/1721949869873741934
