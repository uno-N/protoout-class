---
title: "事前準備"
---

## 3-1. 必須（全員実施）

リンク先の手順に従い、各サービスの利用準備を行ってください
アクセストークンは後で使いますのでクリップボードやメモ帳などにコピーしておきましょう

### 3-1-1. チャネルアクセストークンを取得する（LINE）

https://zenn.dev/protoout/articles/16-line-bot-setup

### 3-1-2. アクセストークンを取得する（Hugging Face）

https://zenn.dev/protoout/articles/73-hugging-face-setup

### 3-1-3. アカウント作成（Make）

https://zenn.dev/protoout/articles/12-integromat-signup

## 3-2. 任意（必要な人だけ実施）

### 3-2-1. imgBBにサインインする

https://zenn.dev/protoout/articles/74-imgbb-setup