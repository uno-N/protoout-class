---
title: "ハンズオン - オウム返しするBotを作ろう"
---

## 4-1. この章の完成イメージ

### 4-1-1. シナリオ

![image](https://i.imgur.com/zeWTUDa.png)

### 4-1-2. LINE Bot

[![Image from Gyazo](https://i.gyazo.com/94e5bda2678dcf5bbc7a0154eeac8b07.gif)](https://gyazo.com/94e5bda2678dcf5bbc7a0154eeac8b07)

## 4-2. 事前準備

- [LINE公式アカウントの作成 / LINE Botの初め方](https://zenn.dev/protoout/articles/16-line-bot-setup) を実施
  - チャネルアクセストークンをコピーしておいてください

## 4-3. makeでシナリオ作成を開始する

### 4-3-1. 前提

- [Make](https://www.make.com/en/login) で操作します

### 4-3-2. イメージ

![image](https://i.imgur.com/A4lnHbh.png)

![image](https://i.imgur.com/PfGuDM3.png)

![image](https://i.imgur.com/71Jv9GF.png)

## 4-4. `LINE`モジュールの`Watch Events`を追加 & 設定する

### 4-4-1. イメージ

![image](https://i.imgur.com/0KuGxkQ.png)

![image](https://i.imgur.com/VDMcCof.png)

![image](https://i.imgur.com/Cj5laiY.png)

![image](https://i.imgur.com/Ow07yBD.png)

![image](https://i.imgur.com/feQ1eAF.png)

![image](https://i.imgur.com/JZQxQo8.png)

![image](https://i.imgur.com/JsdcYTD.png)

![image](https://i.imgur.com/2xz781o.png)

![image](https://i.imgur.com/P9ReEPw.png)

> くるくるしてればOK

## 4-5. 作成したチャネルにWebhook URLを設定する

### 4-5-1. 前提

- [LINE Developesコンソール](https://developers.line.biz/console/)で操作します
  - ログインがまだの方は、ログインしておいてください

### 4-5-2. イメージ

![image](https://i.imgur.com/6gLYAwO.png)

![image](https://i.imgur.com/CkPMYbG.png)

![image](https://i.imgur.com/MXdxHOe.png)

![image](https://i.imgur.com/02lLRRA.png)


## 4-6. `LINE`モジュールの`Send a Reply Message`を追加 & 設定する

### 4-6-1. 前提

- makeに戻ります

### 4-6-2. イメージ

![image](https://i.imgur.com/yShsjBh.png)

![image](https://i.imgur.com/J7cKn3A.png)

![image](https://i.imgur.com/bYaSqkZ.png)

![image](https://i.imgur.com/ryLyuNB.png)

![image](https://i.imgur.com/cVslXPH.png)

![image](https://i.imgur.com/r5XHXVd.png)

> くるくるしてればOK

## 4-7. LINEにメッセージを送る

### 4-7-1. イメージ

![image](https://i.imgur.com/sxa02C3.png)

> 送った文字がそのまま返ってくればOK

## 4-8. 次のステップ

オウム返しができた方は、

- [テキストから画像を生成しよう（TextToImage）](https://zenn.dev/protoout/books/handson-hugging-face-line/viewer/042-text2image-bot)
- [画像からテキストを生成しよう（ImageToText）](https://zenn.dev/protoout/books/handson-hugging-face-line/viewer/044-image2text-bot)
<!-- NOTE: 間に合わなかった -->
<!-- - [音声からテキストを生成しよう（AudioToText）](https://zenn.dev/protoout/books/handson-hugging-face-line/viewer/046-audio2text-bot) -->

のうち、好きなステップに進みましょう。
