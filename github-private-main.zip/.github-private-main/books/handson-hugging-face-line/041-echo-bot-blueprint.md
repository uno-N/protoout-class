---
title: "ハンズオン - オウム返しするBotを作ろう（Blueprint）"
---

## 5-1. この章の完成イメージ

### 5-1-1. シナリオ

![image](https://i.imgur.com/zeWTUDa.png)

### 5-1-2. LINE Bot

[![Image from Gyazo](https://i.gyazo.com/94e5bda2678dcf5bbc7a0154eeac8b07.gif)](https://gyazo.com/94e5bda2678dcf5bbc7a0154eeac8b07)

## 5-2. 事前準備

- [LINE公式アカウントの作成 / LINE Botの初め方](https://zenn.dev/protoout/articles/16-line-bot-setup) を実施
  - チャネルアクセストークンをコピーしておいてください 

## 5-3. シナリオ設定ファイルをダウンロードする

### 5-3-1. 操作

- 下記URLを開き、`blueprint.json`をデスクトップに保存する
  - https://drive.google.com/file/d/12Dch86SiSWSWeP2zZBSxG_HQrZI9Ztxd/view?usp=drive_link

### 5-3-2. イメージ

![image](https://i.imgur.com/A4rqXlq.png)

## 5-4. makeでシナリオ作成を開始する

### 5-4-1. 操作

- [Make](https://www.make.com/en/login) を開き、ログインします

### 5-4-2. イメージ

![image](https://i.imgur.com/A4lnHbh.png)

![image](https://i.imgur.com/PfGuDM3.png)

![image](https://i.imgur.com/71Jv9GF.png)

> このような画面になっていればOK

## 5-5. オウム返しするBotのシナリオを読み込む

### 5-5-1. 操作

- 画面下部の`...` → `Import Blueprint`を選択する
- デスクトップの`blueprint.json`を選択する
- `Save`を選択する

### 5-5-2. イメージ

![image](https://i.imgur.com/DoGiyYG.png)

![image](https://i.imgur.com/gW4Et7I.png)

![image](https://i.imgur.com/bveC3mQ.png)

![image](https://i.imgur.com/Rmzipj6.png)

![image](https://i.imgur.com/tCDSxJ0.png)

> `LINE`モジュールが2つ並んでいればOK

## 5-6. `LINE`モジュール`Watch Events`を設定する

### 5-6-1. イメージ

![image](https://i.imgur.com/WctxK7a.png)

![image](https://i.imgur.com/5HFGZDQ.png)

![image](https://i.imgur.com/czKCppI.png)

> 事前準備でコピーしておいたチャネルアクセストークンをコピペする

![image](https://i.imgur.com/mdWk4VP.png)

![image](https://i.imgur.com/dNXu1e5.png)

> 表示されているURLをコピーしておきます

## 5-7. `LINE`モジュール`Send a Reply Message`を設定する

### 5-7-1. イメージ

![image](https://i.imgur.com/C5GICpp.png)

![image](https://i.imgur.com/Sbr0RdT.png)

![image](https://i.imgur.com/VQsCAfa.png)

![image](https://i.imgur.com/giNNB5I.png)

![image](https://i.imgur.com/aUZN97n.png)

> くるくるしてればOK

## 5-8. 作成したチャネルにWebhook URLを設定する

### 5-8-1. 前提

- [LINE Developesコンソール](https://developers.line.biz/console/)で操作します
  - ログインがまだの方は、ログインしておいてください

### 5-8-2. イメージ

![image](https://i.imgur.com/6gLYAwO.png)

![image](https://i.imgur.com/CkPMYbG.png)

> コピーしておいたURLをペーストします

![image](https://i.imgur.com/MXdxHOe.png)

![image](https://i.imgur.com/02lLRRA.png)

> 「成功」と表示されたらOK

## 5-9. LINEにメッセージを送る

### 5-9-1. イメージ

![image](https://i.imgur.com/giNNB5I.png)

> もう一回くるくるさせます

![image](https://i.imgur.com/sxa02C3.png)

> 送った文字がそのまま返ってくればOK

## 5-10. 次のステップ

オウム返しができた方は、

- [テキストから画像を生成しよう（TextToImage）](https://zenn.dev/protoout/books/handson-hugging-face-line/viewer/042-text2image-bot)
- [画像からテキストを生成しよう（ImageToText）](https://zenn.dev/protoout/books/handson-hugging-face-line/viewer/044-image2text-bot)
<!-- NOTE: 間に合わなかった -->
<!-- - [音声からテキストを生成しよう（AudioToText）](https://zenn.dev/protoout/books/handson-hugging-face-line/viewer/046-audio2text-bot) -->

のうち、好きなステップに進みましょう。
