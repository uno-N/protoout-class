---
title: "ハンズオン - テキストから画像を生成しよう（TextToImage）"
---

## 6-1. この章の完成イメージ

### 6-1-1. シナリオ

![](https://i.ibb.co/Gs7NGp9/Monosnap-Hugging-Face-x-LINE-Text-To-Image-Make-2023-11-03-15-53-45.png)

### 6-1-2. LINE Bot

https://twitter.com/mitsuoka0423/status/1721950557030760606

## 6-2. 事前準備

- [ ] [ハンズオン - オウム返しするBotを作ろう｜【好きなモデルで作る】Hugging Face x LINE Botハンズオン【ノーコード】](https://zenn.dev/protoout/books/handson-hugging-face-line/viewer/040-echo-bot)
- [ ] [imgBBにサインインする](https://zenn.dev/protoout/articles/74-imgbb-setup)

## 6-3. `Hugging Face`モジュールを追加する

### 6-3-1. 操作

- `Hugging Face`モジュールを追加し、設定する

### 6-3-2. イメージ

![](https://i.ibb.co/CJhxDqf/Monosnap-Hugging-Face-x-LINE-Text-To-Image-Make-2023-11-03-16-10-47.png)

![image](https://i.imgur.com/4Yuqior.png)

### 6-3-3. 詳細

| 項目 | 値 | 備考 |
| -- | -- | -- | 
| Connection | 追加したConnectionを選択する | `Add`ボタンからConnectionを追加する。APIトークンは[ここ](https://huggingface.co/settings/tokens)で取得する |
| URL | `/models/runwayml/stable-diffusion-v1-5` |  |
| Headers/Item 1/Name | `Content-Type` |  |
| Headers/Item 1/Value | `application/json` |  |
| Body | `{"inputs": "[LINEで送ったメッセージ]"}` | `LINE`モジュールのアウトプットを利用する |

## 6-4. `imgBB`モジュールを追加する

### 6-4-1. 操作

- `imgBB`モジュールを追加し、設定する

### 6-4-2. イメージ

![](https://i.ibb.co/12tYqmt/Monosnap-Hugging-Face-x-LINE-Text-To-Image-Make-2023-11-03-16-18-48.png)

![](https://i.ibb.co/r5CYyt5/Monosnap-Hugging-Face-x-LINE-Text-To-Image-Make-2023-11-03-16-19-24.png)

### 6-4-3. 詳細

| 項目 | 値 | 備考 |
| -- | -- | -- | 
| Connection | 追加したConnectionを選択する | `Add`ボタンからConnectionを追加する。APIトークンは[ここ](https://api.imgbb.com/)で取得する |
| File name | `Headers: date` | `Hugging Face`モジュールのアウトプットを利用する |
| Data | `Body` | `Hugging Face`モジュールのアウトプットを利用する |

## 6-5. `LINE`モジュールを変更する

### 6-5-1. 操作

- 返信するメッセージの内容を画像にする

### 6-5-2. イメージ

![](https://i.ibb.co/vjxsrBb/image.png)

### 6-5-3. 詳細

| 項目 | 値 | 備考 |
| -- | -- | -- | 
| Connection | 変更なし |  |
| Reply Token | 変更なし |  |
| Type | `Image` |  |
| Original Content URL | `Image: Url` | 拡大時に表示される画像のURL。`imgBB`モジュールのアウトプットを利用する |
| Preview Image URL | `Thumbnail: Url` | トークルームに表示される画像のURL。`Hugging Face`モジュールのアウトプットを利用する |
