---
title: "ハンズオン - 画像からテキストを生成しよう（ImageToText）"
---

## 7-1. この章の完成イメージ

### 7-1-1. シナリオ

![image](https://i.imgur.com/fJgZ3xn.png)

### 7-1-2. LINE Bot

https://twitter.com/mitsuoka0423/status/1721949815901438115

## 7-2. 事前準備

- [ ] [ハンズオン - オウム返しするBotを作ろう｜【好きなモデルで作る】Hugging Face x LINE Botハンズオン【ノーコード】](https://zenn.dev/protoout/books/handson-hugging-face-line/viewer/040-echo-bot)

## 7-3. `LINE`モジュールの`Download a Message Attachment`を追加する

### 7-3-1. イメージ

![image](https://i.imgur.com/ANfPfp9.png)

![image](https://i.imgur.com/hZhu52L.png)

![image](https://i.imgur.com/Mp9ydTy.png)

![image](https://i.imgur.com/dgSOnx1.png)

## 7-4. `HTTP`モジュールの`Make a request`を追加する

### 7-4-1. イメージ

![image](https://i.imgur.com/dQGqGk7.png)

![image](https://i.imgur.com/x8xx5B0.png)

![image](https://i.imgur.com/vJiwXWr.png)

![image](https://i.imgur.com/w05cE1D.png)

### 7-4-2. 詳細

設定値の詳細は下記を確認してください

https://zenn.dev/protoout/books/handson-hugging-face-line/viewer/090-tips > `HTTP`モジュール（画像データ）

## 7-5. `LINE`モジュールの`Send a Reply Message`を変更する

### 7-5-1. イメージ

![image](https://i.imgur.com/ZOC1uYB.png)

![image](https://i.imgur.com/w05cE1D.png)
