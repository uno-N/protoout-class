---
title: "Hugging Faceでモデルを探して使ってみよう"
---

## 8-1. モデルの探し方

- Hugging Faceではモデルがカテゴリ分けされており、カテゴリベースでモデルを探すと探しやすいです

:::message info
すべてのモデルでInference APIが利用できるわけではないため、モデルを見つけたらInference APIが使えるか確認しましょう
:::

### 8-1-1. 操作

- https://huggingface.co/models を開く
- サイドバーから使いたいカテゴリを選ぶ
- 右側に表示されたモデルから好きなものを選ぶ
- `Deploy` > `Inference API`が表示されればOK

### 8-1-2. イメージ

![image](https://i.imgur.com/IPLri8o.png)

![image](https://i.imgur.com/5Zc1tm4.png)

![image](https://i.imgur.com/P6beVX7.png)

## 8-2. Inference APIの使い方

makeからInference APIを叩く方法を紹介します

### 8-2-1. 操作

- Inference APIを選ぶ
- URLをコピーする
- `HTTP`モジュールの`Make a request`に必要な情報を入力する
  - 詳細な手順は下記を参照
    - 画像データの場合：[Tips](https://zenn.dev/protoout/books/handson-hugging-face-line/viewer/090-tips) > `9-1-1. HTTPモジュール（画像データ）`
    - 音声データの場合：[Tips](https://zenn.dev/protoout/books/handson-hugging-face-line/viewer/090-tips) > `9-1-2. HTTPモジュール（音声データ）`

### 8-2-2. イメージ

![image](https://i.imgur.com/hnf1VpA.png)

![image](https://i.imgur.com/K4RXLil.png)

![](https://i.ibb.co/YhnRbtZ/Monosnap-Make-2023-11-03-14-41-51.png)

## 8-3. （補足）インプット/アウトプットで整理する

- 大きく下記の4つをインプット/アウトプットに利用できます
  - テキスト
  - 画像
  - 動画
  - 音声
- Hugging Faceではモデルがカテゴリ分けされているため、やりたいことのインプット/アウトプットが明確になっていると探しやすいです
  - やりたいことはとくに決めずに面白そうなモデルを探すのも楽しいです

### 8-3-1. 例

- テキストで指定した内容の画像を生成したい
  - 入力：`テキスト`、出力：`画像`
  - カテゴリ名：`Text-to-Image`
- 写真をゴッホ風のテイストに変換したい
  - 入力：`画像`、出力：`画像`
  - カテゴリ名：`Image-to-Image`
- 音声をアニメキャラの声に変換したい
  - 入力：`音声`、出力：`音声`
  - カテゴリ名：`Audio-to-Audio`

好きなモデルを見つけて、オリジナルののLINE AIチャットボットを作ってみましょう！
