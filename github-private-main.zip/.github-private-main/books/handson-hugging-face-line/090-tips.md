---
title: "Tips"
---

## 9-1. Inference APIのインプットに画像や音声を利用する

`Hugging Face`モジュールの`Make a API Call`では、画像や音声などバイナリデータを利用することができないようです
回避策として`HTTP`モジュールを利用する方法を紹介します

> `Hugging Face`モジュールの`Make a API Call`でのやり方をご存知の方いましたら教えてくださいm

### 9-1-1. `HTTP`モジュール（画像データ）

#### 9-1-1-1. イメージ

![](https://i.ibb.co/vhJMJ5q/Monosnap-Make-2023-11-03-14-53-04.png)

![](https://i.ibb.co/YhnRbtZ/Monosnap-Make-2023-11-03-14-41-51.png)

#### 9-1-1-2. 操作

- `HTTP`を選ぶ
- モジュールに値を入力する

#### 9-1-1-3. 詳細

| 項目 | 値 | 備考 |
| -- | -- | -- | 
| URL | 使いたいAPIのURL |  |
| Method | `POST` |  |
| Headers/Item 1/Name | `Authorization` |  |
| Headers/Item 1/Value | `Bearer [Hugging Faceのアクセストークン]` | `Bearer `のあとにアクセストークンを記載する。スペースも必須。アクセストークンは[ここ](https://huggingface.co/settings/tokens)で取得する |
| Body type | `Raw` |  |
| Content type | `Custom` |  |
| Value | `image/jpeg` | 画像データでは`image/jpeg`を利用（音声は別） |
| Request content | 画像データ | LINEモジュールとつなぐ場合は`Download a Message Attachment`の`Data`を選ぶ |

### 9-1-2. HTTPモジュール（音声データ）

#### 9-1-2-1. イメージ

![](https://i.ibb.co/vhJMJ5q/Monosnap-Make-2023-11-03-14-53-04.png)

![](https://i.ibb.co/85kLf3C/Monosnap-Make-2023-11-03-14-49-37.png)

#### 9-1-2-2. 操作

- `HTTP`を選ぶ
- モジュールに値を入力する

#### 9-1-2-3. 詳細

| 項目 | 値 | 備考 |
| -- | -- | -- | 
| URL | 使いたいAPIのURL |  |
| Method | `POST` |  |
| Headers/Item 1/Name | `Authorization` |  |
| Headers/Item 1/Value | `Bearer [Hugging Faceのアクセストークン]` | `Bearer `のあとにアクセストークンを記載する。スペースも必須。アクセストークンは[ここ](https://huggingface.co/settings/tokens)で取得する |
| Body type | `Raw` |  |
| Content type | `Custom` |  |
| Value | `audio/webm;codecs=opus` | 音声データでは`audio/webm;codecs=opus`を利用（画像は別） |
| Request content | 画像データ | LINEモジュールとつなぐ場合は`Download a Message Attachment`の`Data`を選ぶ |
