---
title: "APIとサンプルリスト: A~G"
---

## Animals
### Cat Facts

毎日の猫の事実

* public-apisでのカテゴリ
  * Animals
* 使い方の参考ページ
  * https://alexwohlbruck.github.io/cat-facts/docs/endpoints/facts.html

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://cat-fact.herokuapp.com/facts?animal_type=cat&amount=2');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Dogs

Stanford Dogsデータセットに基づく犬API

* public-apisでのカテゴリ
  * Animals
* 使い方の参考ページ
  * https://dog.ceo/dog-api/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://dog.ceo/api/breeds/image/random');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### RandomCat

猫のランダム写真

* public-apisでのカテゴリ
  * Animals
* 使い方の参考ページ
  * https://aws.random.cat/meow



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://aws.random.cat/meow');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### RandomDog

犬のランダムな写真

* public-apisでのカテゴリ
  * Animals
* 使い方の参考ページ
  * https://random.dog/woof.json



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://random.dog/woof.json');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### RandomFox	

キツネのランダムな写真

* public-apisでのカテゴリ
  * Animals
* 使い方の参考ページ
  * https://randomfox.ca/floof/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://randomfox.ca/floof/');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Shibe.Online

しばいぬ・猫・鳥のランダム写真

* public-apisでのカテゴリ
  * Animals
* 使い方の参考ページ
  * https://shibe.online/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('http://shibe.online/api/shibes?count=3&urls=true&httpsUrls=true');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Anime
### AnimeNewsNetwork

アニメ業界ニュース

* public-apisでのカテゴリ
  * Anime
* 使い方の参考ページ
  * https://www.animenewsnetwork.com/encyclopedia/api.php

**コメント**
* XMLで来る。JSONではないので扱いにくいけど、頑張って取得できるようにすれば有効に使える
  * 参考：node.jsのいろいろなモジュール38 – XMLとJSONの相互変換 | Developers.IO


**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://cdn.animenewsnetwork.com/encyclopedia/api.xml?anime=4658');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Jikan

非公式のMyAnimeList API

* public-apisでのカテゴリ
  * Anime
* 使い方の参考ページ
  * https://jikan.moe/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.jikan.moe/v3/search/anime?q=Naruto&limit=16');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Studio Ghibli

ジブリ映画のリソース

* public-apisでのカテゴリ
  * Anime
* 使い方の参考ページ
  * https://ghibliapi.herokuapp.com/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://ghibliapi.herokuapp.com/films/58611129-2dbc-4a81-a72f-77ddfc1b1b49');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Books
### LibGen



* public-apisでのカテゴリ
  * Books
* 使い方の参考ページ
  * http://garbage.world/posts/libgen/

**コメント**
* 現状はgen.lib.rus.ecでのアクセスがおススメらしい。読み替える。


**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('http://gen.lib.rus.ec/json.php?ids=1,2&fields=Title,Author,MD5');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Open Library

様々な図書館の本、本の表紙および関連データ

* public-apisでのカテゴリ
  * Books
* 使い方の参考ページ
  * https://openlibrary.org/developers/api



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('http://openlibrary.org/query.json?type=/type/edition&authors=/authors/OL1A&*=');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Penguin Publishing

ペンギン出版の本、本の表紙および関連データ

* public-apisでのカテゴリ
  * Books
* 使い方の参考ページ
  * http://www.penguinrandomhouse.biz/webservices/rest/

**コメント**
* ブラウザでたたくと自動認識でXMLが来る。axiosでたたくとJSON。おもしろい。


**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://reststop.randomhouse.com/resources/works/72148');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Business
### Domainsdb.info

登録ドメイン名検索

* public-apisでのカテゴリ
  * Business
* 使い方の参考ページ
  * https://domainsdb.info/?query=facebook

**コメント**
* 参考資料URLの下の方に叩き方が載っている。
* ドメインがの使用状況を確認できる
* ほどよく返答までが重いのでレスポンス待ちを体験できる。


**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://domainsdb.info/?query=facebook');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Calendar
### Church Calendar

カトリック典礼暦

* public-apisでのカテゴリ
  * Calendar
* 使い方の参考ページ
  * http://calapi.inadiutorium.cz/api-doc



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('http://calapi.inadiutorium.cz/api/v0/en/calendars/default/2015/6');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Czech Namedays Calendar

チェコのカレンダー

* public-apisでのカテゴリ
  * Calendar
* 使い方の参考ページ
  * http://svatky.adresa.info/

**コメント**
* チェコ語の勉強にもなる


**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('http://svatky.adresa.info/json?date=0101');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Namedays Calendar

いろいろな国の休日情報

* public-apisでのカテゴリ
  * Calendar
* 使い方の参考ページ
  * https://api.abalin.net/doc



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.abalin.net/namedays?month=1&day=1');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Cryptocurrency
### BitcoinCharts

ビットコインネットワークに関連する財務および技術データ

* public-apisでのカテゴリ
  * Cryptocurrency
* 使い方の参考ページ
  * https://bitcoincharts.com/about/exchanges/

**コメント**
* いまいち内容が掴めていない


**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://exchange.bitcoin/api/trades?since=5');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### CoinDesk

ビットコイン価格指数

* public-apisでのカテゴリ
  * Cryptocurrency
* 使い方の参考ページ
  * https://www.coindesk.com/coindesk-api



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.coindesk.com/v1/bpi/currentprice.json');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Currency Exchange
### Czech National Bank

為替レートのコレクション

* public-apisでのカテゴリ
  * Currency Exchange
* 使い方の参考ページ
  * 



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://www.cnb.cz/cs/financni_trhy/devizovy_trh/kurzy_devizoveho_trhu/denni_kurz.xml');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Exchangeratesapi.io

無料通貨換算

* public-apisでのカテゴリ
  * Currency Exchange
* 使い方の参考ページ
  * https://exchangeratesapi.io/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.exchangeratesapi.io/latest');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Frankfurter

フランクフルターAPIは、欧州中央銀行が発表する外国為替参照レートを追跡します。

* public-apisでのカテゴリ
  * Currency Exchange
* 使い方の参考ページ
  * https://www.frankfurter.app/docs/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.frankfurter.app/latest');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Rates API

レートAPIは、欧州中央銀行によって公開されたデータに基づいて構築された現在および過去の為替レートの無料サービスです。

* public-apisでのカテゴリ
  * Currency Exchange
* 使い方の参考ページ
  * https://ratesapi.io/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.ratesapi.io/api/latest');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Data Validation

(wip)

## Development
### Agify.io

名前から人の年齢を予測するためのシンプルなAPI

* public-apisでのカテゴリ
  * Development
* 使い方の参考ページ
  * https://agify.io/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.agify.io?name=michael');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### APIs.guru

Web APIのウィキペディア、パブリックAPIのOpenAPI / Swagger仕様

* public-apisでのカテゴリ
  * Development
* 使い方の参考ページ
  * https://apis.guru/api-doc/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.apis.guru/v2/list.json');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### The Bored API

退屈と戦うためにランダムな活動を見つける

* public-apisでのカテゴリ
  * Development
* 使い方の参考ページ
  * https://www.boredapi.com/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://www.boredapi.com/api/activity?participants=1');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### CDNJS

CDNJSのライブラリ情報

* public-apisでのカテゴリ
  * Development
* 使い方の参考ページ
  * https://api.cdnjs.com/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.cdnjs.com/libraries/jquery');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### CountAPI

このAPIを使用すると、単純な数値カウンターを作成できます

* public-apisでのカテゴリ
  * Development
* 使い方の参考ページ
  * https://countapi.xyz/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.countapi.xyz/hit/mysite.com/awesomeclick');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Public-APIs

Public-APIs（このAPI）

* public-apisでのカテゴリ
  * Development
* 使い方の参考ページ
  * https://github.com/davemachado/public-api



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.publicapis.org/entries?category=animals&https=true');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Environment
### GrünstromIndex

ドイツのグリーン電力指数（Grünstromindex/ GSI）

* public-apisでのカテゴリ
  * Environment
* 使い方の参考ページ
  * https://www.corrently.de/hintergrund/gruenstromindex



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.corrently.io/core/gsi?plz=69256');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### UK Carbon Intensity

National Gridによって開発された英国向けの公式炭素強度API

* public-apisでのカテゴリ
  * Environment
* 使い方の参考ページ
  * https://carbon-intensity.github.io/api-definitions/#carbon-intensity-api-v2-0-0



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.carbonintensity.org.uk/intensity');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Finance
### Razorpay IFSC

インドの金融システムコード（銀行支店コード）

* public-apisでのカテゴリ
  * Finance
* 使い方の参考ページ
  * https://ifsc.razorpay.com/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://ifsc.razorpay.com/KARB0000001');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Food & Drink
### Open Brewery DB

醸造所、サイダーリー、クラフトビールショップ情報

* public-apisでのカテゴリ
  * Food & Drink
* 使い方の参考ページ
  * https://www.openbrewerydb.org/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.openbrewerydb.org/breweries');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### PunkAPI

ビールのレシピ

* public-apisでのカテゴリ
  * Food & Drink
* 使い方の参考ページ
  * https://punkapi.com/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.punkapi.com/v2/beers?page=2&per_page=80');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Recipe Puppy

レシピ検索

* public-apisでのカテゴリ
  * Food & Drink
* 使い方の参考ページ
  * http://www.recipepuppy.com/about/api/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('http://www.recipepuppy.com/api/?i=onions,garlic&q=omelet&p=3');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### The Report Of The Week API

食べ物レポートの検索（YouTube）

* public-apisでのカテゴリ
  * Food & Drink
* 使い方の参考ページ
  * https://github.com/andyklimczak/TheReportOfTheWeek-API



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://thereportoftheweek-api.herokuapp.com/reports?category=Energy%20Crisis');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Games & Comics
### JokeAPI

プログラミング、その他のジョーク

* public-apisでのカテゴリ
  * Games & Comics
* 使い方の参考ページ
  * https://sv443.net/jokeapi



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://sv443.net/jokeapi/category/Programming');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Jokes

プログラミング、その他のジョーク

* public-apisでのカテゴリ
  * Games & Comics
* 使い方の参考ページ
  * https://github.com/15Dkatz/official_joke_api



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://official-joke-api.appspot.com/random_joke');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Open Trivia

雑学API

* public-apisでのカテゴリ
  * Games & Comics
* 使い方の参考ページ
  * https://opentdb.com/api_config.php



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://opentdb.com/api.php?amount=10');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### The RESTful Pokémon API

ポケモンAPI

* public-apisでのカテゴリ
  * Games & Comics
* 使い方の参考ページ
  * https://pokeapi.co/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://pokeapi.co/api/v2/pokemon/ditto/');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Rick and Morty

アメリカの大人向けサイエンス・フィクションシットコムアニメ「リック・アンド・モーティー」のAPI

* public-apisでのカテゴリ
  * Games & Comics
* 使い方の参考ページ
  * https://rickandmortyapi.com/documentation



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://rickandmortyapi.com/api/character/');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Geocoding
### HelloSalut

ユーザーの言語に従ってHelloの翻訳を取得する

* public-apisでのカテゴリ
  * Geocoding
* 使い方の参考ページ
  * https://www.fourtonfish.com/hellosalut/hello/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://fourtonfish.com/hellosalut/?lang=ja');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### OnWater

緯度/経度が水上か陸上かを確認します

* public-apisでのカテゴリ
  * Geocoding
* 使い方の参考ページ
  * https://onwater.io/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.onwater.io/api/v1/results/23.92323,-66.3');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Government
### Data USA

USAの様々なデータ

* public-apisでのカテゴリ
  * Government
* 使い方の参考ページ
  * https://datausa.io/about/api/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://datausa.io/api/data?drilldowns=Nation&measures=Population');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### US federal spending data

米国連邦支出データ

* public-apisでのカテゴリ
  * Government
* 使い方の参考ページ
  * https://api.usaspending.gov/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.usaspending.gov/api/v2/references/toptier_agencies/');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

