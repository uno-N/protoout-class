---
title: "APIとサンプルリスト: h~n"
---

## Health
### Covid-19

Covid 19の蔓延、感染および回復

* public-apisでのカテゴリ
  * Health
* 使い方の参考ページ
  * https://covid19api.com/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.covid19api.com/country/japan/status/confirmed');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Jobs
### Github Jobs

Github Jobs

* public-apisでのカテゴリ
  * Jobs
* 使い方の参考ページ
  * https://jobs.github.com/api



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://jobs.github.com/positions?description=javascript');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Open Skills

役職、スキル、および関連する求人データ????

* public-apisでのカテゴリ
  * Jobs
* 使い方の参考ページ
  * https://github.com/workforce-data-initiative/skills-api/wiki/API-Overview



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('http://api.dataatwork.org/v1/jobs/autocomplete?begins_with=%22engineer%22');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Music
### Lyrics.ovh

曲の歌詞を取得するシンプルなAPI

* public-apisでのカテゴリ
  * Music
* 使い方の参考ページ
  * https://lyricsovh.docs.apiary.io/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.lyrics.ovh/v1/Coldplay/Adventure%20of%20a%20Lifetime');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Songsterr

ギター、ベース、ドラムのタブとコードを提供

* public-apisでのカテゴリ
  * Music
* 使い方の参考ページ
  * https://www.songsterr.com/a/wa/api/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('http://www.songsterr.com/a/ra/songs.xml?pattern=Marley');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## News
### Chronicling America

Chronicling Americaは、歴史的な新聞とデジタル化された新聞のページに関する情報へのアクセスを提供します。

* public-apisでのカテゴリ
  * News
* 使い方の参考ページ
  * https://chroniclingamerica.loc.gov/about/api/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://chroniclingamerica.loc.gov/search/titles/results/?terms=michigan&format=json&page=5');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)