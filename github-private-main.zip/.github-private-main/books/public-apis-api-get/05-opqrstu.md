---
title: "APIとサンプルリスト: o~u"
---

## Open Data
### Archive.org

インターネットアーカイブのAPI

* public-apisでのカテゴリ
  * Open Data
* 使い方の参考ページ
  * https://archive.readme.io/docs



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://archive.org/wayback/available?url=www.example.com');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Callook.info

アメリカ合衆国のハムラジオのコールサイン

* public-apisでのカテゴリ
  * Open Data
* 使い方の参考ページ
  * https://callook.info/api_reference.php



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://callook.info/W1AW/json');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### French Address Search

フランス政府による住所検索

* public-apisでのカテゴリ
  * Open Data
* 使い方の参考ページ
  * https://geo.api.gouv.fr/adresse



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api-adresse.data.gouv.fr/search/?q=8+bd+du+port');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Universities List

大学名、国、ドメインを取得するAPI

* public-apisでのカテゴリ
  * Open Data
* 使い方の参考ページ
  * https://github.com/Hipo/university-domains-list



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('http://universities.hipolabs.com/search?name=middle&country=turkey');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### University of Oslo

オスロ大学（ノルウェー）のコース、講義ビデオ、コースの詳細情報など

* public-apisでのカテゴリ
  * Open Data
* 使い方の参考ページ
  * https://data.uio.no/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://data.uio.no/syllabus/v1/course/SOSGEO1120/semester/20v/reading-lists');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Wikipedia

WikipediaのAPI

* public-apisでのカテゴリ
  * Open Data
* 使い方の参考ページ
  * https://www.mediawiki.org/wiki/API:Main_page



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://meta.wikimedia.org/w/api.php?action=languagesearch&search=ja');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Open Source Projects

[wip]

## Patent
### USPTO

米国特許APIサービス

* public-apisでのカテゴリ
  * Patent
* 使い方の参考ページ
  * https://developer.uspto.gov/api-catalog

**コメント**
* サイトは若干迷ったがAPI操作画面は分かりやすい
  * 例： https://developer.uspto.gov/ds-api-docs/index.html?url=https%3A//developer.uspto.gov/ds-api/swagger/docs/oa_citations.json/v2#!/oa_citations/list_searchable_fields


**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://developer.uspto.gov/ds-api/oa_citations/v2/fields');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)


## Personality
### Advice Slip

ランダムなアドバイススレを生成する

* public-apisでのカテゴリ
  * Personality
* 使い方の参考ページ
  * https://api.adviceslip.com/#top

**コメント**
* 186番の内容とか面白い
  * https://api.adviceslip.com/advice/186


**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.adviceslip.com/advice');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### chucknorris.io

手作りのチャックノリスジョーク用のJSON API

* public-apisでのカテゴリ
  * Personality
* 使い方の参考ページ
  * https://api.chucknorris.io/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.chucknorris.io/jokes/random');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### kanye.rest

ランダムなカニエウェスト引用のREST API

* public-apisでのカテゴリ
  * Personality
* 使い方の参考ページ
  * https://kanye.rest/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.kanye.rest/');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### NaMoMemes

Narendra Modiのミーム

* public-apisでのカテゴリ
  * Personality
* 使い方の参考ページ
  * https://github.com/theIYD/NaMoMemes



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://namo-memes.herokuapp.com/memes/10');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Quote Garden

5000を超える有名な引用のREST API

* public-apisでのカテゴリ
  * Personality
* 使い方の参考ページ
  * https://pprathameshmore.github.io/QuoteGarden/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://quote-garden.herokuapp.com/api/v2/quotes/random');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Quotes on Design

デザインに関してのインスピレーションを与える名言

* public-apisでのカテゴリ
  * Personality
* 使い方の参考ページ
  * https://quotesondesign.com/api/



**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://quotesondesign.com/wp-json/wp/v2/posts/?orderby=rand');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)


## Science & Math
### arcsecond.io

複数の天文学データソース

* public-apisでのカテゴリ
  * Science & Math
* 使い方の参考ページ
  * https://api.arcsecond.io/

**コメント**
* Swagger UIで試せるのが素敵

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.arcsecond.io/activities/');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### GBIF

グローバル生物多様性の施設情報

* public-apisでのカテゴリ
  * Science & Math
* 使い方の参考ページ
  * http://api.gbif.org/v1/ https://www.gbif.org/developer/summary

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.gbif.org/v1/occurrence/search?year=1800,1899');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### iDigBio

世界中の組織から数百万もの博物館標本にアクセス

* public-apisでのカテゴリ
  * Science & Math
* 使い方の参考ページ
  * https://github.com/idigbio/idigbio-search-api/wiki

**コメント**
* v2 にバージョンアップされている。息の長いAPIぽい。

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('http://api.idigbio.org/v2/media/');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Launch Library

今後の宇宙打ち上げ情報

* public-apisでのカテゴリ
  * Science & Math
* 使い方の参考ページ
  * https://launchlibrary.net/docs/1.3/api.html

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://launchlibrary.net/1.3/agency/NASA');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Asterank.com

Asterank.com 情報。アステランクは、600,000以上の小惑星の科学的および経済的データベースです。

* public-apisでのカテゴリ
  * Science & Math
* 使い方の参考ページ
  * http://www.asterank.com/mpc

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('http://asterank.com/api/mpc?query={query}&limit={limit}');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### NASA

画像を含むNASAデータいろいろ

* public-apisでのカテゴリ
  * Science & Math
* 使い方の参考ページ
  * https://api.nasa.gov/

**コメント**
* api_key が必要だがDEMO_KEYをつければテストができます

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.nasa.gov/insight_weather/?api_key=DEMO_KEY&feedtype=json&ver=1.0');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### NASA APOD (unofficial API)

NASAのAPOD（今日の天文学画像）画像を取得するためのAPI。非公式。

* public-apisでのカテゴリ
  * Science & Math
* 使い方の参考ページ
  * https://apodapi.herokuapp.com/

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://apodapi.herokuapp.com/api/?date=2005-12-24&html_tags=true&image_thumbnail_size=450&absolute_thumbnail_url=true');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Numbers

数学についての事実・トリビア

* public-apisでのカテゴリ
  * Science & Math
* 使い方の参考ページ
  * http://numbersapi.com/#42

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('http://numbersapi.com/1..3,10');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Open Notify

ISS宇宙飛行士、現在地などの通知情報

* public-apisでのカテゴリ
  * Science & Math
* 使い方の参考ページ
  * http://open-notify.org/Open-Notify-API/

**コメント**
* サンプルはISSの情報

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('http://api.open-notify.org/iss-pass.json?lat=45.0&lon=-122.3&alt=20&n=5');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Open Science Framework

研究デザイン、研究資料、データ、原稿などのリポジトリとアーカイブ

* public-apisでのカテゴリ
  * Science & Math
* 使い方の参考ページ
  * https://developer.osf.io/#

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.osf.io/v2/users/?filter[full_name]=michel');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### SHARE

研究や学術活動に関するフリーでオープンなデータセット

* public-apisでのカテゴリ
  * Science & Math
* 使い方の参考ページ
  * https://share-research.readthedocs.io/en/latest/

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://share.osf.io/api/v2/search/creativeworks/_search');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### SpaceX

SpaceXに関する 会社、車両、発射台、打ち上げデータ

* public-apisでのカテゴリ
  * Science & Math
* 使い方の参考ページ
  * https://github.com/r-spacex/SpaceX-API

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.spacexdata.com/v3/launches/latest');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Sunrise and Sunset

緯度・経度に応じた日の出・日の入りのデータ

* public-apisでのカテゴリ
  * Science & Math
* 使い方の参考ページ
  * https://sunrise-sunset.org/api

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.sunrise-sunset.org/json?lat=35.6895&lng=139.69171');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### USGS Earthquake Hazards Program

リアルタイムの地震情報

* public-apisでのカテゴリ
  * Science & Math
* 使い方の参考ページ
  * https://earthquake.usgs.gov/fdsnws/event/1/

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&starttime=2014-01-01&endtime=2014-01-02');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### USGS Water Services

河川・湖の水質や水位の情報

* public-apisでのカテゴリ
  * Science & Math
* 使い方の参考ページ
  * https://waterservices.usgs.gov/rest/

**コメント**
* テストツールの使い方が若干難しい
  * 例: https://waterservices.usgs.gov/rest/GW-Levels-Service.html

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://waterservices.usgs.gov/nwis/gwlevels/?format=json&sites=375907091432201&siteStatus=all');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### World Bank

世界銀行のデータセット（財政や指標）

* public-apisでのカテゴリ
  * Science & Math
* 使い方の参考ページ
  * https://datahelpdesk.worldbank.org/knowledgebase/topics/125589

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('http://api.worldbank.org/v2/country/all/indicator/SP.POP.TOTL');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Security
### UK Police

英国の警察データ

* public-apisでのカテゴリ
  * Security
* 使い方の参考ページ
  * https://data.police.uk/docs/

**コメント**
* dateはあまり前だと出てこない 2020 時点で 2017とか

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://data.police.uk/api/crimes-street/all-crime?lat=52.629729&lng=-1.131592&date=2020-01');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Social
### HackerNews

CSと起業家のための社会ニュース

* public-apisでのカテゴリ
  * Social
* 使い方の参考ページ
  * https://github.com/HackerNews/API

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://hacker-news.firebaseio.com/v0/item/2921983.json?print=pretty');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Open Collective

Open Collectiveデータを取得する

* public-apisでのカテゴリ
  * Social
* 使い方の参考ページ
  * https://docs.opencollective.com/help/contributing/development/api

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://opencollective.com/sustainoss/events.json?limit=10&offset=0');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Sports & Fitness
### balldontlie

NBAからの統計データへのアクセスを提供します

* public-apisでのカテゴリ
  * Sports & Fitness
* 使い方の参考ページ
  * https://www.balldontlie.io/#getting-started

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://www.balldontlie.io/api/v1/players');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### BikeWise

Bikewise（自転車の衝突、危険、盗難について学び、報告するサイト）のAPI

* public-apisでのカテゴリ
  * Sports & Fitness
* 使い方の参考ページ
  * https://www.bikewise.org/documentation/api_v2

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://bikewise.org:443/api/v2/incidents?page=1&proximity_square=100');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### City Bikes

世界中のシティバイク情報

* public-apisでのカテゴリ
  * Sports & Fitness
* 使い方の参考ページ
  * http://api.citybik.es/v2/

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('http://api.citybik.es/v2/networks');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Ergast F1

1950年の世界選手権の初めからのF1データ

* public-apisでのカテゴリ
  * Sports & Fitness
* 使い方の参考ページ
  * http://ergast.com/mrd/

**コメント**
* .json をつけるとJSONフォーマットが来る

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('http://ergast.com/api/f1/drivers.json?limit=10&offset=20');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Football (Soccer) Videos

プレミアリーグ、ブンデスリーガ、セリエAなどのゴールとハイライトのコードを埋め込むAPI

* public-apisでのカテゴリ
  * Sports & Fitness
* 使い方の参考ページ
  * https://www.scorebat.com/video-api/

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://www.scorebat.com/video-api/v1/');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### NHL Records and Stats

NHLの履歴と統計のデータ

* public-apisでのカテゴリ
  * Sports & Fitness
* 使い方の参考ページ
  * https://gitlab.com/dword4/nhlapi

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://records.nhl.com/site/api/franchise-team-totals');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Test Data
### Bacon Ipsum

Bacon Ipsumの肉付きの良いテキストを生成します

* public-apisでのカテゴリ
  * Test Data
* 使い方の参考ページ
  * https://baconipsum.com/json-api/

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://baconipsum.com/api/?type=all-meat&sentences=1&start-with-lorem=1');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### JSONPlaceholder

テストとプロトタイピングのための偽のデータ

* public-apisでのカテゴリ
  * Test Data
* 使い方の参考ページ
  * http://jsonplaceholder.typicode.com/

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('http://jsonplaceholder.typicode.com/posts');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Loripsum

ダミーテキストを生成する

* public-apisでのカテゴリ
  * Test Data
* 使い方の参考ページ
  * https://loripsum.net/

**コメント**
* Lorem_ipsum とは
  * https://ja.wikipedia.org/wiki/Lorem_ipsum

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://loripsum.net/api/1/short/headers');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### PIPL

ランダムに偽の人々のデータをJSONで生成するフリーの公開API

* public-apisでのカテゴリ
  * Test Data
* 使い方の参考ページ
  * https://pipl.ir/

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://pipl.ir/v1/getPerson');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### RandomUser

ランダムのユーザーデータを生成します

* public-apisでのカテゴリ
  * Test Data
* 使い方の参考ページ
  * https://randomuser.me/documentation

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://randomuser.me/api/');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Yes No

YES NO ジェネレーター

* public-apisでのカテゴリ
  * Test Data
* 使い方の参考ページ
  * https://yesno.wtf/api

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://yesno.wtf/api');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Tracking
### Postmon

ブラジルの郵便番号をフリーで簡単に素早く取得するAPI

* public-apisでのカテゴリ
  * Test Data
* 使い方の参考ページ
  * https://postmon.com.br/

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.postmon.com.br/v1/cep/69934-000');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

## Transportation
### Icelandic APIs

アイスランドまたはアイスランドに関する交通サービスのAPI

* public-apisでのカテゴリ
  * Transportation
* 使い方の参考ページ
  * http://docs.apis.is/

**コメント**
* サイトも使いやすくて面白い

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://apis.is/flight?language=en&type=departures');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Metro Lisboa

地下鉄の遅延（ポルトガル リスボン？）

* public-apisでのカテゴリ
  * Transportation
* 使い方の参考ページ
  * 

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('http://app.metrolisboa.pt/status/getLinhas.php');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### TransitLand

トランジットアグリケーション

* public-apisでのカテゴリ
  * Transportation
* 使い方の参考ページ
  * https://transit.land/documentation/datastore/api-endpoints.html

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://transit.land/api/v1/routes?operated_by=o-9q8y-sfmta');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Transport for Atlanta, US

マルタ、米国アトランタへの輸送

* public-apisでのカテゴリ
  * Transportation
* 使い方の参考ページ
  * https://www.itsmarta.com/app-developer-resources.aspx

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('http://developer.itsmarta.com/BRDRestService/RestBusRealTimeService/GetAllBus');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Transport for Berlin, Germany

サードパーティーのベルリンの交通API

* public-apisでのカテゴリ
  * Transportation
* 使い方の参考ページ
  * https://github.com/derhuerst/vbb-rest/blob/3/docs/index.md

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://3.vbb.transport.rest/stops?query=jungfernheide');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Transport for Boston, US

ボストンの交通API

* public-apisでのカテゴリ
  * Transportation
* 使い方の参考ページ
  * https://mbta.com/developers/v3-api

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api-v3.mbta.com/routes?filter%5Bstop%5D=place-north');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Transport for Budapest, Hungary

ハンガリー・ブタペストの交通API

* public-apisでのカテゴリ
  * Transportation
* 使い方の参考ページ
  * https://bkkfutar.docs.apiary.io/#

**コメント**
* サイトのテストも分かりやすい

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://private-anon-a00cbde3d6-bkkfutar.apiary-proxy.com/api/query/v1/ws/otp/api/where/bicycle-rental.json?key=apaiary-test&version=3&appVersion=apiary-1.0&includeReferences=true');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Transport for London, England

イギリス ロンドンの交通API

* public-apisでのカテゴリ
  * Transportation
* 使い方の参考ページ
  * https://api.tfl.gov.uk/

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://api.tfl.gov.uk/AirQuality');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)

### Transport for Norway

ノルウェーの交通API

* public-apisでのカテゴリ
  * Transportation
* 使い方の参考ページ
  * https://reisapi.ruter.no/Help/

**コメント**
* シンプルな一覧だけど分かりやすい

**axios ソースコード**

```js
// axiosライブラリを呼び出す
const axios = require('axios');

// 実際にデータを取得する getRequest 関数
async function getRequest() {
  let response;
  try {
    response = await axios.get('https://reisapi.ruter.no/Place/GetStop/1');
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

// getRequest を呼び出してデータを読み込む
getRequest();
```

[目次に戻る 🔼](#top)
