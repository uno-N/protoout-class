# Discordの使い方


## 基本

[Discord の使い方](https://note.com/mss_discord/n/nfbe5aa2a797a)　[チャットでよく使う 4 つの機能を覚えよう【Discord コミュニティ運用術・機能編 1】 \| Appliv Games](https://games.app-liv.jp/archives/467564#link1)
  - OB 生とのつながりやイベントシェアチャンネルなど，受講生の方にも活用していただけるチャンネルが多数あります
  - 詳しくはこちらの一覧をご覧ください[Discordチャンネル情報 \- Google スプレッドシート](https://docs.google.com/spreadsheets/d/1CiZV_wzsRmRESAbNgmvtItMfSHNo8lLI0wAK_QzEn5k/edit?usp=sharing)

## プロトアウトのDiscordチャンネル情報です

| Discord         |                              |                                                              |
|-----------------|------------------------------|--------------------------------------------------------------|
| Text Channels   |                              |                                                              |
|                 | #general                     | 最初に参加するチャンネルです                                               |
|                 | #crowdfunding-share          | クラウドファンディングに関するネタを共有するチャンネルです                                |
|                 | #random                      | ランダムなトピックをシェアするチャンネルです                                       |
|                 | #mitene                      | 宿題やQiitaやnote記事をシェアするチャンネルです                                 |
|                 | #news-share                  | 宿題以外で気になった記事などを共有するチャンネル                                     |
| Event           |                              |                                                              |
|                 | #event-share                 | イベントをシェアするチャンネルです                                            |
|                 | #remoteworkhack              | #remoteworkhack LTイベントに関するチャンネルです                            |
|                 | #mokumoku-kai                | もくもく部屋です．                                                    |
|                 | #mokumoku-kai（voice channel） | もくもく部屋のVoice Channelです．                                      |
| 卒業制作            |                              |                                                              |
|                 | #demo-day                    | 卒業制作発表（DEMO DAY）と当日の話題など                                     |
|                 | #mentoring-cf                |                                                              |
| Class           |                              |                                                              |
|                 | #class-all                   | 学生全体のチャンネルです．ここではOB，OGとのコミュニケーションが取れます                       |
|                 | #tech-qa                     | 技術系のQAチャンネルです                                                |
|                 | #planning-qa                 | 企画系のQAチャンネルです                                                |
| Club            |                              |                                                              |
|                 | #執筆部                         | プロトアウトスタジオには部活があります！ここではCodeZineの連載企画など，技術記事の執筆に関するトピックがみれます |
| Voice Channnels |                              |                                                              |
|                 | #放課後A-Room                   | 時間を決めずに，自習室のように使っていただくチャンネルです                                |
|                 | #放課後B-Room                   |                                                              |
|                 | #放課後C-Room                   |
