# GitHub

## GitHub ディスカッション

- QAの場所
    - https://github.com/protoout/po-common/discussions/categories/q-a
- 自己紹介の場所
    - https://github.com/protoout/po-common/discussions/categories/%E8%87%AA%E5%B7%B1%E7%B4%B9%E4%BB%8B

## GitHubのチーム運用について

- [protoout](https://github.com/orgs/protoout/teams/protoout): プロトアウトスクール生が入ってる場所
    - 配下に各クラスごとのチームがあり、各クラスごとにリポジトリが見える
        - ex: https://github.com/orgs/protoout/teams/pds01-students
    - 運用
        - クラス間共有のリポジトリが閲覧可能
            - ex: https://github.com/protoout/po-common
        - クラス間共有のスレットが閲覧可能
            - ex: https://github.com/orgs/protoout/teams/protoout
- [seminar](https://github.com/orgs/protoout/teams/seminar): 特別授業などで利用したクラス
    - seminarは基本的に一時的なクラスなので特に活用は検討していなく、その授業のリポジトリを見るだけ用途
    - 配下に各クラスごとのチームがある
        - ex: https://github.com/orgs/protoout/teams/psh-students
- [staff](https://github.com/orgs/protoout/teams/staff): 運営側の人たちまとめ
    - mentor: メンター
    - teachers: 教員
    - operator: 副担/事務

