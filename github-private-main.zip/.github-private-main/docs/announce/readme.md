# 授業で利用するアナウンス系の資料


- [ツイート案内](./class_tweet.md)
- [肖像権](./copyright.md)
