# 企画・発信編の補足動画リスト

任意でご覧ください。

- [実装の優先順位とアドバイスの受け取り方](https://youtu.be/d8s5sPW7-lk)
  - メンタリングを進めていく際の注意点などの話をしています。
  - 見てほしい時期: Lessson06~07　メンタリングスタート頃
  - 重要度: 中

- [MVPと実装解像度を上げるためのプロトタイピング](https://youtu.be/iYC4UHAd2JM)
  - MVPという考え方、ここからの期間でどこを実装するか
  - 見てほしい時期: Lessson06~07　メンタリングスタート頃
  - 重要度: 中

- [CF裏目標ワーク](https://www.youtube.com/watch?v=ZTZOLgH--Gs)
  - リターンの設計について
  - 見てほしい時期: Lesson07~08 / 中間報告〜公開申請前頃
  - 重要度: 高
  - [裏目標 リターン設定ワーク](https://docs.google.com/spreadsheets/d/14CGjGbwsRdvN3ZhLwm49wbJDZizixQE36qaExj0Vkwo/edit?usp=sharing)

- [CF支援者獲得アクション](https://youtu.be/NX2mYx1q9Rk) / [CF支援者獲得アクション2](https://youtu.be/rCAwkHYllLs)
  - 発信の手法や考え方について
  - 見てほしい時期: Lesson08~09 / 公開申請前〜CF期間
  - 重要度: 高
  - [支援者獲得アクション計画ワーク](https://docs.google.com/spreadsheets/d/18TEP07mJeqq5qnZZfQbW7L7U_1ZyUS6JvPyBZAQJ8GE/edit?usp=sharing)
  - [CF支援者獲得リストアップワーク](https://docs.google.com/spreadsheets/d/1PWxPGEPxhDU_R5eA9v0rVCxFdPMYUdkOyDR4CW0xQDA/edit?usp=sharing)動画にはありませんが支援者の解像度を上げるために実施してみてください

- [DEMO DAYの解像度を上げていこう](https://youtu.be/XgTv2fzp__0)
  - DEMO DAYってどんな場にするべきだっけ
  - 見てほしい時期: Lesson08~09 / 公開申請前〜CF期間
  - 重要度: 高
  - [DEMODAYをイメージ](https://docs.google.com/spreadsheets/d/1LdQNQVuoNv8-j1lrnhCMdL9EaO7B0fL1uAxY1IH74o0/edit?usp=sharing)
