# 前座小噺：エンジニアの文化について

## ここでの「エンジニア」の定義

一言でエンジニアと言っても多岐にわたります。  
ここで話をするエンジニアとは「ITエンジニア」のことです。

[エンジニアとは何をする人？エンジニアの種類・仕事内容・適性をご紹介！](https://www.internetacademy.jp/it/programming/programming-basic/work-and-annual-income-types-of-engineer.html)

IT関連以外にも、鉄鋼業や交通インフラにおける技術職のエンジニアなどもいます。（が、今回の文脈とはちょっと別物です）

## ITエンジニアの生命線「GitHub」

複数人で同時にソフトウェアを開発するための「Git」という支援ソフトウェアがあります。  
一般には **バージョン管理システム** と呼ばれています。  

そのシステムをオンラインで提供するプラットフォーム（サービスの1つ）が「[GitHub](https://github.com/)」。  
まさしく今見ているこのページそのものです。

とくにWeb系のエンジニアは、このGitHubが障害で停止すると仕事も止まってしまう、というレベルでどっぷり依存して使っている人も多いです。

## 誰でも無償で中身が知れちゃう「オープンソース」

ソフトウェアには「ライセンス」というものがあり、一定の許諾の元に無償で自由に使えるライセンスを持ったソフトウェアのことを「オープンソース」といいます。  
GitHubではオープンソースなソフトウェアがたくさん公開されています。

有名どころ：

- Android <https://github.com/android>
- BitCoin <https://github.com/bitcoin/bitcoin>
- LibreOffice <https://github.com/LibreOffice>
- WordPress <https://github.com/WordPress/WordPress>

直接使ったことはなくても、システムの根幹にあってまったく気づかないうちに使っているもののほうがほとんどです。世界のインターネットを支えるシステムの大半で使われているOS「[Linux](https://github.com/torvalds/linux)」もその1つです。

権威ある機関も積極的にGitHubを利用しています。

- NASA <https://github.com/nasa>
- ホワイトハウス <https://github.com/whitehouse>
- 東京都公式コロナ情報サイト <https://github.com/tokyo-metropolitan-gov/covid19>

GitHubは、エンジニアにとっては、あらゆる情報が蓄積された「宝の山」でもあります。  
<https://twitter.com/ukokq/status/1286841913476132869>

## 技術知識を記事として発信する

通常のブログサービスだが、技術的な書き方に対応しているなどして、ITエンジニアが好んで使うサービスの1つに「はてな」があります。

- [はてなブログ](https://hatenablog.com/)
- [はてなブックマーク](https://b.hatena.ne.jp/)

2010年代以降は「テックブログ」という「技術記事投稿専門サイト」のような概念が生まれ、最近では多くのITエンジニアがこのようなプラットフォーム上で学んだ技術を発信したり、情報収集をしたりしています。

- [Qiita](https://qiita.com/)
- [Zenn](https://zenn.dev/)
- [note](https://note.com/)

## 相互扶助の精神

ITエンジニアの世界には「質問プラットフォーム」というものが普及しています。

- [Stack Overflow](https://ja.stackoverflow.com/)
- [teratail](https://teratail.com/)
- [Qiita 質問](https://qiita.com/question-trend)

参考: [エンジニア文化でよく使われる情報発信や収集サービスのまとめ](https://zenn.dev/protoout/articles/09-media-service-explain)

## コミュニティ文化

オンラインで非同期に情報交換をしたり、頻繁にイベントを開催するなどして運営されているエンジニアコミュニティが多数存在します。

- [IoTLT ~ IoT縛りの勉強会/LT会~ | Facebook](https://ja-jp.facebook.com/groups/IoTLT/)
- [RPACommunity - connpass](https://rpacommunity.connpass.com/)
- [JPPUG](https://power.users.community/forums/forum/power-automate/)

### イベント

ゆるいコミュニティだといわゆる「質問・雑談掲示板」のようなものがメインだったりしますが、エンジニアコミュニティの醍醐味といえば「イベント」です。イベントにさまざまな種類があり、またそのイベント開催をサポートするWebサービスも存在しています。近年はコロナウイルスの影響もあり、オンラインイベントがほぼ主流になってきています。

- [connpass - エンジニアをつなぐIT勉強会支援プラットフォーム](https://connpass.com/)
- [TECH PLAY［テックプレイ］ - IT勉強会・セミナーなどのイベント情報検索サービス](https://techplay.jp/)
- [Doorkeeper: セミナー・勉強会・イベント管理ツール](https://www.doorkeeper.jp/)

#### イベントの種類

参考：<https://tele-labo.jp/article/column/6126>

- カンファレンス・展示会
  - 大規模なイベントです。
  - 例：[Maker Faire Tokyo](https://makezine.jp/event/mft2021/)
  - 例：[DevRel / Japan](https://devrel.tokyo/japan-2021/)
- 勉強会
  - 登壇者の発表を授業のように聞くのがメインで、オンラインでも活発に行われています。
- ハンズオン・ワークショップ
  - 参加者も実際に一緒に手を動かしてモノを作っていくイベントです。
- LT会（ライトニングトーク）
  - 終業後にふらっと立ち寄って話をきいたり、オンラインでもラジオ的に流しておけるような、より軽く参加できるタイプの勉強会です。
  - 例：[IoT縛りの勉強会 ! IoTLT - connpass](https://iotlt.connpass.com/)
- もくもく会
  - 参考：[エンジニアのもくもく会とは？知識習得や人脈作りに役立つ？](https://www.pasonatech.co.jp/workstyle/column/detail.html?p=2282)
  - 授業の宿題実施タイムも「もくもく会」形式です。