# 前座小噺：エンジニアと英語

## ウェブサイトのコンテンツは**英語の情報が54%！！**
<a href="https://www.statista.com/chart/14900/two-worlds_-languages-irl-and-online/" title="Infographic: Two Worlds: Languages IRL and Online | Statista"><img src="https://cdn.statcdn.com/Infographic/images/normal/14900.jpeg" alt="Infographic: Two Worlds: Languages IRL and Online | Statista" width="100%" height="auto" style="width: 100%; height: auto !important; max-width:960px;-ms-interpolation-mode: bicubic;"/></a> You will find more infographics at <a href="https://www.statista.com/chartoftheday/">Statista</a>

※ 左のグラフ:第一言語を何語にしている人が何人くらいいるかの見積もり

※ 右のグラフ：ウェブサイトのコンテンツで使われている言語の割合

<br>

日本語のコンテンツはたったの**3.4%**......

3.4%の情報源だけで頑張るか、**英語を選択肢に入れて57.4%の情報源を武器にするか**......

新しい情報・必要な情報を得るために

慣れるかぁ、英語。

<br>

## よくある話

- [エンジニアには英語力が必要！得られるメリットやおすすめの勉強法を紹介](https://human.sankei.co.jp/guide/column/engineer-english/)
- [エンジニアは英語をどこまで勉強すればよいのか](https://qiita.com/e99h2121/items/c6afa788d87dbcb09175)

ガッツリTOEICで何百点とるだとかの話題が多いですが、そこまでする必要はないです。

## 実際どのレベルまで必要か？

× 英語で長文読解ができたり、動画を見て普通に理解できる  
○ 英語の操作画面（インターフェース）がなんとなくわかる

例えば、GitHubで公開されているオープンソースのREADMEの小見出しの英語は以下のようなものが一般的です。

- [【超初心者向け】はじめてのREADME.md](https://tips-memo.com/python-readme)

自分で調べながらモノをよく作ったりするようになってくると、以下で紹介されているあたりの単語は、パッと見でなんとなくわかるぐらいになっていることが大半です。

- [プログラミング必須英単語600+](https://progeigo.org/learning/essential-words-600-plus/)

さらに本格的になってくると以下のあたりの表現もわかると英語ドキュメントもさらっと読めるかもしれません。

- [Web業界でよく使う用語の英語辞典](https://www.webcreatorbox.com/webinfo/web-jargon-english)
- [ITの英語：ITエンジニアが知っておきたい英単語と表現](https://thinkit.co.jp/article/18226)

## 少しずつ慣れましょう

日常に英語、英単語があることを当たり前にしてゆけば、英語でしか展開されていない情報に出会っても抵抗が無くなってゆきます。

スマートフォンの言語設定を英語にしておくのもオススメ。（慣れないうちは、ワタワタします。笑）

- [米在住ライターが伝授！英語が身近になる15の習慣＆勉強法](https://kinarino.jp/cat6-%E3%83%A9%E3%82%A4%E3%83%95%E3%82%B9%E3%82%BF%E3%82%A4%E3%83%AB/43062-%E7%B1%B3%E5%9C%A8%E4%BD%8F%E3%83%A9%E3%82%A4%E3%82%BF%E3%83%BC%E3%81%8C%E4%BC%9D%E6%8E%88%EF%BC%81%E8%8B%B1%E8%AA%9E%E3%81%8C%E8%BA%AB%E8%BF%91%E3%81%AB%E3%81%AA%E3%82%8B15%E3%81%AE%E7%BF%92%E6%85%A3%EF%BC%86%E5%8B%89%E5%BC%B7%E6%B3%95)
