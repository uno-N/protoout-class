# 授業で利用するデバイスやセンサーの購入リスト obniz 2022年版

とくに指示がない場合は、自分でデバイスを買う体験をすることも兼ねて各自に購入を行ってもらいます。

## 0. デバイスの購入期限など

各クラスでの指示にしたがってください。
基本的には授業実施の2週間前くらいまでにアナウンスがあります。

また、 **初期不良などがある場合があるので、購入後に返品や交換をするケースもありえるかもしれません。余裕を持って購入しましょう。**

## 1. 購入品リスト

金額は2022/9/15時点の情報です。

合計: 8285円+USBケーブル。

### マイコンボード obniz Board 1Y

`obniz Board 1Y`をご購入ください。

- obniz Board 1Y
    - https://obniz.com/ja/products/obnizboard
    - 6930円

> 旧タイプのobniz Board（6090円）でも大丈夫ですが、使うセンサによっては一部配線の難易度が上がりますので基本的にはobniz Board 1Yがオススメです。

### センサー類

以下のセンサーなどを購入ください。
リンクは秋月電子のオンラインストアになっていますが、同じ型番のものが用意出来れば他のストアで購入しても大丈夫です。

リンク先によっては「セッションの有効期間がきれました」と表示される場合があります。その時は、ブラウザをリロードすると表示されます。

コロナ禍ですが、秋葉原の秋月電子は通常営業しているので、試しに現地で購入するのも体験としてオススメです。

- 抵抗内蔵5mm青色LED（5V用）OSB5SA5B64A－5V
    - http://akizukidenshi.com/catalog/g/gI-12519/
    - 25円
- 抵抗内蔵5mm赤色LED（5V用）640nm　OSR6LU5B64A－5V
    - https://akizukidenshi.com/catalog/g/gI-12517/ 
    - 15円
- 抵抗内蔵5mm黄色LED（5V用）590nm　OSY5LU5B64A－5V
    - https://akizukidenshi.com/catalog/g/gI-12520/
    - 15円
- マイコン内蔵RGB　8mmLED　PL9823－F8
    - http://akizukidenshi.com/catalog/g/gI-08412/
    - 40円
- マイクロサーボ9g　SG－90
    - http://akizukidenshi.com/catalog/g/gM-08761/
    - 440円
- 高精度IC温度センサー　LM60BIZ
    - http://akizukidenshi.com/catalog/g/gI-02490/
    - 50円
- CdSセル　5mmタイプ[MI527/MI5527]
    - http://akizukidenshi.com/catalog/g/gI-00110/
    - 30円
- 圧電スピーカー（圧電サウンダ）（13mm）PKM13EPYH4000－A0
    - http://akizukidenshi.com/catalog/g/gP-04118/
    - 30円
- 超音波距離センサー　HC－SR04[101-60-142 / 20-019-100-A]
    - http://akizukidenshi.com/catalog/g/gM-11009/
    - 300円
- ミニブレッドボード　BB－601（白）
    - http://akizukidenshi.com/catalog/g/gP-05155/
    - 130円
- ブレッドボード・ジャンパーワイヤ（オス－オス）10cmセット[BBJ-20]
    - http://akizukidenshi.com/catalog/g/gC-05371/
    - 180円
- カーボン抵抗（炭素皮膜抵抗）1／2W330Ω（100本入）
    - https://akizukidenshi.com/catalog/g/gR-07812/
    - 100円

### USBケーブル

`obniz Board 1Y`の電源として利用します。各自のパソコンなどの環境に合わせて用意しましょう。
`obniz Board 1Y`側はUSB Type-Cメスのポートなので、 **Type-Cオスのケーブルを一つ用意してください。**
スマートフォンなどの電源USBケーブルに該当する場合があるので、すでに持っている人は追加購入しなくても大丈夫です。
自身のPCのポートから電源を取るか、別途電源アダプターなどがある場合はそちらを使って電源給電を行ってください。

また、`obniz Board 1Y`ではなく`obniz Board`を利用する場合はポートがType-CではなくmicroBなので注意しましょう。

#### USBケーブル参考情報

**あくまでも以下のUSBケーブルは参考情報です。** 各自の環境に合わせてご購入ください。

##### パターン1:  給電側がタイプAの場合（一番よくみるUSB）

* [USBケーブル　USB2.0　TypeAオス⇔TypeCオス　1.5m](https://akizukidenshi.com/catalog/g/gC-13563/)

```
パソコン(Aメス) <----(Aオス&Type-CオスのUSBケーブル)---->  obniz Board 1Y(Type-Cメス)
```

##### パターン2: 給電側がタイプCの場合（最近のMacBookなど）

* [Type-Cオス&Type-Cオス](https://amzn.to/3gjFIi6)

```
パソコン(Cメス) <----(Type-Cオス&Type-CオスのUSBケーブル)----> obniz Board 1Y(Type-Cメス)
```

## 2. 事前にWi-Fiの接続をお試しください。

手元にobnizが届いた人は[Wi-Fiの接続](https://obniz.com/ja/doc/reference/board-1y/quick-start/)の`2-3 パスワードの入力`までを実施しておいてください。

万が一初期不良などがあった場合に返品して新しいものを届けてもらうなどをする必要があります。

## 参考

[2020年版](https://qiita.com/n0bisuke/private/51423cb0810238edb39e
)と比較すると値上がるものもあれば、値下がるものもありました
