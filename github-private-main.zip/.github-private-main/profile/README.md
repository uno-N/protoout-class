# 学内用のリンク

（この文章はログインしてる人しかみれません）

## 各種リンク

- Notionの学内ポータル
    - 教室や宿題など、大体の情報はこちらから辿れます。
    - https://www.notion.so/protoout/ce131fed7f8342318e2f7b71b98f5a97?v=2b87c40f784448f5b0c493c770586638
- 共通授業資料
    - こちらにまとまっています。
    - https://github.com/protoout/.github-private/tree/main/lessons
- ディスカッション Q&Aなど
    - https://github.com/orgs/protoout/discussions

