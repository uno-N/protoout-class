<div align="center">
<samp>

# 共通資料リポジトリ

プロトアウトスタジオ内のクラス共通の資料置き場です。
各自活用しましょう。

</samp>
</div>

## 主に学生向け

- 宿題関連: [homework](docs/homework)
- クラウドファンディング関連: [cf](docs/cf)
- 授業準備関連（obniz購入指示など: [prepatations](docs/preparations)
- Tips記事など: https://zenn.dev/protoout
- 動画授業: [lessons](lessons)

## 主に教員向け

- 授業で利用する共通案内系資料: [announce](docs/announce)
- 授業資料を作る際、zennに資料がないかを確認しましょう。
    - チートシート / 各種アカウント作成の手順 / 事例集などは外部公開資料としてzennに公開しています。
        - [articles](articles)
        - [books](books)
            - ※講師運営陣へ
                - 資料作成の際はarticlesフォルダーに設置してください。 ↑のzennに公開されます。
                - 書き方は既存のmdを参考にしてください。

## その他リポジトリへのリンク

### クラスごとの教材

- 一般クラス
    - https://github.com/protoout/po
- 法人クラス
    - https://github.com/protoout/pst
    - https://github.com/protoout/pds
    - https://github.com/protoout/peo
    - https://github.com/protoout/peh
    - https://github.com/protoout/pmv
- 姉妹校:
    - もいせん: https://github.com/protoout/moicen
    - もいせん事務局: https://github.com/protoout/forest
- その他:
    - https://github.com/protoout/shd

### 運営サイド資料

- メンターおよびチューター向け資料
    - https://github.com/protoout/mentoring
- 事務局および教員向け
    - https://github.com/protoout/jimukyoku
